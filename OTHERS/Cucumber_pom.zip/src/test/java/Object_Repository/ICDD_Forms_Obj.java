package Object_Repository;

import org.openqa.selenium.By;

public class ICDD_Forms_Obj {
	
	public static final By CUSTOMER_ALERT=By.xpath("//td[text()='Customer Alerts']");
	public static final By CHECK_FIRST_ALERT=By.xpath("//table[@id='alertsModel']//input[@class='cbox']");
	public static final By CLICK_ALERT=By.xpath("//table[@id='alertsModel']//td[@aria-describedby='alertsModel_alertId']//a");
	public static final By CLICK_ALERT2=By.xpath("//table[@id='alertsModel']/tr[2]//td[@aria-describedby='alertsModel_alertId']//a");
	public static final By FORMSTAB=By.xpath("(//a[@id='icon_default_a'])[2]");
	public static final By CLONEFORM=By.xpath("//li[@title='Clone Work Item']/a");
	// SOW
	public static final By SOWFORM=By.xpath("//li[@title='Create Source Of Wealth E-Form']/a");
	public static final By SOW_WORKITEM=By.xpath("//td[@title='Source Of Wealth']");
	public static final By ACCOUNT_FULLNAME=By.id("cdev_fullNameOfClient");
	public static final By ACCOUNT_PARENTID=By.id("cdev_parentAlertId");
	public static final By ACCOUNT_ICDDTID=By.id("cdev_icddId");
	public static final By ACCOUNT_ICMID=By.id("cdev_icmId");
	public static final By DEPOSITS_ANTICIPATED_NO=By.id("cdev_sow_trxAmountPerMonth1");
	public static final By DEPOSITS_ANTICIPATED_TOTAL=By.id("cdev_sow_trxValuePerMonth1");
	public static final By WITHDRAWAL_ANTICIPATED_NO=By.id("cdev_sow_trxAmountPerMonth2");
	public static final By WITHDRAWAL_ANTICIPATED_TOTAL=By.id("cdev_sow_trxValuePerMonth2");

	public static final By SOURCE_OF_DEPOSIT=By.xpath("//*[@id='cdev_sow_listInitialDepositSources_ui_chosen']//input");
	public static final By COUNTRIES_OF_DEPOSIT=By.xpath("//*[@id='cdev_sow_listInitialDepositTypes_ui_chosen']//input");
	public static final By COUNTIRES_INIT_DEPOSIT=By.xpath("//*[@id='cdev_sow_listInitialDepositCountries_ui_chosen']//input");
	
	public static final By EMPLOYMENT_JOB_TITLE=By.id("cdev_sow_jobTitle");
	public static final By EMPLOYMENT_EMP_NAME=By.id("cdev_sow_nameOfEmployer");
	public static final By EMPLOYMENT_NATURE=By.xpath("//*[@id='cdev_sow_natureOfBusiness1_ui_chosen']//input");
	public static final By EMPLOYMENT_TOTAL_EXP=By.id("cdev_sow_yearsOfWorkExperience");
	public static final By EMPLOYMENT_ANNUAL_INCOME=By.id("cdev_sow_totalEmploymentIncome");
	public static final By INVESTEMENT_INCOME=By.id("cdev_sow_totalInvestmentIncome");
	public static final By PROPERTY_INCOME=By.id("cdev_sow_totalRentalIncome");
	public static final By BUSINESS_ESTABLISHED=By.id("cdev_sow_businessEstablishment");
	public static final By BUSINESS_NATURE=By.xpath("//*[@id='cdev_sow_natureOfBusiness2_ui_chosen']//input");
	public static final By BUSINESS_OWNERSHIP_PERCENTAGE=By.id("cdev_sow_ownershipOfBusiness");
	public static final By BUSINESS_CLIENT_PAY=By.id("cdev_sow_clientBusinessPayment");
	public static final By BUSINESS_TOTAL_INCOM=By.id("cdev_sow_totalBusinessIncome");
	public static final By OTHER_SOURCE_INCOME=By.id("cdev_sow_otherIncomeSource");
	public static final By OTHER_TOTAL_INCOME=By.id("cdev_sow_totalOtherIncome");
	public static final By INHERITANCE_YEAR=By.id("cdev_sow_year1");
	public static final By INHERITANCE_TYPE=By.id("cdev_sow_typeOfAsset1");
	public static final By INHERITANCE_ORIGINAL_AMOUNT=By.id("cdev_sow_originalAmount1");
	public static final By INHERITANCE_RELATIONSHIP=By.id("cdev_sow_relationshipWithClient1");
	public static final By INHERITANCE_SOURCE=By.id("cdev_sow_sourceOfWealthOfGiver1");
	public static final By SAVINGS_TOTALAMOUNT_ON=By.id("cdev_sow_savingValue");
	public static final By SAVINGS_TOTALAMOUNT_OFF=By.id("cdev_sow_savingValue_off");
	public static final By MORTGAGE_LIABILITIES_ON=By.id("cdev_sow_mortgageValue");
	public static final By MORTGAGE_TOTALAMOUNT_OFF=By.id("cdev_sow_mortgageValue_off");
	public static final By INVESTMENTS_TOTALAMOUNT_ON=By.id("cdev_sow_investmentsValue");
	public static final By INVESTMENTS_TOTALAMOUNT_OFF=By.id("cdev_sow_investmentsValue_off");
	public static final By LOANS_LIABILITIES_ON=By.name("cdev_sow_loansValue");
	public static final By LOANS_TOTALAMOUNT_OFF=By.id("cdev_sow_loansValue_off");
	public static final By PROPERTY_TOTALAMOUNT_ON=By.id("cdev_sow_propertyValue");
	public static final By PROPERTY_TOTALAMOUNT_OFF=By.id("cdev_sow_propertyValue_off");
	public static final By OTHER_LIABILITIES_ON=By.id("cdev_sow_otherValue");
	public static final By OTHER_TOTALAMOUNT_OFF=By.id("cdev_sow_otherValue_off");
	public static final By COUNTRIES_SIGNIFICANT_WEALTH=By.xpath("//*[@id='cdev_sow_listCountries_ui_chosen']//input");
	public static final By INDUSTRIES_SIGNIFICANT_WEALTH=By.xpath("//*[@id='cdev_sow_listIndustries_ui_chosen']//input");
	public static final By DEFENCE_WEAPONS=By.id("cdev_sow_defenceAndMilitary_ui");
	public static final By MONY_SERVICE=By.id("cdev_sow_moneyService_ui");
	public static final By GAMING_INDUSTRIES=By.id("cdev_sow_gamingGambling_ui");
	public static final By PRECIOUS_METALS=By.id("cdev_sow_diamondAndMineral_ui");
	public static final By ROUGH_DIAMONDS=By.id("cdev_sow_diamondAndMineralQuestion1");
	public static final By KIMBERLEY_PROCESS=By.id("cdev_sow_diamondAndMineralQuestion2");
	public static final By CONCLUSION_INCOME_OR_WEALTH=By.id("cdev_sow_doesTheClientDerive");
	public static final By CONCLUSION_CORROBORATED=By.id("cdev_sow_hasSourceOfWealthBeenCorroborated");
	public static final By CONCLUSION_DETAILED_CORROBORATED=By.id("cdev_sow_detailedCorroborationOfSow");
	public static final By CONCLUSION_CONCERN_CLIENT_SOURCE=By.id("cdev_sow_isThereAnyDoubtOrConcern");
	public static final By CONCLUSION_PROVIDE_REASON=By.id("cdev_sow_isThereAnyDoubtOrConcernReason");
	public static final By CONCLUSION_EXPLAIN=By.id("cdev_sow_describeAccumulationOfNetWorth");
	
	public static final By GAMLING_INDUSTRY_CLIENT_DRIVE=By.id("cdev_sow_gamblingIndustryClientDerive");
	public static final By CLIENT_CONTROLLING_DIRECTOR_HNW=By.id("cdev_sow_clientControllingDirector");
	
	
	//Adverse Media
	public static final By ADVERSE_WORKITEM=By.xpath("//td[@title='Adverse Information Assessment']");
	public static final By ADVERSE_MEDIA_FORM=By.xpath("//li[@title='Create Adverse Media E-Form']/a");
	public static final By NAME_OF_THE_PARTY=By.name("cdev_am_involvedPartyName");
	public static final By RELATIONSHIP_WITH_BANK_CUSTOMER=By.id("cdev_am_relationshipWithBanksCustomer");
	public static final By MEDIA_REPORT_HEADLINE=By.id("cdev_am_adverseMediaReportheadline");
	public static final By TYPE_OF_ADVERSE=By.id("cdev_am_typeOfAdverseMedia");
	public static final By COUNTRYOF_INCIDENT=By.id("cdev_am_countryOfIncident");
	public static final By DATEOF_ADVERSE_NEWS=By.id("dateField_cdev_am_adverseNewsDate");
	public static final By REGULATORY_ACTION=By.id("cdev_am_hasRegulatoryActionTakenPlace");
	public static final By DATE_OF_REGULATORY_ACTION=By.id("dateField_cdev_am_dateOfRegulatoryAction");
	public static final By TYPEOF_REGULATORY_ACTION=By.id("cdev_am_typeOfRegulatoryAction");
	public static final By SOURCEOF_ADVERSE_MEDIA=By.id("cdev_am_sourceOfAdverseMedia");
	public static final By CREADIBLE_NONCREADIBLE_SOURCE=By.id("cdev_am_credibility");
	public static final By FACTS_ALLEGATION_SPECULATION=By.xpath("//div[@id='cdev_am_contact_ui_chosen']//input");
	public static final By RISK_OF_ADVERSE_MEDIA=By.id("cdev_am_riskOfAdverseMedia");
	public static final By DETAILS_ADVERSEMEDIA_REPUTATION=By.id("cdev_am_reputation");
	public static final By DETAILS_AM_ASSOCIATED_PARTY_BG=By.id("cdev_am_associatedPartyBackground");
	public static final By DETAILS_AM_ASSOCIATED_PARTY_REPUTATION=By.id("cdev_am_associatedPartyReputation");
	public static final By CONFIRM_AM_ON_CLIENT=By.id("cdev_am_confirmedAdverseMediaOnClient");
	public static final By RECOMMENDATION_BY_RM=By.id("cdev_am_recommendationByTheRm");
	public static final By RM_REASON_FOR_RECOM=By.id("cdev_am_reasonsForRecommendation");
	public static final By AM_NEXT=By.id("textButton_nextButton");
	public static final By AM_NOTE=By.id("tinymce");
	public static final By AM_FINISH=By.id("textButton_finishButton");
	
// PEP Form
	public static final By PEP_WORKITEM=By.xpath("//td[@title='PEP Assessment Form']");
	public static final By PEP_EFORM=By.xpath("//li[@title='Create PEP E-Form']/a");
	public static final By SOURCEOF_PEP_TRIGGER=By.id("cdev_pep_sourceOfPepTrigger");
	public static final By RELATIONSHIP_WITH_CLIENT=By.id("cdev_pep_relationshipWithClient");
	public static final By CLIENT_PEP_OR_PEPLINKED=By.id("cdev_pep_pepOrPepLinked");
	public static final By NAME_OF_PROMINENTPFH=By.id("cdev_pep_nameOfProminentPFH");
	public static final By COUNTRY_OF_RESIDENCE_PFH=By.id("cdev_pep_countryOfResidentOfPpfHolder");
	public static final By LATEST_PUBLIC_FUNCTION=By.id("cdev_pep_publicFunction1");
	public static final By LATEST_COUNTRY_POWER_OR_AUTHORITY=By.id("cdev_pep_country1");
	public static final By LATEST_FROM_YEAR=By.id("cdev_pep_from1");
	public static final By LATEST_TO_YEAR=By.id("cdev_pep_to1");
	public static final By PREVIOUS_PUBLIC_FUNCTION=By.id("cdev_pep_publicFunction2");
	public static final By PREVIOUS_COUNTRY_POWER_OR_AUTHORITY=By.id("cdev_pep_country2");
	public static final By PREVIOUS_FROM_YEAR=By.id("cdev_pep_from2");
	public static final By PREVIOUS_TO_YEAR=By.id("cdev_pep_to2");
	public static final By PUBLIC_FUNCTION_HOLDING=By.xpath("//*[@id='cdev_pep_doesPFHMatchesFollowing_ui_chosen']//input");
	public static final By DESCRIBE_THE_ORG=By.id("cdev_pep_describeTheOrganisation");
	public static final By DESCRIBE_THE_INDIVIDUAL=By.id("cdev_pep_describeTheIndividualsPosition");
	public static final By PFH_STILL_IN_OFFICE=By.id("cdev_pep_isPFHStillInOffice");
	public static final By PFH_LEFT_OFFICE_MONTH=By.id("cdev_pep_whenPFHLeftOfficeMonth");
	public static final By PFH_LEFT_OFFICE_YEAR=By.id("cdev_pep_whenPFHLeftOffice");
	public static final By FINAL_PEP_STATUS=By.id("cdev_pep_finalDecisionOnPepStatus");
	public static final By REASON_THE_CLIENT_IS_PEP=By.id("cdev_pep_reasonTheClientIsAPep");
	public static final By PEP_CATEGORY=By.id("cdev_pep_pepCategory");
	public static final By COUNTRYOF_PEP_DERIVES_POWER=By.id("cdev_pep_countryWhereThePepDerivesPower");
	public static final By PEP_DECLASSIFICATION_REQ=By.id("cdev_pep_declassificationRequired");
	public static final By PEP_LINK_OF_INFLUENCE=By.xpath("//*[@id='cdev_pep_doesThePepHaveLinksOrInfluence_ui_chosen']//input");
	public static final By PEP_INDUSTRY_INFLUENCE=By.xpath("//*[@id='cdev_pep_industry_ui_chosen']//input");
	public static final By PEP_INVOLVEMENT_IN_INDUSTRY=By.id("cdev_pep_describeThePepsInvolvement");
	public static final By ADVERSE_MEDIA_ON_PEP=By.id("cdev_pep_isThereAnyAdverseMediaOnTheClient");
	public static final By PEP_OTHER_SUBSTANTIAL_INCOME=By.id("cdev_pep_hasTheClientEarnedAnySubstantialIncome");
	public static final By PEP_RECEIVED_LARGE_AMOUNT_OF_MONEY=By.id("cdev_pep_hasTheClientReceivedLargeAmountsOfMoney");
	public static final By PEP_ASKED_FOR_ADDITIONAL_SECRECY=By.id("cdev_pep_hasTheClientAskedForAnyAdditionalSecrecy");
	public static final By PEP_SECRECY_PROVIDE_DETAILS=By.id("cdev_pep_provideDetail");
	public static final By PEP_BASED_ON_TRANSACTION_REVIEW=By.id("cdev_pep_basedOnTransactionReview");
	public static final By PROVIDE_DETAILS_TRANSACTION_REVIEW=By.id("cdev_pep_provideDetail2");
	public static final By SUSPICIOUS_ACTIVITY_FILE=By.id("cdev_pep_suspiciousActivityOnTheAccount");
	public static final By DECISION_TO_ONBOARD=By.id("cdev_pep_decisionToOnboardRetainTheClient");
	public static final By REASON_TO_ONBOARD_OR_RETAIN=By.id("cdev_pep_reasonToOnboardRetainTheClient");
	public static final By ADDITIONAL_CONTROLS=By.id("cdev_pep_additionalControlsToBePlacedIfAny");
	
	public static final By OTHER_DOMESTIC_FOREIGN_PEP=By.id("cdev_pep_domesticOrForeignPepClient");
	public static final By OTHER_HNW_PEP=By.id("cdev_pep_pepMeetHNWCriteria");
	public static final By OTHER_PEP_VERY_HIGH_RISK_COUNTRY=By.id("cdev_pep_isThePepVeryHighRiskCountry");
	
	//Tax E-Form
	public static final By TAX_WORKITEM=By.xpath("//td[@title='TAX Questionnaire']");
	public static final By TAXE_FORM=By.xpath("(//a[@id='icon_create_form_a'])[5]");
	public static final By SUBJECTOF_ADVERSE_TAX_NEWS=By.id("cdev_tq_question1");
	public static final By TAX_NEWS_COMMENTS=By.id("cdev_tq_comment1");
	public static final By CLIENT_UNWILLING_TO_SHARE_INFO=By.id("cdev_tq_question2");
	public static final By INFO_COMMENTS=By.id("cdev_tq_comment2");
	public static final By INCONSISTENT_CLIENT_PROFILE_NET=By.id("cdev_tq_question3");
	public static final By INCONSISTENCY_COMMENTS=By.id("cdev_tq_comment3");
	public static final By CLIENT_LIQUID_ASSET=By.id("cdev_tq_question4");
	public static final By LIQUID_COMMENT=By.id("cdev_tq_comment4");
	public static final By PERSONAL_INVESTMENT_VEHICLE=By.id("cdev_tq_question5");
	public static final By PERSONAL_INVESTMENT_COMMENT=By.id("cdev_tq_comment5");
	public static final By MANAGED_CLIENT_ASSET=By.id("cdev_tq_question6");
	public static final By MANAGED_CLIENT_ASSET_COMMENTS=By.id("cdev_tq_comment6");
	public static final By CLIENT_PAYMENT=By.id("cdev_tq_question7");
	public static final By CLIENT_PAYMENT_COMMENTS=By.id("cdev_tq_comment7");
	public static final By CLIENT_ACC_MAINTANENCE=By.id("cdev_tq_question8");
	public static final By CLIENT_ACC_MAINTANENCE_COMMENTS=By.id("cdev_tq_comment8");
	public static final By CLIENT_COMMERCIAL_TXN=By.id("cdev_tq_question9");
	public static final By CLIENT_COMMERCIAL_TXN_COMMENTS=By.id("cdev_tq_comment9");
	public static final By CONTACT_BTW_CLIENT_AND_BANK=By.id("cdev_tq_question10");
	public static final By CONTACT_BTW_CLIENT_AND_BANK_COMMENTS=By.id("cdev_tq_comment10");
	public static final By CLIENT_SAR=By.id("cdev_tq_question11");
	public static final By CLIENT_SAR_COMMENTS=By.id("cdev_tq_comment11");
	public static final By CLIENT_TRANSFERRING_FUNDS=By.id("cdev_tq_question12");
	public static final By TAX_EVASION_RED_FLAG=By.id("cdev_tq_taxEvasionRedFlag");
	public static final By CLIENT_TRANSFERRING_FUNDS_COMMENTS=By.id("cdev_tq_comment12");
	public static final By REASON_FOR_RED_FLAG=By.id("cdev_tq_reasonOfRedFlagOnTaxEvasion");
	public static final By RM_RECOMMENDATION=By.xpath("//select[@id='cdev_tq_rmsRecommendation']");
	public static final By REASON_FOR_MAINTAINING_REL=By.id("cdev_tq_reasonOfMaintainingRelationship");
	public static final By SUGGESTED_ACTION=By.id("cdev_tq_suggestedActionByRm");
	
	//Client Contact Form
	public static final By CLIENT_CONTACT_WORKITEM=By.xpath("//td[@title='Client Contact']");
	public static final By CLIENT_CONTACT_FORM=By.xpath("(//a[@id='icon_create_form_a'])[6]");
	public static final By DATE_AND_TIME_OF_CONTACT=By.id("dateField_cdev_cc_dateAndTimeOfContact1");
	public static final By NATURE_OF_CONTACT=By.id("cdev_cc_natureOfContact1");
	public static final By ATTENDEES=By.xpath("//textarea[@id='cdev_cc_attendees1']");
	public static final By DESCRIPTION_OF_CLIENT_CONTACT=By.id("cdev_cc_descriptionOfClientContact1");
	public static final By EVENT_TYPE=By.xpath("//select[@id='cdev_cc_eventType1']");
	public static final By GENERATED_DATEOF_LETTERSMS=By.id("dateField_cdev_cc_generationDate1");
	public static final By LETTER_REF_EMAIL=By.id("cdev_cc_referenceNumber1");
	public static final By DATE_AND_TIME_OF_CONTACT2=By.id("dateField_cdev_cc_dateAndTimeOfContact2");
	public static final By NATURE_OF_CONTACT2=By.id("cdev_cc_natureOfContact2");
	public static final By ATTENDEES2=By.xpath("//textarea[@id='cdev_cc_attendees2']");
	public static final By DESCRIPTION_OF_CLIENT_CONTACT2=By.id("cdev_cc_descriptionOfClientContact2");
	public static final By EVENT_TYPE2=By.xpath("//select[@id='cdev_cc_eventType2']");
	public static final By GENERATED_DATEOF_LETTERSMS2=By.id("dateField_cdev_cc_generationDate2");
	public static final By LETTER_REF_EMAIL2=By.id("cdev_cc_referenceNumber2");
	public static final By DATE_AND_TIME_OF_CONTACT3=By.id("dateField_cdev_cc_dateAndTimeOfContact3");
	public static final By NATURE_OF_CONTACT3=By.id("cdev_cc_natureOfContact3");
	public static final By ATTENDEES3=By.xpath("//textarea[@id='cdev_cc_attendees3']");
	public static final By DESCRIPTION_OF_CLIENT_CONTACT3=By.id("cdev_cc_descriptionOfClientContact3");
	public static final By EVENT_TYPE3=By.xpath("//select[@id='cdev_cc_eventType3']");
	public static final By GENERATED_DATEOF_LETTERSMS3=By.id("dateField_cdev_cc_generationDate3");
	public static final By LETTER_REF_EMAIL3=By.id("cdev_cc_referenceNumber3");
	public static final By DATE_AND_TIME_OF_CONTACT4=By.id("dateField_cdev_cc_dateAndTimeOfContact4");
	public static final By NATURE_OF_CONTACT4=By.id("cdev_cc_natureOfContact4");
	public static final By ATTENDEES4=By.xpath("//textarea[@id='cdev_cc_attendees4']");
	public static final By DESCRIPTION_OF_CLIENT_CONTACT4=By.id("cdev_cc_descriptionOfClientContact4");
	public static final By EVENT_TYPE4=By.xpath("//select[@id='cdev_cc_eventType4']");
	public static final By GENERATED_DATEOF_LETTERSMS4=By.id("dateField_cdev_cc_generationDate4");
	public static final By LETTER_REF_EMAIL4=By.id("cdev_cc_referenceNumber4");
	public static final By DATE_AND_TIME_OF_CONTACT5=By.id("dateField_cdev_cc_dateAndTimeOfContact5");
	public static final By NATURE_OF_CONTACT5=By.id("cdev_cc_natureOfContact5");
	public static final By ATTENDEES5=By.xpath("//textarea[@id='cdev_cc_attendees5']");
	public static final By DESCRIPTION_OF_CLIENT_CONTACT5=By.id("cdev_cc_descriptionOfClientContact5");
	public static final By EVENT_TYPE5=By.xpath("//select[@id='cdev_cc_eventType5']");
	public static final By GENERATED_DATEOF_LETTERSMS5=By.id("dateField_cdev_cc_generationDate5");
	public static final By LETTER_REF_EMAIL5=By.id("cdev_cc_referenceNumber5");

	//Addition CDD form
	public static final By ADDITIONAL_CDD_FORM=By.xpath("//li[@title='Trigger Additional CDD']/a");
	public static final By NAME_SCREENING_RESULTRS=By.id("nameScreeningHit");
	public static final By NAME_SCREENING_TRUE_MATCH=By.id("isTrueMatch");
	public static final By NAME_SCREENING_MATCH=By.xpath("//div[@id='nameScreeningMatchType_ui_chosen']/ul/li/input");
	public static final By CLIENT_SANCTIONED_FINAL_DECISION=By.id("clientSanctionedFinalDecision");
	public static final By SANCTIONS_LINKS_SUMMARY=By.id("sanctionsLinksSummary");
	public static final By NTBR=By.id("ntbr");
	public static final By NTBR_RATIONALE=By.id("ntbrRationale");
	public static final By CDD_CLOSE=By.xpath("//a[@id='closeBtn']");
	public static final By CDD_SAVE=By.xpath("//*[text()='Save']");
	
	public static final By DORMANT_REACTIVATION=By.id("dormantReactivation");
	public static final By SENSITIVE_CLIENT=By.id("sensitiveClient");
	
	//Create Review checklist
	public static final By CREATEREVIEWCHECKLIST_WORKITEM=By.xpath("//td[@title='Review Checklist']");
	public static final By CREATE_REVIEW_CHECKLIST_FORM=By.xpath("//li[@title='Create Review Checklist']/a");
	public static final By REVIEW_CHECKS_LATEST_ALERT=By.xpath("//label[text()='[A+] Check if there is any other latest alert for the client?']/../select");
	public static final By ALERT_ID=By.id("cdev_trr_q0AlertId");
	public static final By ALERT_DATE=By.id("dateField_cdev_trr_q0AlertDate");
	public static final By ALERT_REMARKS=By.id("cdev_trr_q0Remarks");
	public static final By CLIENT_FULL_NAME_UPDATED=By.id("cdev_trr_q1");
	public static final By CLIENT_FULL_NAME_CURRENT_VALUE=By.id("cdev_trr_q1Current");
	public static final By CLIENT_FULL_NAME_UPDATED_VALUE=By.id("cdev_trr_q1Updated");
	public static final By CLIENT_FULL_NAME_REMARKS=By.id("cdev_trr_q1Remarks");
	public static final By FORMER_UPDATED=By.id("cdev_trr_q2");
	public static final By FORMER_CURRENT_VALUE=By.id("cdev_trr_q2Current");
	public static final By FORMER_UPDATED_VALUE=By.id("cdev_trr_q2Updated");
	public static final By FORMER_REMARKS=By.id("cdev_trr_q2Remarks");
	public static final By ID_DETAILS_UPDATED=By.id("cdev_trr_q3");
	public static final By ID_DETAILS_CURRENT_VALUE=By.id("cdev_trr_q3Current");
	public static final By ID_DETAILS_UPDATED_VALUE=By.id("cdev_trr_q3Updated");
	public static final By ID_DETAILS_REMARKS=By.id("cdev_trr_q3Remarks");
	public static final By NATIONALITY_UPDATED=By.id("cdev_trr_q4");
	public static final By NATIONALITY_CURRENT_VALUE=By.id("cdev_trr_q4Current");
	public static final By NATIONALITY_UPDATED_VALUE=By.id("cdev_trr_q4Updated");
	public static final By NATIONALITY_REMARKS=By.id("cdev_trr_q4Remarks");
	public static final By RESIDENTIAL_ADDRESS_UPDATED=By.id("cdev_trr_q5");
	public static final By RESIDENTIAL_ADDRESS_CURRENT_VALUE=By.id("cdev_trr_q5Current");
	public static final By RESIDENTIAL_ADDRESS_UPDATED_VALUE=By.id("cdev_trr_q5Updated");
	public static final By RESIDENTIAL_ADDRESS_REMARKS=By.id("cdev_trr_q5Remarks");
	public static final By CONTACT_UPDATED=By.id("cdev_trr_q6");
	public static final By CONTACT_URRENT_VALUE=By.id("cdev_trr_q6Current");
	public static final By CONTACT_UPDATED_VALUE=By.id("cdev_trr_q6Updated");
	public static final By CONTACT_REMARKS=By.id("cdev_trr_q6Remarks");
	public static final By DATE_OF_BIRTH_UPDATED=By.id("cdev_trr_q7");
	public static final By DATE_OF_BIRTH_URRENT_VALUE=By.id("cdev_trr_q7Current");
	public static final By DATE_OF_BIRTH_UPDATED_VALUE=By.id("cdev_trr_q7Updated");
	public static final By DATE_OF_BIRTH_REMARKS=By.id("cdev_trr_q7Remarks");
	public static final By COUNTRY_OF_BIRTH_UPDATED=By.id("cdev_trr_q8");
	public static final By COUNTRY_OF_BIRTH_URRENT_VALUE=By.id("cdev_trr_q8Current");
	public static final By COUNTRY_OF_BIRTH_UPDATED_VALUE=By.id("cdev_trr_q8Updated");
	public static final By COUNTRY_OF_BIRTH_REMARKS=By.id("cdev_trr_q8Remarks");
	public static final By A_ALERT_GENERATED=By.id("cdev_trr_q9");
	public static final By A_ALERT_GENERATED_REMARKS=By.id("cdev_trr_q9Remarks");
	public static final By A_CLIENT_PEP=By.id("cdev_trr_q10");
	public static final By A_CLIENT_REMARKS=By.id("cdev_trr_q10Remarks");
	public static final By C_PISE_TOOL=By.id("cdev_trr_q11");
	public static final By C_PISE_TOOL_REMARKS=By.id("cdev_trr_q11Remarks");
	public static final By A_ADVERSE_MEDIA_INFO=By.id("cdev_trr_q12");
	public static final By A_ADVERSE_MEDIA_INFO_REMARKS=By.id("cdev_trr_q12Remarks");
	public static final By A_ADVERSE_MEDIA_eFORM=By.id("cdev_trr_q13");
	public static final By A_ADVERSE_MEDIA_eFORM_REMARKS=By.id("cdev_trr_q13Remarks");
	public static final By C_CLIENT_ACCOUNT_ACTIVITY=By.id("cdev_trr_q14");
	public static final By C_CLIENT_ACCOUNT_ACTIVITY_REMARKS=By.id("cdev_trr_q14Remarks");
	public static final By A_CASA_ACCOUNT_OPENING_CONSITENT=By.id("cdev_trr_q141");
	public static final By A_CASA_ACCOUNT_OPENING_CONSITENT_REMARKS=By.id("cdev_trr_q141Remarks");
	public static final By A_CASA_FOR_BUSINESS=By.id("cdev_trr_q142");
	public static final By A_CASA_FOR_BUSINESS_REMARKS=By.id("cdev_trr_q142Remarks");
	public static final By A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT=By.id("cdev_trr_q143");
	public static final By A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT_REMARKS=By.id("cdev_trr_q143Remarks");
	public static final By C_SOWFORM_UPDATED=By.id("cdev_trr_q15");
	public static final By C_SOWFORM_UPDATED_REMARKS=By.id("cdev_trr_q15Remarks");
	public static final By C_HNW_TAX_FORM=By.id("cdev_trr_q16");
	public static final By C_HNW_TAX_FORM_REMARKS=By.id("cdev_trr_q16Remarks");
	public static final By A_ADDRESS_INVALID_INDICATOR=By.id("cdev_trr_q17");
	public static final By A_ADDRESS_INVALID_INDICATOR_REMARKS=By.id("cdev_trr_q17Remarks");
	public static final By A_CLIENT_INDUSTORY_APPEAR_VALID=By.id("cdev_trr_q18");
	public static final By A_CLIENT_INDUSTORY_APPEAR_VALID_INDUSTRY=By.id("cdev_trr_q18Remarks");
	public static final By A_CLIENT_JOB_APPEAR_VALID=By.id("cdev_trr_q19");
	public static final By A_CLIENT_JOB_APPEAR_VALID_OCC=By.id("cdev_trr_q19Remarks");
	public static final By A_CLIENT_FULL_NAME=By.id("cdev_trr_c1");
	public static final By A_CLIENT_FULL_NAME_NEWVAL=By.id("cdev_trr_c1NewValue");
	
	
	//New create checklist form -Start
	public static final By REVIEW_CHECKS_LATEST_ALERT_NEW=By.xpath("//select[@id='cdev_trr2_q1']");
	public static final By ALERT_ID_NEW=By.xpath("//input[@id='cdev_trr2_q1_alert_id']");
	public static final By ALERT_DATE_NEW=By.id("dateField_cdev_trr2_q1_alert_date");
	public static final By ALERT_REMARKS_NEW=By.id("cdev_trr2_q1_remarks");
	
	public static final By CLIENT_STATIC_DATA_INFO=By.xpath("//select[@id='cdev_trr2_q2']");
	public static final By CLIENT_STATIC_DATA_REMARKS=By.xpath("//*[@id='cdev_trr2_q2_remarks']");
	
	public static final By CLIENT_EMPLOYEEMENT_DETAILS=By.xpath("//select[@id='cdev_trr2_q3']");
	public static final By CLIENT_EMPLOYEEMENT_REMARKS=By.xpath("//*[@id='cdev_trr2_q3_remarks']");
	
	public static final By CLIENT_WORK_TYPE= By.xpath("//select[@id='cdev_trr2_q3a']");
	public static final By CLIENT_WORK_REMARKS=By.xpath("//*[@id='cdev_trr2_q3a_remarks']");

	public static final By CLIENT_OCCUPATION=By.xpath("//select[@id='cdev_trr2_q3b']");
	public static final By CLIENT_OCCUPATION_REMARKS=By.xpath("//*[@id='cdev_trr2_q3b_remarks']");

	public static final By CLIENT_INDUSTRY=By.xpath("//select[@id='cdev_trr2_q3c']");
	public static final By CLIENT_INDUSTRY_REMARKS=By.xpath("//*[@id='cdev_trr2_q3c_remarks']");
	
	public static final By CLIENT_INDICATOR_FLAG_ADDRESS=By.xpath("//select[@id='cdev_trr2_q4']");
	public static final By CLIENT_INDICATOR_FLAG_ADDRESS_REMARKS=By.xpath("//*[@id='cdev_trr2_q4_remarks']");
	
	public static final By CLIENT_UPDATE_IN_ICM=By.xpath("//select[@id='cdev_trr2_q5']");
	public static final By CLIENT_UPDATE_IN_ICM_REMARKS=By.xpath("//*[@id='cdev_trr2_q5_remarks']");

	public static final By FOR_A_RELEATED_PARTIES=By.xpath("//select[@id='cdev_trr2_q6']");
	public static final By FOR_A_RELEATED_PARTIES_REMARKS=By.xpath("//*[@id='cdev_trr2_q6_remarks']");
	
	public static final By FOR_A_PEP_RISK_EVENT=By.xpath("//select[@id='cdev_trr2_q7']");
	public static final By FOR_A_PEP_RISK_EVENT_REMARKS=By.xpath("//*[@id='cdev_trr2_q7_remarks']");
	
	public static final By FOR_A_ADVERSE_MEDIA_EVENT=By.xpath("//select[@id='cdev_trr2_q8']");
	public static final By FOR_A_ADVERSE_MEDIA_EVENT_REMARKS=By.xpath("//*[@id='cdev_trr2_q8_remarks']");
	
	public static final By FOR_C_SOW_REVIEW=By.xpath("//select[@id='cdev_trr2_q10']");
	public static final By FOR_C_SOW_REVIEW_REMARKS=By.xpath("//*[@id='cdev_trr2_q10_remarks']");
	
	public static final By FOR_C_INTERNET_SEARCH=By.xpath("//select[@id='cdev_trr2_q11a']");
	public static final By FOR_C_INTERNET_SEARCH_REMARKS=By.xpath("//*[@id='cdev_trr2_q11a_remarks']");
	
	public static final By FOR_C_NEW_RISK_FACTOR=By.xpath("//select[@id='cdev_trr2_q11b']");
	public static final By FOR_C_NEW_RISK_FACTOR_REMARKS=By.xpath("//*[@id='cdev_trr2_q11b_remarks']");
	
	
	public static final By FOR_C_CASA_ACCOUNTS=By.xpath("//select[@id='cdev_trr2_q12a']");
	public static final By FOR_C_CASA_ACCOUNTS_REMARKS=By.xpath("//*[@id='cdev_trr2_q12a_remarks']");
	
	public static final By FOR_C_BUSINESS_ACCOUNTS=By.xpath("//select[@id='cdev_trr2_q12b']");
	public static final By FOR_C_BUSINESS_ACCOUNTS_REMARKS=By.xpath("//*[@id='cdev_trr2_q12b_remarks']");
	
	public static final By FOR_C_CASA_CREDIT_TRANSACTION=By.xpath("//select[@id='cdev_trr2_q12c']");
	public static final By FOR_C_CASA_CREDIT_TRANSACTION_REMARKS=By.xpath("//*[@id='cdev_trr2_q12c_remarks']");
	
	
	public static final By FOR_C_CASA_EXPALNAITION_ON_CREDITS=By.xpath("//select[@id='cdev_trr2_q12d']");
	public static final By FOR_C_CASA_EXPALNAITION_ON_CREDITS_REMARKS=By.xpath("//*[@id='cdev_trr2_q12d_remarks']");
	
	public static final By FOR_C_ESCALATED_TO_CDD_ADVISOR=By.xpath("//select[@id='cdev_trr2_q12e']");
	public static final By FOR_C_ESCALATED_TO_CDD_ADVISOR_REMARKS=By.xpath("//*[@id='cdev_trr2_q12e_remarks']");
	
	
	public static final By FOR_C_HNW_TAX=By.xpath("//select[@id='cdev_trr2_q13']");
	public static final By FOR_C_HNW_TAX_REMARKS=By.xpath("//*[@id='cdev_trr2_q13_remarks']");
	
	
	
	public static final By FOR_C_UHNW_CLIENT=By.xpath("//select[@id='cdev_trr2_q14']");
	public static final By FOR_C_UHNW_CLIENT_REMARKS=By.xpath("//*[@id='cdev_trr2_q14_remarks']");
	
	
	public static final By FOR_C_SANCTIONED_CLIENT=By.xpath("//select[@id='cdev_trr2_q15']");
	public static final By FOR_C_SANCTIONED_CLIENT_REMARKS=By.xpath("//*[@id='cdev_trr2_q15_remarks']");
	
	
	public static final By FOR_C_SANCTIONED_CLIENT_ESCALATION=By.xpath("//select[@id='cdev_trr2_q16']");
	public static final By FOR_C_SANCTIONED_CLIENT_ESCALATION_REMARKS=By.xpath("//*[@id='cdev_trr2_q16_remarks']");
	
	public static final By CLIENT_CONTACT_ADVISED=By.xpath("//select[@id='cdev_trr2_q17']");
	public static final By CLIENT_CONTACT_ADVISED_REMARKS=By.xpath("//*[@id='cdev_trr2_q17_remarks']");
	
	
	// NEW create check list end
	
	public static final By A_CLIENT_FORMER=By.id("cdev_trr_c2");
	public static final By A_CLIENT_FORMER_NEWVAL=By.id("cdev_trr_c2NewValue");
	public static final By A_CLIENT_ID=By.id("cdev_trr_c3");
	public static final By A_CLIENT_ID_NEWVAL=By.id("cdev_trr_c3NewValue");
	public static final By A_CLIENT_NATIONALITY=By.id("cdev_trr_c4");
	public static final By A_CLIENT_NATIONALITY_NEWVAL=By.id("cdev_trr_c4NewValue");
	public static final By A_CLIENT_RESIDENTIAL_ADD=By.id("cdev_trr_c5");
	public static final By A_CLIENT_RESIDENTIAL_ADD_NEWVAL=By.id("cdev_trr_c5NewValue");
	public static final By A_CLIENT_ISD_PHONE=By.id("cdev_trr_c6");
	public static final By A_CLIENT_ISD_PHONE_NEWVAL=By.id("cdev_trr_c6NewValue");
	public static final By A_CLIENT_DOB=By.id("cdev_trr_c7");
	public static final By A_CLIENT_DOB_NEWVAL=By.id("cdev_trr_c7NewValue");
	public static final By A_CLIENT_COUNTRYOFBIRTH=By.id("cdev_trr_c8");
	public static final By A_CLIENT_COUNTRYOFBIRTH_NEWVAL=By.id("cdev_trr_c8NewValue");
	public static final By A_CLIENT_CHANGE_BUSINESS=By.id("cdev_trr_c12");
	public static final By A_CLIENT_CHANGE_BUSINESS_NEWVAL=By.id("cdev_trr_c12NewValue");
	public static final By A_CLIENT_NAMEOF_CURRENT_EMPLOYER=By.id("cdev_trr_c13");
	public static final By A_CLIENT_NAMEOF_CURRENT_EMPLOYER_REMARKS=By.id("cdev_trr_c13Remarks");
	public static final By A_CLIENT_CURRENT_WORKTYPE=By.id("cdev_trr_c14");
	public static final By A_CLIENT_CURRENT_WORKTYPE_REMARKS=By.id("cdev_trr_c14Remarks");
	public static final By A_CLIST_AND_ADVICE_THE_CLIENT=By.id("cdev_trr_c9");
	public static final By A_CLIENT_PROVIDE_EXPLANATION=By.id("cdev_trr_c10");
	public static final By A_CLIENT_RELEVANT_STATIC_DATA_REQ=By.id("cdev_trr_c11");
	public static final By A_CLIENT_USER_COMMENTS=By.id("cdev_trr_userComments");
	
	public static final By EXPORT_ICON=By.xpath("//a[@id='icon_export_a']");
	public static final By CREATE_RFI=By.xpath("//a[@id='icon_rfi_a']//following::a[contains(.,'Create RFI')]");
	public static final By VIEW_RFIS=By.xpath("//a[@id='icon_rfi_a']//following::a[contains(.,'View RFIs')]");
	public static final By PRINT_DETAILS=By.xpath("//a[@id='icon_export_a']//following::a[contains(.,'Print Details')]");
	public static final By SHOW_AS_PDF=By.xpath("//a[@id='icon_export_a']//following::a[contains(.,'Show as PDF')]");
	public static final By SEND_MAIL=By.xpath("//a[@id='icon_export_a']//following::a[contains(.,'Send Mail')]");
	public static final By VIEW_HISTORY=By.xpath("//a[contains(.,'More')]//following::a[contains(.,'View History')]");
	public static final By VIEW_NOTES=By.xpath("//a[@id='icon_view_notes_a']");
	public static final By QUICK_CHANGE_STEP=By.xpath("//a[contains(text(),'Next steps')]");
	public static final By PRINT_LIST=By.xpath("//a[@id='icon_export_a']//following::a[contains(.,'Print List')]");
	public static final By EXPORT=By.xpath("//a[@id='icon_export_a']//following::a[contains(.,'Export')]");
	public static final By RFI_ICON=By.xpath("//a[@id='icon_rfi_a']");
	


}
