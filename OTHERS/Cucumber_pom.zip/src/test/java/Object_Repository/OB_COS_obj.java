package Object_Repository;

import org.openqa.selenium.By;

public class OB_COS_obj {
	
//Mortgage Loan
	//Product details
	public static final By PRODUCT_CATEGORY=By.xpath("//select[@id='productCategory']");
	public static final By PRODUCT_TYPE=By.id("productType");
	public static final By CAMPAIGN_CODE=By.id("promotionCodeDisplayData");
	public static final By MORTGAGE_TYPE=By.id("mortgageTypeCode");
	public static final By MORTGAGE_SERVICES=By.id("mortgageServiceCode");
	public static final By ASSESSMENT_TYPE=By.id("assesmentType");
	public static final By BROKER_REFERRAL_FLAG=By.id("lbrokerReferralFlag");
	//property details
	public static final By PROPERTY_DETAILS_EXPAND=By.xpath("text()='Property Details'");
	public static final By PROPERTY_DETAILS_AVAILABLE=By.id("availPropertyFlag");
	public static final By PURCHASE_TYPE=By.id("purchaseTypeCode");
	public static final By USE_OF_PROPERTY=By.id("useOfProperty");
	public static final By PROPERTY_TYPE=By.id("propertyTypeCodeDisplayData");
	public static final By DEVELOPMENT=By.id("developmentCodeDisplayData");
	public static final By DEVELOPER_NAME=By.id("developerCodeDisplayData");
	public static final By GROSS_AREA=By.id("grossArea");
	public static final By NETORSALEABLE_AREA=By.id("netArea");
	public static final By PURCHASE_PRICE=By.id("purchasePrice");
	public static final By NET_PURCHASE_PRICE=By.id("netPurchasePrice");
	public static final By PROPERTY_DETAIL1=By.id("blockNo");
	public static final By PROPERTY_DETAIL2=By.id("buildingNo");
	public static final By PROPERTY_DETAIL3=By.id("pdStreet");
	public static final By PROPERTY_DETAIL4=By.id("district");
	public static final By AREA=By.id("areaCode");
	public static final By COUNTRY=By.id("propertyCountryCode");
	public static final By ZIPCODE=By.id("zipCode");
	public static final By APPURTENANCE=By.id("pdAppurtenance");
	public static final By CARPARKLEVEL=By.id("pdCarParkLevel");
	public static final By CARPARKSPACES=By.id("pdCarParkSpace");
	public static final By SUBSIDY_TYPE=By.id("subsidyType");
	public static final By CONFIRM_OR_DEALFLAG=By.id("lconfirmorDealFlag");
	public static final By DIRECT_DEAL_FLAG=By.id("ldirectDealFlag");
	public static final By LEASE_TERM_EXPIRY_DATE=By.id("pdleaseTermExpireDate");
	//Indicative Validation
	public static final By DATEOFVALUATION=By.id("jsLabelFormat");
	public static final By INDICATIVE_VALUATION_TYPE=By.xpath("//option[text()='-- Please Select --']/..");
	public static final By VALUATION_REF_NO=By.xpath("//label[text()='Valuation Reference Number:']/..//input");
	public static final By VALUATION_AMT_MORTGAGE_PROPERTY=By.xpath("//label[text()='Valuation Amount- Mortgaged property: ']/..//input");
	public static final By VALUATION_AMT_CARPARK1=By.xpath("//label[text()='Valuation Amount- Car Park1:']/..//input");
	public static final By VALUATION_AMT_CARPARK2=By.xpath("//label[text()='Valuation Amount- Car Park2:']/..//input");
	//Product Request
	public static final By PRODUCT_REQUEST=By.xpath("text()='Product Request'");
	public static final By LOAN_CURRENCY_CODE=By.id("currencyCode");
	public static final By REQUESTED_LOAN_AMT=By.id("appliedLoanAmount");
	public static final By REQUEST_TENURE=By.xpath("appliedTenor");
	public static final By FLOATING_LOAN_TYPE=By.xpath("text()='Product Request'");
	public static final By LOAN_PURPOSE=By.xpath("text()='Product Request'");
	public static final By INTEREST_RATE_TYPE=By.xpath("text()='Product Request'");
	public static final By LOAN_REPAYMENT_METHOD=By.xpath("text()='Product Request'");
	public static final By DRAWDOWN_DATE=By.xpath("text()='Product Request'");
	public static final By PRUDENTIAL_MEASURE_EXCEPTION_DSR=By.id("reasonForPMDSR");
	public static final By PRUDENTIAL_MEASURE_EXCEPTION_LTV=By.id("reasonForPMLTV");
	//Lock-In-Period
	public static final By LOCK_IN_PERIOD=By.xpath("text()='Lock-in Period'");
	//Co-Finance
	public static final By COFINANCE_CHECKBOX=By.id("coFinanceFlag");
	public static final By COFINANCE_LOANAMOUNT=By.id("coFinanceLoanAmount");
	public static final By LOAN_REPAYMENT_TENURE=By.name("loanRepaymentTenor");
	public static final By PAYMENT_HOLIDAY=By.name("paymentHoliday");
	public static final By INTEREST_TYPE=By.id("coFinanceInterestType");
	public static final By INTEREST_RATE=By.id("interestRate");
	//scheme_loan
	public static final By SCHEME_LOAN_FLAG=By.id("schemeLoanFlag");
	public static final By SCHEME_LOAN_TYPE_CODE=By.id("schemeLoanTypeCode");
	public static final By SCHEME_LOAN_CATEGORY=By.id("lschemeLoanCategory");
	public static final By SCHEME_LOAN_AMOUNT=By.id("schemeLoanAmount");
	public static final By SCHEME_LOAN_TENOR=By.id("schemeLoanTenor");
	public static final By SCHEME_LOAN_=By.id("schemeLoanIntRate");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
