package Object_Repository;

import org.openqa.selenium.By;

public class ICDD_WorkItem_Obj {

	public static final By ADDNOTE   					     = By.id("icon_add_notes");
	public static final By ADDNOTEDROP					     = By.xpath("//*[@id='noteModelPreDefinedNotes']");
	public static final By OKBUTTON        				     = By.id("textButton_addNoteDialog_SubmitButton");
	public static final By COMMENTS         			     = By.id("tinymce");
	public static final By CANCEL           			     = By.id("textButton_viewNotesPopup_OkButton");
	public static final By VIEWNOTE  					     = By.id("icon_view_notes");
	public static final By ALERTDETAILS_CHANGESTEP 			 = By.id("icon_change_step");
	public static final By ALERTDETAILS_CHANGESTEP_DROPDWN   = By.xpath("//*[@id='statusesSelectText']");
	public static final By ALERTSDETAIL_CHANGESTEP_TEXTFIELD = By.id("tinymce");
	public static final By FILNET_OPETIONS					 = By.xpath("//*[@id='toolbarActions-alerts.actions.titleadditionsHolder']/ul/li[3]/ul/li");
	public static final By ID_DOCUMENT_NUMBER				 = By.id("custNationalId");
    public static final By ACCOUNT_NUMBER 					 = By.id("accNumber");
    public static final By CARD_NUMBER						 = By.id("cardNumber");
    public static final By LOAN_NUMBER						 = By.id("loadNumber");
    public static final By CUSTOMER_TYPE					 = By.id("custType");
    public static final By PRODUCT					         = By.id("product");
    public static final By DOCUMENT_TYPE_OPTION				 = By.xpath("//*[@id='docType']/option");
    public static final By SEARCH_BUTTON			         = By.xpath("//td[text()='Search']");
    public static final By LOGINPAGE_USERNAME = By.id("j_username_1");
	public static final By LOGINPAGE_PASSWORD = By.id("j_password");
	public static final By LOGINPAGE_LOGIN = By.id("textButton_btnLogin");
	
	public static final By REPORT=By.xpath("//a[@rel='menu.menu.reports']");
	public static final By CUSTOMER_ALERT_BUTTON=By.xpath("//td[contains(text(),'Customer Alerts')]");
	public static final By CUSTOMER_ALERT=By.xpath("//td[text()='Customer Alerts']");
	public static final By WORKBENCH_MENU_TAB =By.xpath("//a[@rel='menu.menu.workitems']"); //By.xpath("//a[contains(text(), 'Workbench')]")
	public static final By WORKITEM=By.xpath("//a[@rel='menu.menu.alerts']");
	public static final By MYWORK_ITEM_DROPDOWN=By.xpath("//img[@src='images/rcm/panelContainer/Arrow_White.gif']");
	public static final By WORKITEMS_ALL_OPTIONS = By.xpath("//table[@id='dropDownMenuOps']//td//div[contains(@class,'clsMenuBaseSpan')]");
	public static final By ADD_ATTACHMENT=By.xpath("(//*[@id='icon_add_attachment_a']/i)[1]");
	public static final By Onboarding_CDD_A_Checker= By.xpath("//div[@id='item_3340']");
	public static final By VIEW_ATTACHMENT=By.xpath("(//*[@id='icon_view_attachment'])[1]");
	public static final By SEARCH=By.xpath("//input[@id='toolbarFilterTextArea']");
	public static final By RECENT_CREATED_ALERT=By.xpath("(//td[@class='ui-ellipsis clsGridUnreadRow'][@aria-describedby='alertsModel_alertId'])[1]//a");
	
	//public static final By REF_ID=By.xpath("//tr[@id='473861']/td[5]/span/a");
	public static final By REF_ID=By.xpath("//td[contains(@aria-describedby,'alertsModel_alertId')]");
	
	//public static final By REF_ID=By.cssSelector("#\34 73856 > td:nth-child(5)");
	
	public static final By RISK_LEVEL_RAING=By.xpath("//td[contains(@aria-describedby,'alertsModel_Risk Level')]");		
	public static final By ISSUE=By.xpath("//td[contains(@aria-describedby,'alertsModel_Issues')]");
	public static final By ISSUE_TYPE=By.xpath("(//td[contains(@aria-describedby,'alertsModel_alertTypeShortName')])[1]");
	public static final By HIGH_RISK_CLIENT = By.xpath("//td[text()='High Risk Client']");
	public static final By STEP=By.xpath("(//td[contains(@aria-describedby,'alertsModel_status')])[3]");
	
	public static final By PERFORM_CHECKING_LOW_RISK=By.xpath("//td[contains(@title,'Perform Checking - Low Risk')]");
	
	public static final By ALERT_FROM_PRIMARY_CLIENT=By.xpath("//tr[@id='473912']/td[1]");
	public static final By EXPANDICONFRAME = By.id("frmDetails");
    public static final By EXPANDICON = By.xpath("//img[@src='plugin?plugin=Customers&resource=views/new-look/images/expand_table.gif']");
	
	public static final By ASSIGN_TO_ME=By.xpath("//i[@id='icon_assign']");
	
	public static final By OK_BUTTON=By.xpath("//*[@id='textButton_changeAlertUser_SubmitButton']");

	public static final By ADDITIONAL_DATA_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[2]/tbody/tr[1]/td/img");
	public static final By ON_BOARDING_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[3]/tbody/tr[1]/td/img");
	public static final By CLIENT_RISK_RATING_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[4]/tbody/tr[1]/td/img");
	public static final By KEY_RISK_INDICATORS_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[6]/tbody/tr[1]/td/img");
	public static final By PREVIOUS_RISK_RATING_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[7]/tbody/tr[1]/td/img");
	public static final By FCC_RISK_EVENTS_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[8]/tbody/tr[1]/td/img");
	public static final By CRA_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[9]/tbody/tr[1]/td/img");
	public static final By PROHIBITION_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[10]/tbody/tr[1]/td/img");
	public static final By TRIGGER_REVIEW_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[11]/tbody/tr[1]/td/img");
	public static final By MANUAL_TRR_REAASONS_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[12]/tbody/tr[1]/td/img");
	public static final By SELF_RESTRICTION_CHK_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[13]/tbody/tr[1]/td/img");
	public static final By CARDS_RELATIONSHIP_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[14]/tbody/tr[1]/td/img");
	public static final By TRANSACTION_MONTHLY_HISTORY_PROFIL_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[15]/tbody/tr[1]/td/img");
	public static final By CONSTOMER_ADDRESSES_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[16]/tbody/tr[1]/td/img");
	public static final By CONSTOMER_PHONE_NO_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[17]/tbody/tr[1]/td/img");
	public static final By CONSTOMER_EMAIL_ADDRESSES_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[18]/tbody/tr[1]/td/img");
	public static final By DOCUMENTATION_AND_CERTIFICATION_TRACKING_EXPAND_BUTTON=By.xpath("//div[@id='panesData_caseDetailsTab']/table/tbody/tr/td/table[19]/tbody/tr[1]/td/img");
	
	public static final By Scroll=By.xpath("//*[@id='panesData_caseDetailsTab']");
	
	//public static final By WORKFLOW=By.cssSelector("li#workflowBtn.button.actimizeIconButton");
			//By.xpath("//li[contains(@title,'Workflow')]");
	public static final By WORKFLOW=By.id("workflowBtn");
	
	
	public static final By CHECK_DOCUMENT1=By.xpath("//td[contains(text(),'Check')]");
	public static final By CHECK_DOCUMENT2=By.xpath("////td[contains(text(),'Check')]");
	public static final By CHECK_DOCUMENT3=By.xpath("//td[@id='textButton_3936203_button']");
	
	public static final By next_step_for_submit=By.xpath("//*[@id='nextStatusesMenu']");
	//public static final By ALLOPTION_FOR_SUBMIT=By.xpath("//*[@id='nextStatusesMenu']//li");
	public static final By ALLOPTION_FOR_SUBMIT=By.xpath("//table[@id='toolsTable']//td//li[contains(@class,'actimizeIconButton quickNextStepEnabled')]");
	
	public static final By SUBMIT_APPROVAL=By.xpath("//ul[@id='nextStatusesMenu']/li[6]/a");
	
	public static final By DETAIL_BUTTON=By.xpath("//*[@id='detailsBtn']");
	public static final By ALERTDETAILS_ALERTSTEP = By.xpath("//td[contains(@class,'clsAlertStepLabel')]");
	//public static final By ALERTDETAILS_ALERTSTEP= By.xpath("//*[@id='alertTitlePanelTable']/tbody/tr/td[4]/span/table/tbody/tr/td");
	public static final By CDD_STATUS_PENDING=By.xpath("//*[@id='actimize_application_form']/table/tbody/tr/td/div/div/div/table[2]/tbody/tr[2]/td/table/tbody/tr[6]/td[3]");
	
	public static final By NEXT_STEP_FOR_APPROVE=By.xpath("//*[@id='nextStatusesMenuOpener']");
	public static final By ALLOPTION_FOR_APPROVE=By.xpath("//table[@id='toolsTable']//td//li[contains(@class,'actimizeIconButton quickNextStepEnabled')]");
	public static final By APPROVE_COMPLETE=By.xpath("//ul[@id='nextStatusesMenu']/li/a");
	public static final By CDD_STATUS=By.xpath("//*[@id='actimize_application_form']/table/tbody/tr/td/div/div/div/table[2]/tbody/tr[2]/td/table/tbody/tr[6]/td[3]");

	//
	public static final By WORKITEM_SEARCH=By.xpath("//input[@id='toolbarFilterTextArea']");
	public static final By WORKITEM_SEARCH_ID=By.id("toolbarFilterTextArea");
	public static final By WORKITEM_SEARCH_Name=By.name("quickFilterTextbox");
	
	
	public static final By ICDD_SEARCH_Name=By.name("CSN");
	public static final By ICDD_SEARCH_id=By.id("csn");
	public static final By ICDD_SEARCH_xPath=By.xpath("//input[@name='CSN']");
	
	public static final By ICDD_SEARCH_Lastname=By.xpath("//input[@id='lastName']");
	public static final By LastName_id=By.id("lastName");
	public static final By ICDD_SEARCH_name=By.name("lastName");
	
	public static final By ICDD_ID_Link=By.xpath("(//a[@class='customerLink'])[1]");
	
	public static final By ICDD_ID_text=By.xpath("(//*[text()='ICDD ID:'])[1]/../td[3]");
	public static final By ICDD_ID_text1=By.xpath("(//table[@class='inline '])[1]/tbody/tr[2]/td[3]");

	
	

	public static final By CUSTOMER_TAB=By.xpath("//*[@class='active menuTabs']/a");
	public static final By ALERTDETAILS_ASSIGNUSER_TEXTBOX = By.xpath("//input[@id='user_name']");
    public static final By ALERTSDETAIL_CLOSE_BUTTON = By.xpath("//td[contains(text(),'Close')]");
	public static final By ICCD_ID_SREACH=By.xpath("//*[text()='ICDD ID:']/../td[4]/input");
	
	
	public static final By SEARCH1_BUTTON=By.xpath("//*[text()='Search']");
	public static final By ICCD_ID_LINK=By.xpath("(//*[@class='clsGridCellFont']/span/a)[1]");
	public static final By ICCD_ID=By.xpath("(//*[text()='ICDD ID:'])[1]/../td[3]");
	public static final By CUSTOMER_NAME=By.xpath("//*[text()='Customer Name:']/../td[5]");
	public static final By RECORD_DATE=By.xpath("//*[text()='Record Date:']/../td[7]");
	public static final By CUSTOMER_SCRORE=By.xpath("//*[text()='Customer Score:']/../td[3]");
	public static final By RISK_RATING=By.xpath("//*[text()='Risk Rating:']/../td[5]");
	public static final By ALERT_LEVEL_STATUS=By.xpath("//*[text()='Alert Level Status:']/../td[7]");
	public static final By ONBOARDING_STATUS=By.xpath("//*[text()='Onboarding Status:']/../td[3]");
	public static final By APPLICATION_REASON=By.xpath("//*[text()='Application Cancel/Decline Reason:']/../td[5]");
	public static final By ICM_ID=By.xpath("//*[text()='ICM ID:']/../td[7]");
	public static final By CDD_STATUS1=By.xpath("//*[text()='CDD Status:']/../td[3]");
	public static final By NEXT_REVIEW_DATE=By.xpath("//*[text()='Next Review Date:']/../td[5]");
	public static final By TYPE=By.xpath("//*[text()='Type:']/../td[3]");
	public static final By RELATIONSHIP_ACTIVATION_DATE=By.xpath("//*[text()='Relationship Activation Date:']/../td[3]");
	public static final By RELATIONSHIP_CLODES_IND=By.xpath("//*[text()='Relationship Closed Ind:']/../td[3]");
	public static final By PARTY_REFERENCE_ID=By.xpath("//*[text()='Party Reference Id:']/../td[3]");
	public static final By RESIDENTIAL_ADDRESS=By.xpath("//*[text()='Residential Address:']/../td[5]");
	public static final By CITY=By.xpath("//*[text()='City:']/../td[5]");
	public static final By STATE=By.xpath("//*[text()='State:']/../td[5]");
	public static final By COUNTRY=By.xpath("//*[text()='Country:']/../td[5]");
	public static final By EMAIL=By.xpath("//*[text()='Email:']/../td[5]");
	public static final By DOB=By.xpath("//*[text()='DOB:']/../td[5]");
	public static final By CLOSED_DATE=By.xpath("//*[text()='Close Date:']/../td[5]");
	public static final By NATIONALITY=By.xpath("//*[text()='Nationality/Citizenship:']/../td[7]");
	public static final By FIN_NUM=By.xpath("//*[text()='FIN Num:']/../td[7]");
	public static final By EDUCATION=By.xpath("//*[text()='Education:']/../td[7]");
	public static final By PASSPORT_NUMBER=By.xpath("//*[text()='Passport Number:']/../td[7]");
	public static final By OCCUPATION=By.xpath("//*[text()='Occupation:']/../td[7]");
	public static final By SUB_SEGMENT=By.xpath("//*[text()='Sub-segment:']/../td[7]");
	public static final By CLIENT_TYPE=By.xpath("//*[text()='Client type:']/../td[7]");
	public static final By INDUSTRY=By.xpath("//*[text()='Industry:']/../td[7]");
	public static final By LAST_REVIEW_DATE=By.xpath("//*[text()='Last Review Date:']/../td[7]");
	
	
	public static final By PREVIOUS_NAME=By.xpath("//*[text()='Previous Name:']/../td[2]");
	public static final By NATIONALITY1  =By.xpath("//*[text()='Nationalities / Citizenships 1:']/../td[4]");
	public static final By SEGMENT=By.xpath("//*[text()='Segment:']/../td[6]");
	public static final By BRANCH_CODE=By.xpath("//*[text()='Branch code / Home branch:']/../td[8]");
	public static final By PREVIOUS_NAME2=By.xpath("//*[text()='Previous Name 2:']/../td[2]");
	public static final By NATIONALITY2=By.xpath("//*[text()='Nationalities / Citizenships 2:']/../td[4]");
	public static final By NATURE_OF_EMPLOYMENT=By.xpath("//*[text()='Nature of Employment (Customer Work Type):']/../td[6]");
	public static final By COUNTRY_OF_BIRTH=By.xpath("//*[text()='Country of Birth:']/../td[8]");
	public static final By ANY_OTHER_NAME_KNOWNBY1=By.xpath("//*[text()='Any other name known by:']/../td[2]");
	public static final By NATIONALITY3=By.xpath("//*[text()='Nationalities / Citizenships 3:']/../td[4]");
	public static final By ARM_CODE=By.xpath("//*[text()='ARM Code:']/../td[6]");
	public static final By US_RESIDENT=By.xpath("//*[text()='U.S. Resident?:']/../td[8]");
	public static final By ANY_OTHER_NAME_KNOWNBY2=By.xpath("//*[text()='Any other name known by 2:']/../td[2]");
	public static final By NATIONALITY4=By.xpath("//*[text()='Nationalities / Citizenships 4:']/../td[4]");
	public static final By NAME_OF_EMPLYER=By.xpath("//*[text()='Name of the Employer:']/../td[6]");
	public static final By US_PERMANENT_RESIDENT_CARD=By.xpath("//*[text()='Holder of a US Permanent Resident Card:']/../td[8]");
	public static final By CLIENT_NAME=By.xpath("//*[text()='Client Name (Product):']/../td[2]");
	public static final By NATIONALITY5=By.xpath("//*[text()='Nationalities / Citizenships 5:']/../td[4]");
	public static final By EMPLOYEE_ID=By.xpath("//*[text()='Employee ID / PWID:']/../td[6]");
	public static final By DECLARED_ANUUAL_INCOME=By.xpath("//*[text()='Declared Annual Income:']/../td[8]");
	public static final By CLIENT_STATUS=By.xpath("//*[text()='Client Status:']/../td[2]");
	public static final By ACQUISION_CHANNEL=By.xpath("//*[text()='Acquisition Channel:']/../td[4]");
	public static final By PRR_EXEMPTED=By.xpath("//*[text()='PRR Exempted:']/../td[6]");
	public static final By CASE_OWNER_ID=By.xpath("//*[text()='Case Owner Id:']/../td[8]");
	public static final By MINOR=By.xpath("//*[text()='Minor:']/../td[2]");
	public static final By FINAL_RISK_RATING=By.xpath("//*[text()='Final Risk Rating:']/../td[2]");
	public static final By REASON_FOR_RISK_RATING=By.xpath("//*[text()='Reason for Risk Rating:']/../td[4]");
	public static final By PROHIBITION=By.xpath("//*[text()='Prohibition:']/../td[6]");
	public static final By PROHIBITION_REASON=By.xpath("//*[text()='Prohibition Reason(s):']/../td[8]");
	public static final By CRA_RATING=By.xpath("//*[text()='CRA Rating:']/../td[2]");
	public static final By SEGMENT_COUNTRY_OVERRIDE=By.xpath("//*[text()='Segment/Country Override:']/../td[4]");
	public static final By JOINT_ACCOUNT_OVERRIDE=By.xpath("//*[text()='Joint-Account Override:']/../td[6]");
	public static final By RELATED_ENTRY_OVERRIDE=By.xpath("//*[text()='Related Entity Override:']/../td[8]");
	public static final By AUM_IN_USD=By.xpath("//*[text()='AUM in USD:']/../td[2]");
	public static final By AUM_IN_LCY=By.xpath("//*[text()='AUM in LCY:']/../td[4]");
	public static final By APPROVED_BORROWING_LIMIT_IN_USD= By.xpath("//*[text()='Approved Borrowing Limit in USD:']/../td[6]");
	public static final By APPROVED_BORROWING_LIMIT_IN_LCY= By.xpath("//*[text()='Approved Borrowing Limit in LCY:']/../td[8]");
	public static final By PEP_STATUS= By.xpath("//*[text()='PEP Status:']/../td[2]");
	public static final By PEP_CATEGORY=By.xpath("//*[text()='PEP Category:']/../td[4]");
	public static final By ADVERSE_MEDIA_STATUS=By.xpath("//*[text()='Adverse Media Status:']/../td[6]");
	public static final By SANCTION_STATUS= By.xpath("//*[text()='Sanction Status:']/../td[2]");
	public static final By CLIENT_NET_WORTH_TYPE= By.xpath("//*[text()='Client Net Worth Type:']/../td[4]");
	public static final By SOW_CORROBORATION=By.xpath("//*[text()='SOW Corroboration:']/../td[6]");
	public static final By NTBR=By.xpath("//*[text()='NTBR:']/../td[8]");
	public static final By ONBoarding_TYPES=By.xpath("//*[text()='On-Boarding Types']/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By PRODUCT_RISK=By.xpath("//*[text()='Product Risk']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By ACCOUNT_SERVICING=By.xpath("//*[text()='Account Servicing']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By BUSINESS_RISK=By.xpath("//*[text()='Business Risk']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By CROSS_BORDER_NON_RESIDENCY=By.xpath("//*[text()='Cross Border Non Residency']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By INCIDENCE_OF_FINANCIAL_CRIME=By.xpath("//*[text()='Incidence of Financial Crime']/../following-sibling::tr/following-sibling::tr/td[6]");
	public static final By SCB_COUNTRY=By.xpath("//*[text()='SCB Country']/../following-sibling::tr/following-sibling::tr/td[7]");
	public static final By PEP_STATUS1=By.xpath("//*[text()='PEP Status']/../following-sibling::tr/following-sibling::tr/td[8]");
	public static final By SANCTION_CONNECTIONS=  By.xpath("//*[text()='Sanctions Connections']/../following-sibling::tr/following-sibling::tr/td[9]");
	public static final By LENGTH_OF_RELATIONSHIP=By.xpath("//*[text()='Length of Relationship']/../following-sibling::tr/following-sibling::tr/td[10]");
	public static final By ADVERSE_INFORMATION=By.xpath("//*[text()='Adverse Information']/../following-sibling::tr/following-sibling::tr/td[11]");
	public static final By FCC_RISK_EVENT=By.xpath("//*[text()='FCC Risk Events']/../following-sibling::tr/following-sibling::tr/td[12]");
	public static final By QUALITY_OF_REGULATION=By.xpath("//*[text()='Quality of Regulation']/../following-sibling::tr/following-sibling::tr/td[13]");
	public static final By PROHIBITION_BASED_ON_STATIC_DATA=By.xpath("//*[text()='Direct prohibition based on available static data']/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By PROHIBITION_BASED_ON_NAME_SCREENING=By.xpath("//*[text()='Prohibition based on name screening']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By PROHIBITION_BASED_ON_MULTIPLE_SAR=By.xpath("//*[text()='Prohibition based on multiple SAR filed']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By PROHIBITION_BASED_ON_PROHIBITED_INDUSTRY=By.xpath("//*[text()='Prohibition based on prohibited Industry in SOW']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By PROHIBITION_BASED_ON_SOW=By.xpath("//*[text()='Prohibition based on SOW(Source of wealth)']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By COUNTRY_PROHIBITION=By.xpath("//*[text()='Country Prohibition']/../following-sibling::tr/following-sibling::tr/td[6]");
	public static final By PROHIBITION_BASED_ON_RISK_RATING=By.xpath("//*[text()='Prohibition Based on Risk Rating from CRA']/../following-sibling::tr/following-sibling::tr/td[7]");
	public static final By TRIGGER_IS_SAR=By.xpath("//*[text()='IS SAR']/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By TRIGGER_IS_NCT=By.xpath("//*[text()='IS NCT']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By TRIGGER_IS_DENY_BUSINESS=By.xpath("//*[text()='IS DENY BUSINESS']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By TRIGGER_IS_CONF_ADV_MEDIA=By.xpath("//*[text()='IS CONF ADV Media']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By TRIGGER_CHANGE_TO_HNW=By.xpath("//*[text()='Change to HNW/UHNW']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By RP_PROHIBITION=By.xpath("//*[text()='RP Prohibition']/../following-sibling::tr/following-sibling::tr/td[6]");
	public static final By RP_NAMESCREEN=By.xpath("//*[text()='RP NameScreen']/../following-sibling::tr/following-sibling::tr/td[7]");
	public static final By CHANGE_TO_NON_RESIDENCY=By.xpath("//*[text()='Change to Non-Resident']/../following-sibling::tr/following-sibling::tr/td[8]");
	public static final By SELF_RESTRICTION_BENF_OWNER=By.xpath("//*[text()='Benf Owner (>=25%) of an entity existing in SCB']/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By SELF_RESTRICTION_ADVERSE_MEDIA=By.xpath("//*[text()='Adverse media against the entity']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By SELF_RESRTICTION_UNDULY_COMPLEX=By.xpath("//*[text()='Unduly complex structure']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By SELF_RESTRICTION_SENSITIVE=By.xpath("//*[text()='Dealing in Prohibited / sensitive industry']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By SELF_RESTRICTION_HIGH_RISK_COUNTRY=By.xpath("//*[text()='Links to PEP from a Very High Risk Country']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By CUSTOMER_ADDRESS_TYPE=By.xpath("(//*[text()='Type'])[1]/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By CUSTOMER_ADDRESS=By.xpath("//*[text()='Address']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By CUSTOMER_COUNTRY=By.xpath("//*[text()='Country']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By CUSTOMER_STATE=By.xpath("//*[text()='State']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By CUSTOMER_PO_BOX=By.xpath("//*[text()='PO Box']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By CUSTOMER_POSTAL_CODE=By.xpath("//*[text()='Postal/Zip code']/../following-sibling::tr/following-sibling::tr/td[6]");
	public static final By CUSTOMER_RETURN_MAIL_FALG=By.xpath("//*[text()='Return mail flag (Address Invalid indicator)']/../following-sibling::tr/following-sibling::tr/td[7]");
	public static final By PHONE_TYPE=By.xpath("((//*[text()='Type'])[2]/../following-sibling::tr/following-sibling::tr/td[1])[1]");
	public static final By PHONE_TYPE1=By.xpath("((//*[text()='Type'])[2]/../following-sibling::tr/following-sibling::tr/td[1])[2]");
	public static final By ISD_CODE=By.xpath("(//*[text()='ISD Code']/../following-sibling::tr/following-sibling::tr/td[2])[1]");
	public static final By ISD_CODE1=By.xpath("(//*[text()='ISD Code']/../following-sibling::tr/following-sibling::tr/td[2])[2]");
	public static final By PHONE=By.xpath("(//*[text()='Phone']/../following-sibling::tr/following-sibling::tr/td[3])[1]");
	public static final By PHONE1=By.xpath("(//*[text()='Phone']/../following-sibling::tr/following-sibling::tr/td[3])[2]");
	public static final By EMAIL_ADDRESS_TYPE=By.xpath("((//*[text()='Type'])[3]/../following-sibling::tr/following-sibling::tr/td[1])[1]");
	public static final By EMAIL_ADDRESS_TYPE1=By.xpath("((//*[text()='Type'])[3]/../following-sibling::tr/following-sibling::tr/td[1])[2]");
	public static final By EMAIL_ADDRESS_EMAIL=By.xpath("(//*[text()='Email']/../following-sibling::tr/following-sibling::tr/td[2])[1]");
	public static final By EMAIL_ADDRESS_EMAIL1=By.xpath("(//*[text()='Email']/../following-sibling::tr/following-sibling::tr/td[2])[2]");
	public static final By DOCUMENT_REQUIRMENT=By.xpath("//*[text()='Requirement']/../following-sibling::tr/following-sibling::tr/td[1]");
	public static final By DOCUMENT_PRIORITY=By.xpath("//*[text()='Priority']/../following-sibling::tr/following-sibling::tr/td[2]");
	public static final By DOCUMENT_STATUS=By.xpath("//*[text()='Status']/../following-sibling::tr/following-sibling::tr/td[3]");
	public static final By DOCUMENT_DUE_DATE=By.xpath("//*[text()='Due Date']/../following-sibling::tr/following-sibling::tr/td[4]");
	public static final By DOCUMENT_TYPE=By.xpath("//*[text()='Document Type']/../following-sibling::tr/following-sibling::tr/td[5]");
	public static final By DOCUMENT_NUMBER=By.xpath("//*[text()='Document Number']/../following-sibling::tr/following-sibling::tr/td[6]");
	public static final By DOCUMENT_ISSUER=By.xpath("//*[text()='Issuer']/../following-sibling::tr/following-sibling::tr/td[7]");
	public static final By DOCUMENT_ISSUE_DATE=By.xpath("//*[text()='Issue Date']/../following-sibling::tr/following-sibling::tr/td[8]");
	public static final By DOCUMENT_ISSUE_COUNTRY=By.xpath("//*[text()='Issue Country']/../following-sibling::tr/following-sibling::tr/td[9]");
	public static final By DOCUMENT_EXPITY_DATE=By.xpath("//*[text()='Document Expiry Date']/../following-sibling::tr/following-sibling::tr/td[10]");
	public static final By DOCUMENT_ALTERNATIVE_APPLIED=By.xpath("//*[text()='Alternative Applied']/../following-sibling::tr/following-sibling::tr/td[11]");
	public static final By DOCUMENT_DETAILS=By.xpath("//*[text()='Details']/../following-sibling::tr/following-sibling::tr/td[12]");
	
	
	
	
	public static final By ACCOUNT_TYPE=By.xpath("//*[text()='Account Type']/../following-sibling::tr/td[1]");
	public static final By ACCOUNT_TYPE_DESCRIPTION=By.xpath("//*[text()='Account Type Description']/../following-sibling::tr/td[2]");
    public static final By NUMBER_OF_ACCOUNT=By.xpath("//*[text()='Number of Accounts']/../following-sibling::tr/td[3]");
	
    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT=By.xpath("(//*[text()='Client Relationship to Account:'])[1]/../td[3]");
	public static final By PRODUCT_fILED=By.xpath("(//*[text()='Product:'])[1]/../td[3]");
    public static final By ACCOUNT_OPENING_CHANNEL=By.xpath("(//*[text()='Account Opening Channel:'])[1]/../td[3]");
    public static final By FEDERAL_TAX=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[1]/../td[3]");
    public static final By ACCOUNT_OPEN_DATE=By.xpath("(//*[text()='Open Date:'])[1]/../td[3]");
    public static final By ACCOUNT_ACTIVE=By.xpath("(//*[text()='Account Active:'])[1]/../span[2]");
    public static final By ACCCOUNT_SUBPRODUCT=By.xpath("(//*[text()='Sub-product Code:'])[1]/../td[5]");
    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION=By.xpath("(//*[text()='Sub-product Description:'])[1]/../td[5]");
    public static final By ACCOUNT_BRANCH=By.xpath("(//*[text()='Branch:'])[1]/../td[5]");
    public static final By ACCOUNT_BRANCH_PHONE=By.xpath("(//*[text()='Branch Phone:'])[1]/../td[5]");
    public static final By ACCOUNT_OFFICER=By.xpath("(//*[text()='Officer#:'])[1]/../td[5]");
    public static final By ACCOUNT_OFFICER_NAME=By.xpath("(//*[text()='Officer Name:'])[1]/../td[5]");
    public static final By ACCOUNT_CURRENCY=By.xpath("(//*[text()='Account Currency'])[1]/../td[3]");
    public static final By PURPOSE_REASON_RELATIONSHIP=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[1]/../td[3]");
    public static final By INITIAL_FUNDING=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[1]/../td[3]");
    public static final By SOURCE_INITIAL_FUNDING=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[1]/../td[3]");
    public static final By ACCOUNT_NUMBER_fILED=By.xpath("(//*[text()='Account Number'])[1]/../td[5]");
    public static final By APPLIED_LIMIT=By.xpath("(//*[text()='Applied Limit (with currency)'])[1]/../td[5]");
    public static final By INITIAL_DEPOSIT=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[1]/../td[5]");
    public static final By COUNTRY_INITIAL_FUNDING=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[1]/../td[5]");
    public static final By ACCOUNT_STATUS=By.xpath("(//*[text()='Account Status'])[1]/../td[7]");    
    public static final By BORROWING_LIMIT=By.xpath("(//*[text()='Borrowing Limit (USD)'])[1]/../td[7]");
    public static final By TYPE_INITIAL_FUNDING=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[1]/../td[7]");
   
    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT2=By.xpath("(//*[text()='Client Relationship to Account:'])[2]/../td[3]");
	public static final By PRODUCT2=By.xpath("(//*[text()='Product:'])[2]/../td[3]");
    public static final By ACCOUNT_OPENING_CHANNEL2=By.xpath("(//*[text()='Account Opening Channel:'])[2]/../td[3]");
    public static final By FEDERAL_TAX2=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[2]/../td[3]");
    public static final By ACCOUNT_OPEN_DATE2=By.xpath("(//*[text()='Open Date:'])[2]/../td[3]");
    public static final By ACCOUNT_ACTIVE2=By.xpath("(//*[text()='Account Active:'])[2]/../span[2]");
    public static final By ACCCOUNT_SUBPRODUCT2=By.xpath("(//*[text()='Sub-product Code:'])[2]/../td[5]");
    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION2=By.xpath("(//*[text()='Sub-product Description:'])[2]/../td[5]");
    public static final By ACCOUNT_BRANCH2=By.xpath("(//*[text()='Branch:'])[2]/../td[5]");
    public static final By ACCOUNT_BRANCH_PHONE2=By.xpath("(//*[text()='Branch Phone:'])[2]/../td[5]");
    public static final By ACCOUNT_OFFICER2=By.xpath("(//*[text()='Officer#:'])[2]/../td[5]");
    public static final By ACCOUNT_OFFICER_NAME2=By.xpath("(//*[text()='Officer Name:'])[2]/../td[5]");
    public static final By ACCOUNT_CURRENCY2=By.xpath("(//*[text()='Account Currency'])[2]/../td[3]");
    public static final By PURPOSE_REASON_RELATIONSHIP2=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[2]/../td[3]");
    public static final By INITIAL_FUNDING2=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[2]/../td[3]");
    public static final By SOURCE_INITIAL_FUNDING2=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[2]/../td[3]");
    public static final By ACCOUNT_NUMBER2=By.xpath("(//*[text()='Account Number'])[2]/../td[5]");
    public static final By APPLIED_LIMIT2=By.xpath("(//*[text()='Applied Limit (with currency)'])[2]/../td[5]");
    public static final By INITIAL_DEPOSIT2=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[2]/../td[5]");
    public static final By COUNTRY_INITIAL_FUNDING2=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[2]/../td[5]");
    public static final By ACCOUNT_STATUS2=By.xpath("(//*[text()='Account Status'])[2]/../td[7]");    
    public static final By BORROWING_LIMIT2=By.xpath("(//*[text()='Borrowing Limit (USD)'])[2]/../td[7]");
    public static final By TYPE_INITIAL_FUNDING2=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[2]/../td[7]");
    
    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT3=By.xpath("(//*[text()='Client Relationship to Account:'])[3]/../td[3]");
	public static final By PRODUCT3=By.xpath("(//*[text()='Product:'])[3]/../td[3]");
    public static final By ACCOUNT_OPENING_CHANNEL3=By.xpath("(//*[text()='Account Opening Channel:'])[3]/../td[3]");
    public static final By FEDERAL_TAX3=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[3]/../td[3]");
    public static final By ACCOUNT_OPEN_DATE3=By.xpath("(//*[text()='Open Date:'])[3]/../td[3]");
    public static final By ACCOUNT_ACTIVE3=By.xpath("(//*[text()='Account Active:'])[3]/../span[2]");
    public static final By ACCCOUNT_SUBPRODUCT3=By.xpath("(//*[text()='Sub-product Code:'])[3]/../td[5]");
    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION3=By.xpath("(//*[text()='Sub-product Description:'])[3]/../td[5]");
    public static final By ACCOUNT_BRANCH3=By.xpath("(//*[text()='Branch:'])[3]/../td[5]");
    public static final By ACCOUNT_BRANCH_PHONE3=By.xpath("(//*[text()='Branch Phone:'])[3]/../td[5]");
    public static final By ACCOUNT_OFFICER3=By.xpath("(//*[text()='Officer#:'])[3]/../td[5]");
    public static final By ACCOUNT_OFFICER_NAME3=By.xpath("(//*[text()='Officer Name:'])[3]/../td[5]");
    public static final By ACCOUNT_CURRENCY3=By.xpath("(//*[text()='Account Currency'])[1]/../td[3]");
    public static final By PURPOSE_REASON_RELATIONSHIP3=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[3]/../td[3]");
    public static final By INITIAL_FUNDING3=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[3]/../td[3]");
    public static final By SOURCE_INITIAL_FUNDING3=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[3]/../td[3]");
    public static final By ACCOUNT_NUMBER3=By.xpath("(//*[text()='Account Number'])[3]/../td[5]");
    public static final By APPLIED_LIMIT3=By.xpath("(//*[text()='Applied Limit (with currency)'])[3]/../td[5]");
    public static final By INITIAL_DEPOSIT3=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[3]/../td[5]");
    public static final By COUNTRY_INITIAL_FUNDING3=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[3]/../td[5]");
    public static final By ACCOUNT_STATUS3=By.xpath("(//*[text()='Account Status'])[3]/../td[7]");    
    public static final By BORROWING_LIMIT3=By.xpath("(//*[text()='Borrowing Limit (USD)'])[3]/../td[7]");
    public static final By TYPE_INITIAL_FUNDING3=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[3]/../td[7]");
    
    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT4=By.xpath("(//*[text()='Client Relationship to Account:'])[4]/../td[3]");
	public static final By PRODUCT4=By.xpath("(//*[text()='Product:'])[4]/../td[3]");
    public static final By ACCOUNT_OPENING_CHANNEL4=By.xpath("(//*[text()='Account Opening Channel:'])[4]/../td[3]");
    public static final By FEDERAL_TAX4=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[4]/../td[3]");
    public static final By ACCOUNT_OPEN_DATE4=By.xpath("(//*[text()='Open Date:'])[4]/../td[3]");
    public static final By ACCOUNT_ACTIVE4=By.xpath("(//*[text()='Account Active:'])[4]/../span[2]");
    public static final By ACCCOUNT_SUBPRODUCT4=By.xpath("(//*[text()='Sub-product Code:'])[4]/../td[5]");
    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION4=By.xpath("(//*[text()='Sub-product Description:'])[4]/../td[5]");
    public static final By ACCOUNT_BRANCH4=By.xpath("(//*[text()='Branch:'])[4]/../td[5]");
    public static final By ACCOUNT_BRANCH_PHONE4=By.xpath("(//*[text()='Branch Phone:'])[4]/../td[5]");
    public static final By ACCOUNT_OFFICER4=By.xpath("(//*[text()='Officer#:'])[4]/../td[5]");
    public static final By ACCOUNT_OFFICER_NAME4=By.xpath("(//*[text()='Officer Name:'])[4]/../td[5]");
    public static final By ACCOUNT_CURRENCY4=By.xpath("(//*[text()='Account Currency'])[4]/../td[3]");
    public static final By PURPOSE_REASON_RELATIONSHIP4=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[4]/../td[3]");
    public static final By INITIAL_FUNDING4=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[4]/../td[3]");
    public static final By SOURCE_INITIAL_FUNDING4=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[4]/../td[3]");
    public static final By ACCOUNT_NUMBER4=By.xpath("(//*[text()='Account Number'])[4]/../td[5]");
    public static final By APPLIED_LIMIT4=By.xpath("(//*[text()='Applied Limit (with currency)'])[4]/../td[5]");
    public static final By INITIAL_DEPOSIT4=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[4]/../td[5]");
    public static final By COUNTRY_INITIAL_FUNDING4=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[4]/../td[5]");
    public static final By ACCOUNT_STATUS4=By.xpath("(//*[text()='Account Status'])[4]/../td[7]");    
    public static final By BORROWING_LIMIT4=By.xpath("(//*[text()='Borrowing Limit (USD)'])[4]/../td[7]");
    public static final By TYPE_INITIAL_FUNDING4=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[4]/../td[7]");
    public static final By CLIENT_RELATIONSHIPTO_ACCOUNT5=By.xpath("(//*[text()='Client Relationship to Account:'])[5]/../td[3]");
	
    public static final By PRODUCT5=By.xpath("(//*[text()='Product:'])[5]/../td[3]");
    public static final By ACCOUNT_OPENING_CHANNEL5=By.xpath("(//*[text()='Account Opening Channel:'])[5]/../td[3]");
    public static final By FEDERAL_TAX5=By.xpath("(//*[text()='Federal Tax Withholding Code:'])[5]/../td[3]");
    public static final By ACCOUNT_OPEN_DATE5=By.xpath("(//*[text()='Open Date:'])[5]/../td[3]");
    public static final By ACCOUNT_ACTIVE5=By.xpath("(//*[text()='Account Active:'])[5]/../span[2]");
    public static final By ACCCOUNT_SUBPRODUCT5=By.xpath("(//*[text()='Sub-product Code:'])[5]/../td[5]");
    public static final By ACCOUNT_SUBPRODUCT_DESCRIPTION5=By.xpath("(//*[text()='Sub-product Description:'])[5]/../td[5]");
    public static final By ACCOUNT_BRANCH5=By.xpath("(//*[text()='Branch:'])[5]/../td[5]");
    public static final By ACCOUNT_BRANCH_PHONE5=By.xpath("(//*[text()='Branch Phone:'])[5]/../td[5]");
    public static final By ACCOUNT_OFFICER5=By.xpath("(//*[text()='Officer#:'])[5]/../td[5]");
    public static final By ACCOUNT_OFFICER_NAME5=By.xpath("(//*[text()='Officer Name:'])[5]/../td[5]");
    public static final By ACCOUNT_CURRENCY5=By.xpath("(//*[text()='Account Currency'])[5]/../td[3]");
    public static final By PURPOSE_REASON_RELATIONSHIP5=By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[5]/../td[3]");
    public static final By INITIAL_FUNDING5=By.xpath("(//*[text()='Amount of Initial Funding/Deposit (with currency)'])[5]/../td[3]");
    public static final By SOURCE_INITIAL_FUNDING5=By.xpath("(//*[text()='Source(s) of Initial Funding/Deposit'])[5]/../td[3]");
    public static final By ACCOUNT_NUMBER5=By.xpath("(//*[text()='Account Number'])[5]/../td[5]");
    public static final By APPLIED_LIMIT5=By.xpath("(//*[text()='Applied Limit (with currency)'])[5]/../td[5]");
    public static final By INITIAL_DEPOSIT5=By.xpath("(//*[text()='Amount of Initial Deposit (USD)'])[5]/../td[5]");
    public static final By COUNTRY_INITIAL_FUNDING5=By.xpath("(//*[text()='Country(s) of Initial Funding/Deposit'])[5]/../td[5]");
    public static final By ACCOUNT_STATUS5=By.xpath("(//*[text()='Account Status'])[5]/../td[7]");    
    public static final By BORROWING_LIMIT5=By.xpath("(//*[text()='Borrowing Limit (USD)'])[5]/../td[7]");
    public static final By TYPE_INITIAL_FUNDING5=By.xpath("(//*[text()='Type(s) of Initial Funding/Deposit'])[5]/../td[7]");
    
    
    public static final By INITIATE_TRIGGER_REVIEW = By.xpath("//table[@title=' Initiate Trigger Review']//td[2]");
	public static final By TRIGGER_REASON = By.id("note");
	public static final By MANUAL_TRIGGER_CONFIRM = By.xpath("//div[text()='Confirms']");
	public static final By INITIATE_PERIODIC_REVIEW = By.xpath("//td[text()='Review Customer']");
	public static final By PERIODIC_REVIEW_CONFIRM = By.xpath("//div[text()='Confirm']");
	//public static final By GET_PERIODIC_ALERT = By.xpath("//div[@id='resultPrev']//a");
	public static final By GET_PERIODIC_ALERT = By.xpath("//td[@id='alertIdsList']//a");
	public static final By PERIODIC_ALERT_CLOSE_BUTTON = By.xpath("//td[text()='Close']");
	
	public static final  By LOGOUT_USERDRPDOWN =By.xpath("//a[@class='user_menu_header_a' or @id='user_menu_header_a']");
	public static final  By LOGOUT_LOGOUTLINK= By.xpath("//*[@id='logoutUserLink']");//By.id("logoutUserLink");
	
	
	
	
	
	
	
	
	
}
