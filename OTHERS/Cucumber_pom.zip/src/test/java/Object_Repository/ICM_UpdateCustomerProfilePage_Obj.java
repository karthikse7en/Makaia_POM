package Object_Repository;

import org.openqa.selenium.By;

public class ICM_UpdateCustomerProfilePage_Obj {

	public static final By BANKID=By.xpath("//input[@id='bankid']");
	public static final By PASSWORD=By.xpath("//input[@id='password1']");
	public static final By LOGIN=By.xpath("//input[@value='LOG IN']");
	public static final By ICM_EXPAND=By.xpath("//b[text()='ICM']");
	public static final By ENQUIRY=By.xpath("//b[text()='Enquiry']");
	public static final By PROFILE_ACTION=By.xpath("//b[text()='ProfileAction']");
	public static final By UPDATE_PROFILE=By.xpath("(//span[text()='Update Profile'])[1]");
	public static final By UPDATE_BUTTON=By.xpath("//span[text()='Update']");
	public static final By RISK_REALTION_NO=By.xpath("(//*[@name='relno'])[1]");
	public static final By PROFILE_ENQUIRY=By.xpath("//span[text()='Profile Enquiry']");
	public static final By ICM_ID=By.name("icmId");
	public static final By ENQUIRY_SUBMIT=By.xpath("//button/span[text()='Submit']");
	public static final By PROFILE_ENQUIRY_BASIC=By.xpath("(//span[text()='Basic'])[2]");
	
	//Basic Tab
	public static final By BASIC_ICN_ID=By.xpath("//input[@name='profileId']");
	public static final By BASIC_RELATIONSHIP_NO=By.name("relationshipNo");
	public static final By BASIC_STATUS=By.xpath("(//*[@name='status'])[1]");
	public static final By BASIC_REOPEN_COUNTER=By.xpath("//input[@aria-label='ReopenCounter']");
	public static final By BASIC_REOPEN_REASON_CODE=By.xpath("(//*[@name='closeReasonCode'])[2]");
	public static final By BASIC_DEDUPE_NUMBER=By.xpath("//*[@name='dedupNumber']");
	public static final By BASIC_DEDUPE_REASON=By.xpath("//input[@name='dedupReasonCode']");
	public static final By BASIC_DESDUPE_COMMENT=By.xpath("//input[@name='dedupComments']");
	public static final By BASIC_CLOSE_INITIATED_BY=By.xpath("//*[@name='closeInitiatedBy']/md-radio-button");
	public static final By BASIC_PROFILE_CLOSED_DATE=By.xpath("//*[@name='profileClosedDate']");
	public static final By BASIC_PROFILE_TYPE=By.xpath("(//*[@name='profileType'])[1]");
	public static final By BASIC_TITLE=By.xpath("(//input[@aria-label='Title'])[2]");
	public static final By BASIC_FIRST_NAME=By.xpath("//input[@name='firstName']");
	public static final By BASIC_MIDDLE_NAME=By.xpath("//input[@id='middleName']");
	public static final By BASIC_LAST_NAME=By.xpath("//input[@id='lastName']");
	public static final By BASIC_FULL_NAME=By.xpath("//input[@name='fullName']");
	public static final By BASIC_ALIAS=By.xpath("//input[@name='AliasName0']");
	public static final By BASIC_GENDER=By.xpath("//*[@name='gender' and @ng-model='customerProfile.gender']");
	public static final By BASIC_DATEOFBIRTH=By.xpath("//input[@name='dateOfBirth']");
	public static final By BASIC_NATIONALITY=By.xpath("(//input[@name='customerNationalityCode'])[2]");
	public static final By BASIC_DATE_OF_BIRTH=By.xpath("//input[@name='dateOfBirth']");
	public static final By BASIC_COUNTRY_OF_BIRTH=By.xpath("(//input[@name='birthCountry'])[2]");
	public static final By BASIC_PREFERRED_STATEMENT_LANG=By.xpath("(//input[@name='prefStmtLang'])[2]");
	public static final By BASIC_QUALIFICATION=By.xpath("(//input[@name='qualificationCode' and @ng-model='tempCustProfl.qualification'])[2]");
	public static final By BASIC_MARITAL_STATUS=By.xpath("(//input[@name='maritalStatus' and @aria-label='maritalStatus'])[2]");
	public static final By BASIC_TAX_RESIDENCY_STATUS=By.xpath("//*[@name='taxResidencyStatus' and @ng-model='customerProfile.taxResidentStatus']");
	public static final By BASIC_REDIDENCE_COUNTRY=By.xpath("//input[@name='residentCountry' and @ng-model='customerProfile.residentCountry']");
	public static final By BAISC_IS_MINOR=By.xpath("//*[@name='isMinor']/div[2]");
	public static final By BASIC_GROUP_ID=By.xpath("//input[@name='groupId' and @ng-model='customerProfile.groupID']");
	public static final By BASIC_PLACE_OF_BIRTH=By.xpath("//input[@name='placeofbirth' and @ng-model='customerProfile.placeOfBirth']");
	public static final By BASIC_LANG_PREFERRED_COMMUMNICATION=By.xpath("(//input[@name='prefLangForComm' and @ng-model='tempCustProfl.prefLangForComm'])[2]");
	public static final By BASIC_NO_OF_DEPENDANT=By.xpath("//input[@name='noOfDependent' and @ng-model='customerProfile.noOfDependent']");
	public static final By BASIC_GST_RESIDENCE_STATUS=By.xpath("//*[@name='gstResidentStatus' and @ng-model='customerProfile.gstResidentStatus']");
	public static final By BASIC_RESIDNECE_STATUS=By.xpath("//*[@name='closeInitiated' and @ng-model='customerProfile.residentStatus']/md-radio-button");
	public static final By BASIC_SENIOR_CITIZEN=By.xpath("//*[@name='seniorCitizen']/div[1]");
	public static final By BASIC_GROUP_NAME=By.xpath("//*[@name='groupName']");
	public static final By TOTAL_RESIDENCE_STATUS=By.xpath("//*[@id='tab-content-0']//div[19]/div//md-radio-group/md-radio-button");
	
	public static final By BASIC_ALIAS_TOTAL_ROWS=By.xpath("//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div/div");
	public static final By BASIC_ALIAS_TOTAL_CLOUMN=By.xpath("//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div[2]/div/div");
	
	
	
	
	
	public static final By ADDRESS_TAB=By.xpath("(//span[text()='Address'])[1]");
	public static final By ADDRESS_NO_OF_ROWS=By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr");
	public static final By ADDRESS_TYPE=By.xpath("//input[@id='id_addressType']");
	public static final By ADDRESS_ADDRESS_LINE1=By.xpath("//input[@name='address1']");
	public static final By ADDRESS_ADDRESS_LINE2=By.xpath("//input[@name='address2']");
	public static final By ADDRESS_ADDRESS_LINE3=By.xpath("//input[@name='address3']");
	public static final By ADDRESS_LANDMARK=By.xpath("//input[@name='landMark']");
	public static final By ADDRESS_CITY=By.xpath("//input[@name='cityName']");
	public static final By ADDRESS_STATE=By.xpath("//input[@name='state']");
	public static final By ADDRESS_POSTAL_CODE=By.xpath("//input[@name='postalCode']");
	public static final By ADDRESS_COUNTRY_CODE=By.xpath("//input[@name='countryCode']");
	public static final By ADDRESS_CLASSCIFICATION=By.xpath("//input[@id='id_addressClassification']");
	public static final By ADDRESS_MAILING_ADDRESS=By.xpath("//*[@name='mailAddrInd']/div/md-radio-button");
	public static final By ADDRESS_POA_DOCUMENT=By.xpath("//input[@name='poaDoc']");
	public static final By ADDRESS_INVALID_INDICATOR=By.xpath("//*[@name='isWAUFlag']/div/md-radio-button");
	public static final By ADDRESS_RETURN_MAIL_COUNTER=By.xpath("//input[@name='returnMailCounter']");
	public static final By ADDRESS_UPDATE_COMMUNICATION_REASON_CODE=By.xpath("//input[@id='reasonCode']");
	
	
	public static final By CONTACT_TAB=By.xpath("(//span[text()='Contact'])[1]");
	public static final By CONTACT_DETAILS_TABLE_ROW=By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr");
	public static final By CONTACT_TYPE1=By.xpath("//input[@name='contactTypeCode']");
	public static final By CONTACT_COUNTRY_ISD=By.xpath("//input[@name='nm_isdcode']");
	public static final By CONTACT_MOB=By.xpath("//input[@name='mobileno']");
	public static final By CONTACT_COOMUNICATION=By.xpath("//input[@name='contactClassificationCode']");
	public static final By CONTACT_PRIMARY_CONTACT=By.xpath("//*[@name='primaryContact']/div/md-radio-button");
	public static final By CONTACT_INVALID_INDICATOR=By.xpath("//*[@name='contactInvalid']/div/md-radio-button");
	public static final By CONTACT_EMAIL=By.xpath("//*[@name='reference']");
	public static final By CONTACT_TELEPHONE=By.xpath("//*[@name='telephone']");
	public static final By SEGMENT=By.xpath("//*[@name='segmentCode']");
    public static final By SUB_SEGMENT=By.xpath("//*[@name='customerSegmentCode']");
	
	public static final By DOCUMENT_TAB=By.xpath("(//span[text()='Document'])[1]");
	public static final By DOCUMENT_DETAILS_COLUMN=By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[3]//tbody/tr[1]/td");
	public static final By DOCUMENT_DETAILS_ROW=By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[3]//tbody/tr");
	public static final By DOCUMENT_NUMBER=By.xpath("(//input[@name='documentNumber'])[1]");
	public static final By DOCUMENT_EXPITYDATE=By.xpath("(//input[@name='expiryDate'])[1]");
	public static final By DOCUMENT_SIGNATORYDATE=By.xpath("(//input[@name='signatorydate'])[1]");
	
	public static final By LOGOUT=By.xpath("//*[text()=' Logout']");
	public static final By YES_BUTTON=By.xpath("//*[@id='body']/div[4]/md-dialog/form/md-dialog-actions/button[1]/span");
	public static final By OK_ALERT_BUTTON=By.xpath("//*[contains(text(),'OK')]");
	public static final By QUEQUES=By.xpath("//b[text()='Queues']");
	public static final By CHECKEER_QUEQUES=By.xpath("//span[text()='Checker Queue']");
	public static final By UPDATE_COSTOMER_PROFILE=By.xpath("//*[text()='Update Customer Profile']");
	public static final By SEARCH_FILTER=By.xpath("//*[@ng-model='searchFilter']");
	public static final By APPROVE_BUTTON=By.xpath("//*[@id='customerProfileBody']/div[3]/button");
	
	public static final By EMPLOYMENT_AND_WEALTH=By.xpath("(//span[text()='Employment & Wealth'])[1]");
	public static final By EMPLOYMENT_TOTOL_ROWS=By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr");
	public static final By EMPLOYMENT_DETAILS=By.xpath("//*[@id='tab-content-4']//form/div[1]//table[1]//tbody/tr/td");
	public static final By EMPLOYMENT_INCOME=By.xpath("//*[@id='tab-content-4']//form/div[2]//table//tbody/tr[1]/td");
	public static final By EMPLOYMENT_NAME_TOTOL_ROWS=By.xpath("//*[@id='tab-content-4']//div[1]/md-content/md-card//table[2]//tbody/tr");
	public static final By EMPLOYMENT_NAME_TOTOL_COLUMN=By.xpath("//*[@id='tab-content-4']//div[1]/md-content/md-card//table[2]//tbody/tr/td//md-input-container//input");
	public static final By EMPLOYMENT_INCOME_TOTAL_ROWS=By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr");
	public static final By EMPLOYMENT_WEALTH_TOTAL_ROWS=By.xpath("//*[@id='tab-content-4']/div//div[3]/md-content/md-card//table[1]/tbody/tr");
	public static final By EMPLOYMENT_WEALTH_TOTAL_ROWS1=By.xpath("//*[@id='tab-content-4']/div/md-content//div[3]//md-card-content/table[2]/tbody/tr");
	public static final By EMPLOYMENT_WEALTH_ASSET_TOTAL_ROWS=By.xpath("//*[@id='tab-content-4']/div/md-content/div/form/div[4]/div/table//tbody/tr");
	public static final By EMPLOYMENT_CLIENT_INVESMENT_RADIO_BUTTON=By.xpath("//*[@id='tab-content-4']/div/md-content/div/form/div[3]//table[1]/tbody/tr/td[4]/font/md-input-container/md-radio-group//md-radio-button");
	public static final By EMPLYMENT_CLIENT_OVERSEAS_RADIO_BUTTON=By.xpath("//*[@id='tab-content-4']/div/md-content/div/form/div[3]//table[2]/tbody/tr/td[4]/font/md-input-container/md-radio-group//md-radio-button");
	public static final By EMPLOYEMNT_VULNERABLECUSTOMER=By.xpath("(//*[@id='tab-content-4']/div/md-content/div/form/div[3]/md-content/md-card/md-card-content/table[3]//tbody//md-radio-button");
	public static final By EMPLOYMENT_VULNERABLE_CUSTOMER_ROWS=By.xpath("//*[@id='tab-content-4']/div/md-content/div/form/div[3]/md-content/md-card/md-card-content/table[3]//tbody/tr");
	
	public static final By FATCA_TAB=By.xpath("(//span[text()='FATCA'])[1]");
	public static final By US_RESIDENT=By.xpath("//*[@name='usResident']/div[1]/div/md-radio-button[1]/div/div[1]");
	public static final By US_CITIZEN=By.xpath("//*[@name='usCitizen']//md-radio-button[1]/div/div[1]");
	public static final By GREEN_CARD_HOLDER=By.xpath("//*[@name='usGreenCardHolder']//md-radio-button/div/div[1]");
	public static final By US_INDICIA_INDENFIER=By.xpath("//*[@id='FATCA']//div[1]/div[1]/md-card//div[5]/div[2]//md-radio-group/div/div/md-radio-button/div/div[1]");
	public static final By US_PERSON_INDICATOR=By.xpath("//*[@id='FATCA']//div[1]/div[1]/md-card//div[6]/div[2]//md-radio-group/div/div/md-radio-button/div/div[1]");
	public static final By REPORT_TO_IRS_INDICATOR=By.xpath("//*[@id='FATCA']//div[1]/div[1]/md-card//div[7]/div[2]//md-radio-group/div/div/md-radio-button/div/div[1]");
	public static final By WITHHOLD_FOR_FATCA_INDICATOR=By.xpath("//*[@id='FATCA']//div[1]/div[1]/md-card//div[8]/div[2]//md-radio-group/div/div/md-radio-button/div/div[1]");
	public static final By RECALCITRANT_FLAG=By.xpath("//*[@id='FATCA']//div[1]/div[2]/md-card//div[1]/div[2]//md-radio-group/div/div/md-radio-button/div/div[1]");
	public static final By RECALCITRANT_IND_ASSIGN_DATE=By.xpath("//input[@name='recalcitrantIndAssignDt']");
	public static final By RECALCITRANT_IND_CLEARED_DATE=By.xpath("//input[@name='recalcitrantIndClearedDt']");
	public static final By ENHANCE_REVIEW_START_DATE=By.xpath("//input[@name='enhancedReviewStartDt']");
	public static final By ENHANCE_REVIEW_END_DATE=By.xpath("//input[@name='enhancedReviewEndDt']");
	public static final By DUE_FROM_DATE=By.xpath("//input[@name='documentDueDt']");
	public static final By US_INDICIA_LAST_UPDATED_DATE=By.xpath("//*[@aria-label='usaIndiciaData']");
	public static final By US_PERSON_LAST_UPDATE_DATE=By.xpath("//*[@aria-label='usaPersonData']");
	public static final By ENHANCE_REVIEW=By.xpath("//*[@id='FATCA']//div[1]/div[2]//div[4]/div[2]//md-radio-group/div/div/md-radio-button/div[1]");
	public static final By FATCA_DOCUMENT_SUBMITED=By.xpath("//*[@id='FATCA']//div[1]/div[2]//div[7]/div[2]//md-radio-group/div/div/md-radio-button/div[1]");
	
	
	
	
	
	public static final By PROFILE_ENQUIRY_CDD=By.xpath("(//span[text()='CDD'])[1]");
	public static final By CDD_REVIEWED_FLAG=By.xpath("(//*[@name='addrAmendAlertInd'])[2]//md-radio-button/div/div[1]");
	public static final By CDD_RISK_CODE=By.id("cddRiskCode");
	public static final By CDD_STATUS=By.xpath("//input[@name='cddReviewStatus']");
	public static final By CDD_REMARK=By.xpath("//input[@name='cddReason']");
	public static final By CDD_LAST_REVIEW_DATE=By.xpath("//input[@ng-model='formData.cdd.cddLastReviewDt ']");
	public static final By CDD_LAST_REVIEW_BY=By.xpath("//input[@aria-label='cddLastReviedBy ']");
	public static final By CDD_NEXT_REVIEW_DATE=By.xpath("//input[@ng-model='formData.cdd.cddNextReviewDt ']");
	public static final By SDD_ELIGIABLE_DATE=By.xpath("//input[@ng-model='formData.cdd.sddEligibleDate ']");
	public static final By RISK_RATING_DATE=By.xpath("//input[@ng-model='formData.cdd.cddRiskRatingDate ']");
	
	
	public static final By PROFILE_ENQUIRY_RISK=By.xpath("(//span[text()='Risk'])[1]");
	public static final By RISK_CODE_TABLE_ROWS=By.xpath("(//*[@class='table'])[3]//tbody/tr");
	public static final By RISK_CODE_TABLE_COLUME=By.xpath("((//*[@class='table'])[3]//tr[1])[1]/th");
	
	
	
	
	public static final By SYSTEM_CROSS_REFERENCE=By.xpath("//a[text()='System Cross Reference']");
	public static final By CDD_SYSTEM_ID=By.xpath("//td[@ng-bind='system.id.extSystemReferenceId']");
	public static final By PROFILE_ENQUIRY_CROSS_REFRENCE=By.xpath("(//span[text()='Cross Reference'])[1]");
	public static final By CROSS_REFERENCE_MORE_DETAILS=By.xpath("//a[text()='More Details']");
	//public static final By ACCOUNT_NUMBER=By.xpath("//input[@id='id_accno']");
	
	
	
	
	public static final By ACCOUNT_NUMBER=By.xpath("//*[@id='id_accno']");
	public static final By OK_BUTTON=By.xpath("//button[@ng-click='answer()']");
	
	
	
	public static final By PROFILE_DORMANCY_RISK=By.xpath("//span[text()='Profile Dormancy Risk']");
	public static final By INTERNAL=By.xpath("//span[text()='Internal']");
	public static final By ARMCODE=By.id("id_arm");
	public static final By SEGMENTCODE=By.id("id_segment");
	public static final By SUBSEGMENTCODE=By.xpath("//*[@id='id_subsegment']");
	public static final By SERVICEINDICATORCODE=By.xpath("//*[@id='id_servindicator']");
	public static final By IBANKINGINDICATOR=By.id("id_ibankingflag");
	public static final By PHONEBANKINGINDICATOR=By.id("id_phonebankingflag");
	public static final By REFERRALID=By.id("id_referralId");
	public static final By SOURCINGID=By.id("id_sourcingId");
	public static final By CLOSINGID=By.id("id_segment");
	public static final By POPUPOK=By.xpath("//*[@id='body']/div[4]/md-dialog/form/md-dialog-actions/button/span");
	public static final By SMSBANKINGINDICATOR=By.xpath("(//*[@id='tab-content-9']//div[3]//div[1]/div/div//md-radio-group/div/md-radio-button)");
	public static final By HOMEBRANCH=By.id("id_homebrh");
	public static final By RELATIONSHIP_ACTIVATED_DATE=By.xpath("//input[@name='prflActivatedDate']");
	public static final By MISROW= By.xpath("//*[@id='tab-content-9']/div/md-content/div/form/div[5]/table/tbody/tr");
	public static final By REFER_RELATIONSHIP_ROW= By.xpath("//*[@id='tab-content-9']/div/md-content/div/form/div[6]/table/tbody/tr");
	public static final By LINK_RELATIONSHIP_ROW= By.xpath("//*[@id='tab-content-9']/div/md-content/div/form/div[7]/table/tbody/tr");
	public static final By BANK_DETAILS_ROW= By.xpath("//*[@id='tab-content-9']/div/md-content/div/form/div[8]/table/tbody/tr");
	
	public static final By CROSS_REFERENCE=By.xpath("//span[text()='Cross Reference']");
	public static final By CROSS_REFERENCE_PRODUCT_ROW=By.xpath("//*[@id='tab-content-10']/div/md-content/div/form/div[2]/div/table/tbody/tr");
	public static final By CR_ACCOUNT_NUMBER=By.id("id_accno");
    public static final By PRODUCT_NAME=By.id("id_productname");
    public static final By ACCOUNT_CURRENCY=By.id("id_actcurr");
    public static final By ICM_PRODUCT_STATUS=By.id("id_accstatus");
    public static final By PRODUCT=By.id("id_product");
    public static final By SUB_PRODUCT=By.xpath("//*[@id='id_subproduct']");
    public static final By PRODUCT_SEQUENCE_NUMBER=By.xpath("//*[@id='id_prodseqno']");
    public static final By CONSOLIDATED_FLAG=By.xpath("//*[@id='id_consFlag']");
    public static final By TP_STATUS=By.xpath("//*[@name='nm_tpstatus' and @aria-label='TP Status']");
    public static final By TP_STATUS_DESC=By.id("tpstatusDesc");
    public static final By RELATIONSHIP_NUMBER=By.xpath("//*[@name='nm_tpstatus' and @aria-label='Related Relationship Number']");
    public static final By NAME_OF_THE_SYSTEM=By.xpath("//*[@name='systemCode']");
    public static final By MAILING_ADDRESS=By.xpath("//*[text()='Mailing Address Type']/following-sibling::div/md-input-container/md-select//span/div");
    public static final By CONTACT_TYPE=By.xpath("//*[@aria-label='contactType']/md-select-value/span[1]");
    public static final By ADDRESS_DETAILS=By.xpath("//*[@aria-label='Address Details']");
    public static final By PRODUCT_INDICATOR=By.id("id_prodIdentifier");
    public static final By PRODUCT_DESCRIPTION=By.xpath("//input[@aria-label='Description' and @ng-model='productIdDesc']");
    public static final By OPERATING_INSTRUCTION=By.xpath("//input[@aria-label='Operating Instruction']");
    public static final By PROFILE_ROLE=By.xpath("//input[@aria-label='Profile Role']");
    public static final By EMBOSSED_NAME=By.xpath("//input[@aria-label='Embossed Name']");
    public static final By PRODUCT_OPEN_DATE=By.xpath("//*[starts-with(@id,'dialogContent')]//div/div[2]/div[10]/div/md-input-container/span");
    public static final By CR_OK_BUTTON=By.xpath("//button[@ng-click='answer()']");
	
	public static final By ADDITIONAL_DETAILS=By.xpath("//span[text()='Additional Info']");
	public static final By ASIA_MILES_MEMBERSHIP_NUMBER=By.xpath("//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content/div[1]//md-input-container/input");
	public static final By BANKRUPTCY_COURT_ORDER_NUMBER=By.xpath("//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content/div[2]//md-input-container/input");
	public static final By BANKRUPTCY_COURT_ORDER_DATE=By.xpath("//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content/div[3]//md-input-container/input");
	public static final By BANKRUPTCY_EXPIRY_DATE=By.xpath("//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content/div[4]//md-input-container/input");
	public static final By BANKRUPTCY_PETITION_FILED_DATE=By.xpath("//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content/div[5]//md-input-container/input");
	public static final By INTERNATIONAL_MOBILE_PREF_FLAG=By.xpath("(//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content//md-input-container/md-checkbox)[1]");
	public static final By SMS_NOTIFY_HIGH_RISK_TELLER_FLAG=By.xpath("(//*[@id='tab-content-11']/div/md-content/div//form/md-content/md-card/md-card-content//md-input-container/md-checkbox)[2]");
	
	public static final By MULTILINGUAL=By.xpath("//span[text()='Multilingual']");
	public static final By LANGUAGE=By.xpath("(//*[@id='multilingualForm']//md-input-container/div//input[2])[1]");
	public static final By FULLNAME=By.xpath("(//*[@id='multilingualForm']//md-input-container/span[1]/input)[1]");
	public static final By MAILING_TITLE_1=By.xpath("(//*[@id='multilingualForm']//md-input-container/span[1]/input)[2]");
	public static final By MAILING_TITLE_2=By.xpath("(//*[@id='multilingualForm']//md-input-container/span[1]/input)[3]");
	
	//public static final By MULTILINGUAL_TYPE=By.xpath("//input[@name='mAddressType'][1]");
	public static final By MULTILINGUAL_TYPE=By.xpath("(//input[@name='mAddressType'])[2]");
//	public static final By MULTILINGUAL_TYPE=By.id("id_addressType");
//	public static final By MULTILINGUAL_TYPE=By.xpath((//input[@id='id_addressType'])[1]");
//	public static final By MULTILINGUAL_TYPE=By.name("mAddressType");
//	public static final By MULTILINGUAL_TYPE=By.xpath("(//*[@id='multilingualForm']//md-input-container//input)[6]");
	
	public static final By MULTILINGUAL_ADD1=By.xpath("(//*[@id='multilingualForm']/div[5]//md-input-container/input)[1]");
	public static final By MULTILINGUAL_ADD2=By.xpath("(//*[@id='multilingualForm']//md-input-container/input)[2]");
	public static final By MULTILINGUAL_ADD3=By.xpath("(//*[@id='multilingualForm']/div[5]//md-input-container/input)[3]");
	public static final By MULTILINGUAL_CITY=By.xpath("(//*[@id='multilingualForm']//div/md-input-container/div[1]/input[1])[3]");
	
	public static final By CUSTOMER_CHOICE=By.xpath("//span[text()='Customer Choice']");
	public static final By EMAIL_CUST_CHOICE=By.xpath("//*[@id='CustomerChoice']//table/tbody/tr[1]/td[2]/md-input-container/md-select/md-select-value/span/div");
	public static final By EMAIL_LAST_UPDATED_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[4])[1]");
	public static final By EMAIL_EFFECTIVE_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[5])[1]");
	public static final By MOBILE_CUST_CHOICE=By.xpath("//*[@id='CustomerChoice']//table/tbody/tr[2]/td[2]/md-input-container/md-select/md-select-value/span/div");
	public static final By MOBILE_LAST_UPDATED_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[4])[2]");
	public static final By MOBILE_EFFECTIVE_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[5])[2]");
	public static final By POST_CUST_CHOICE=By.xpath("//*[@id='CustomerChoice']//table/tbody/tr[3]/td[2]/md-input-container/md-select/md-select-value/span/div");
	public static final By POST_LAST_UPDATED_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[4])[3]");
	public static final By POST_EFFECTIVE_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[5])[3]");
	public static final By PHONE_CUST_CHOICE=By.xpath("//*[@id='CustomerChoice']//table/tbody/tr[4]/td[2]/md-input-container/md-select/md-select-value/span/div");
	public static final By PHONE_LAST_UPDATED_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[4])[4]");
	public static final By PHONE_EFFECTIVE_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[1]/table/tbody//td[5])[4]");
	public static final By CUST_CHOICE_LAST_REQUESTED_DATE=By.xpath("(//*[@id='CustomerChoice']/div/div[2]/div[1]//md-input-container/input)[1]");
	public static final By STAFF_ON_PHONE=By.xpath("(//*[@id='CustomerChoice']/div/div[2]/div[1]//md-input-container/input)[2]");
	public static final By PHONE_NUM_USED=By.xpath("(//*[@id='CustomerChoice']/div/div[2]/div[1]//md-input-container/input)[3]");
	public static final By REQUEST_OVER_PHONE=By.xpath("(//*[@id='multilingualForm']//div/md-input-container/div[1]/input[1])[3]");
	public static final By CONVERSATION_DATE=By.xpath("(//*[@id='CustomerChoice']//div/md-input-container/input[@name='expiryDate'])[1]");
	public static final By CONVERSATION_TIME=By.xpath("//*[@id='CustomerChoice']//div[2]/div[2]/div[3]//md-input-container/input");
	public static final By RISK_CODE_DESCRIPTION=By.xpath("//*[@id='tab-content-8']//form/div[3]/div/table/tbody/tr/td[1]/md-input-container/input");
	public static final By DEPARTMENT_CODE=By.xpath("//*[@id='tab-content-8']//form/div[3]/div/table/tbody/tr/td[4]/md-input-container/input");
	

	//******************************** Modify**************************************
	public static final By DELETE_DORMANCY_RISK=By.xpath("//md-checkbox[@aria-label='Delete All Dormancy Risk']/div/div[1]");
	public static final By DECEASED_DATE=By.name("demisedDate");
	public static final By Acquisition_Channel=By.id("id_aquchnl");
	public static final By Delete_MIS=By.xpath("((//form[@name='internalTab']//table)[2]//tbody/tr/td[4]/span)[1]");
	public static final By Link_Relationship=By.xpath("(//i[@class='glyphicon glyphicon-search'][@role='button'])[2]");
	public static final By Refer_Relationship=By.xpath("(//i[@class='glyphicon glyphicon-search'][@role='button'])[1]");
	public static final By Search_ICM_ID=By.id("internalTabPopup");
	public static final By Search_Button=By.xpath("//span[text()='Search']");
	//public static final By PROFILE_ENQUIRY_CDD=By.xpath("(//span[text()='CDD'])[1]");
	
	
	//public static final By OK_BUTTON=By.xpath("");
	//public static final By OK_BUTTON=By.xpath("");
	//public static final By OK_BUTTON=By.xpath("");
	
}
