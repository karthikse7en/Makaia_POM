package utillities;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import Step_Defination.MyHooks;

public class ScreenshotUtil_old 
{
	private static Logger Log        = LogManager.getLogger(ScreenshotUtil_old.class.getName());
	public enum Status{pass,fail,screenshot}; 
	
	String screenshotDir = SetupPropertiesLoader.getProperty("screenshot_dir", "directory");
 
	/**
	 * This method is to get the current date and time with the yyyy-MM-dd HH-mm-ss format	
	*/
	public String datetime() 
	{
	return new SimpleDateFormat("yyyy-MM-dd HH-mm-ss").format(new Date());

	}
	/**
	 * This method is to get the screenshot	
	 * @param Calling method name
	
	*/
	public ScreenshotUtil_old passfailScreenshot(String methodName,Status status, String partyKey) 	throws Exception
	{
	
		try
		{	
			String directory = screenshotDir+"Screenshots";
			if (!new File(directory).exists())
			{
				new File(directory).mkdir();
			}
			String dynamicname = status+"_"+partyKey+"_"+methodName +"_" + datetime() + ".png";	
			File scrFile = ((TakesScreenshot)BaseTestSetup.driver).getScreenshotAs(OutputType.FILE);
			File dest = new File(directory, dynamicname);
			FileUtils.copyFile(scrFile, dest);
		}
		catch(Exception e)
		{
			Log.error(e.getMessage());
		}

		return this;
	}
	/**
	 * This method is to get the screenshot. It can be called from the catch part
	 * @param Calling method name
	
	*/
	public  String screenshotsForAttachments(String partyKey,String operationName) 	throws Exception
	{
		String dynamicname = partyKey+"_" +operationName + ".png";
		try
		{	
			String directory = screenshotDir+"Screenshots";
			if (!new File(directory).exists())
			{
				new File(directory).mkdir();
			}
			File scrFile = ((TakesScreenshot)BaseTestSetup.driver).getScreenshotAs(OutputType.FILE);
			System.out.println(scrFile);
			File dest = new File(directory, dynamicname);
			System.out.println(dest);
			FileUtils.copyFile(scrFile, dest);
		}
		catch(Exception e)
		{
			Log.error(e.getMessage());
		}
		
		return dynamicname;
	}

	
	public String getScreenCaptureName()
	{
		String screenCapture = null;
		Pattern p=Pattern.compile("\\W");
        Matcher matcher=p.matcher(MyHooks.genieScenario.getName());
		if(!matcher.matches())
		{
        	
			screenCapture=MyHooks.genieScenario.getName().replaceAll("\\W", " ");
        	//System.out.println(screenCapture);
        	
        }
		return screenCapture;
	}
	
	
	public void passfailScreenshot()throws Exception
    {
    
           try
           {  
        	   String stepName = getScreenCaptureName();
                  String directory = screenshotDir+"Screenshots";
                  if (!new File(directory).exists())
                  {
                        new File(directory).mkdir();
                  }
                  String dynamicname = stepName+"_"+ datetime() + ".png"; 
                  File scrFile = ((TakesScreenshot)BaseTestSetup.driver).getScreenshotAs(OutputType.FILE);
                  File dest = new File(directory, dynamicname);
                  FileUtils.copyFile(scrFile, dest);
           }
           catch(Exception e)
           {
                  Log.error(e.getMessage());
           }

    }

	
}
