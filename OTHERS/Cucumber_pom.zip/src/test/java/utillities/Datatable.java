package utillities;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Datatable {
    private Object        instance_;
    private String        sheetName_;
    private String        filePath_;
    private static Logger Log = LogManager.getLogger(WrapperUtil.class.getName());

    /**
     * To set path of the excel going to use
     * 
     * @param Path
     */
    public void setFilePath(String Path) {
        filePath_ = Path;
    }

    public void setSheetName(String sName) {
        sheetName_ = sName;
    }

    /**
     * To get the excel workbook
     * 
     * @return
     */
    public Workbook getWorkBook() {
        try {
            FileInputStream file = new FileInputStream(new File(filePath_));
            if (filePath_.substring(filePath_.indexOf(".")).equals(".xls")) {
                HSSFWorkbook workBook = new HSSFWorkbook(file);
                return workBook;
            }
            else {
                XSSFWorkbook workBook = new XSSFWorkbook(file);
                return workBook;
            }

        }
        catch (Exception e) {
            Log.error(e.getMessage());
            System.out.println("Please provide valid file");
            return null;
        }
    }

    /**
     * To get the data from the data-table
     * 
     * @param sheetName
     * @param columnHeader
     * @param featureFileName
     * @return
     */
    public String getData(String columnHeader, String featureFileName) {
        try {
            System.out.println(filePath_);
            System.out.println(sheetName_);
            int rowNumber = 0;
            int columnNumber = 0;
            for (int i = 0; i < getWorkBook().getSheet(sheetName_).getRow(0).getPhysicalNumberOfCells(); i++) {
                if (getWorkBook().getSheet(sheetName_).getRow(0).getCell(i).toString().trim().equalsIgnoreCase(columnHeader)) {
                    columnNumber = i;
                    break;
                }
            }
            for (int j = 0; j < getWorkBook().getSheet(sheetName_).getPhysicalNumberOfRows(); j++) {
                if (getWorkBook().getSheet(sheetName_).getRow(j).getCell(0).toString().trim().equalsIgnoreCase(featureFileName)) {
                    rowNumber = j;
                    break;
                }
            }
            return getWorkBook().getSheet(sheetName_).getRow(rowNumber).getCell(columnNumber).toString().trim();
        }
        catch (Exception e) {
            System.out.println("Please verify your data");
            return null;
        }
    }

    /**
     * Return the list of locators provided correct sheet name. if the sheet
     * name is incorrect, null value returned.
     * 
     * @param sheetName
     * @return locator
     */
    public List<String> getLocator(String sheetName) {
        try {
            List<String> objectLocator = new ArrayList<String>();
            for (int i = 0; i < getWorkBook().getSheet(sheetName).getPhysicalNumberOfRows(); i++) {
                String str = getWorkBook().getSheet(sheetName).getRow(i).getCell(0).toString();
                objectLocator.add(str);
            }
            return objectLocator;
        }
        catch (Exception e) {
            Log.error(e.getMessage());
            System.out.println("Provide proper locator sheet name");
            return null;
        }
    }

    /**
     * returns data for a particular field. if the parameters are wrong, null
     * value returned.
     * 
     * @param c
     * @param sheetName
     * @param fieldName
     * @param list
     * @return data
     */
    public String getData(Class<?> c, String sheetName, String fieldName, List<?> list) {
        try {
            String dataValue = null;
            instance_ = c.newInstance();
            instance_ = list.get(0);
            List<Field> fields = Arrays.asList(c.getDeclaredFields());
            for (Field field : fields) {
                if (fieldName.equalsIgnoreCase(field.getName())) {
                    Field field2 = c.getDeclaredField(field.getName());
                    field2.setAccessible(true);
                    dataValue = (String) field2.get(instance_);
                    break;
                }
            }
            return dataValue;
        }
        catch (Exception e) {
            Log.error(e.getMessage());
            System.out.println("Parameters for data retrieval might be wrong please verify");
            return null;
        }
    }
    
    /**
     * Overloaded method
     * returns data for a particular field. if the parameters are wrong, null
     * value returned.
     * 
     * @param c
     * @param sheetName
     * @param fieldName
     * @param list
     * @return data
     */
    public String getData(Class<?> c, String sheetName, String fieldName, List<?> list,int i) {
        try {
            String dataValue = null;
            instance_ = c.newInstance();
            instance_ = list.get(0);
            List<Field> fields = Arrays.asList(c.getDeclaredFields());
            for (Field field : fields) {
                if (fieldName.equalsIgnoreCase(field.getName())) {
                    Field field2 = c.getDeclaredField(field.getName());
                    field2.setAccessible(true);
                    dataValue = (String) field2.get(instance_);
                    break;
                }
            }
            return dataValue.split(Pattern.quote("|"))[i-1];
        }
        catch (Exception e) {
            Log.error(e.getMessage());
            System.out.println("Parameters for data retrieval might be wrong please verify");
            return null;
        }
    }
}
