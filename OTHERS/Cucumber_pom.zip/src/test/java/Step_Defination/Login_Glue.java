package Step_Defination;

import java.util.HashMap;

import org.apache.http.impl.client.EntityEnclosingRequestWrapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import Business_Methods.ICDD_CustomerRecord;
import Business_Methods.ICDD_WorkItem;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.BaseTestSetup;
import utillities.DataProvider;
import utillities.SetupPropertiesLoader;
import utillities.Common_Utils;
import Business_Methods.Jira;

public class Login_Glue {
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	Common_Utils Common = new Common_Utils();
	Jira Jira = new Jira();
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public String browserName = "";
	/*String browserProp = SetupPropertiesLoader.getProperty("browser", "directory");
	String urlProp = SetupPropertiesLoader.getProperty("url1", "directory");*/
	
/*	static {
		try {
			BaseTestSetup.setDriver("chrome", SetupPropertiesLoader.getProperty("ICM_Url", "directory"));
		} catch (Exception e) {
		}
	};*/

	public String browserName(String browser) {
		  Capabilities caps = ((RemoteWebDriver) BaseTestSetup.driver).getCapabilities();
		  browserName = caps.getBrowserName();
		  System.out.println(browserName);
		return browserName;
		} 
	
	@Given("^ICM Application \"([^\"]*)\" is launched in browser$")
	public void icm_application_browser_is_launched(String arg1) throws Throwable {
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("chrome")){
				BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
	
	@Given("^SCB Bridge Application is launched in browser \"([^\"]*)\" \"([^\"]*)\"$")
		public void browser_is_launched(String arg1, String arg2) throws Throwable {
		if(BaseTestSetup.driver == null){
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));}
				else {
					browserName(browserName);
					if( browserName.equals("chrome")){
						BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));}
					else{
						BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty("SCB_Bridge", "directory"));
						}
				}
				ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
				dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
				ICDD_CustomerRecord.bridge(arg1, excelHashMapValues, arg2);
	}
	
	@Given("^JIRA Application \"([^\"]*)\" is launched in browser$")
	public void Jira_Application_Browser_is_launched(String arg1) throws Throwable {
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("internet explorer")){
				BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser1", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
	
	@Given("^get statosphere data \"([^\"]*)\" \"([^\"]*)\"$")
	public void get_statosphere_data(String arg1, String arg2) throws Throwable {
		DataProvider dataprovider = new DataProvider();
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		Jira.getStatosphere();
	}

	@Given("^ICDD Application \"([^\"]*)\" is launched in browser$")
	public void iccd_Application_Browser_is_launched(String arg1) throws Throwable {
		if(BaseTestSetup.driver == null){
			BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
		else {
			browserName(browserName);
			if( browserName.equals("internet explorer")){
				BaseTestSetup.driver.get(SetupPropertiesLoader.getProperty(arg1, "directory"));}
			else{
				BaseTestSetup.setDriver(SetupPropertiesLoader.getProperty("browser", "directory"), SetupPropertiesLoader.getProperty(arg1, "directory"));}
			}
	   }
		
		
		/*
		if(!(BaseTestSetup.driver == null) && browserName.equals(SetupPropertiesLoader.getProperty("browser", "directory"))){
			BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty("ICDD_IN", "directory"));}
		else {
			BaseTestSetup.driver.navigate().to(SetupPropertiesLoader.getProperty("ICDD_IN", "directory"));}
		 }*/
    
    @Given("^CDD Maker is able to log as \"([^\"]*)\" in ICDD$")
    public void cdd_Maker_is_able_to_log_as_in_ICDD(String userName) throws Throwable { 
		try {
			System.out.println("Entered Step 2");
			if (userName != null) {
			   String adminUserName = SetupPropertiesLoader.getProperty(userName,"roles");
			   String adminPassword = SetupPropertiesLoader.getProperty("password1", "roles");
				if (adminUserName != null && adminPassword != null) {
					Common.screenshot();
					iCDD_WorkItem.loginApplication(adminUserName, adminPassword);
				    System.out.println("################# "+ userName + "Logged into ICDD Application successfully ################");
				    Log.info("################# "+ userName + "Logged into ICDD Application successfully ################");
				}
				else {
				    throw new Exception("Error: User name or password is not set in roles.properties file");
				}
		   }
		}
		catch (Exception e) {
		    throw new Exception("Login failed" + " :" + e.getMessage());
		}
    }
    
	   @Then("^logout actimize system$")
	    public void logout_Actimize_system() throws Exception {
	    	iCDD_WorkItem.logout();
	    }
    
  
	
	
	
	
}