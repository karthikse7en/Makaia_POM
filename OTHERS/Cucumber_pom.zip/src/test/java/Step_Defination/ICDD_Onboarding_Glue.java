package Step_Defination;

import java.util.HashMap;

import Business_Methods.ICDD_Forms;
import Business_Methods.ICDD_WorkItem;
import utillities.DataProvider;

public class ICDD_Onboarding_Glue {
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	ICDD_Forms ICDD_Forms = new ICDD_Forms();

	
	
	
	
}
