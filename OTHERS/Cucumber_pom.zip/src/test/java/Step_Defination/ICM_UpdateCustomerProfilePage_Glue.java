package Step_Defination;

import java.util.HashMap;

import Business_Methods.DataSync_ICDD_ICM;
import Business_Methods.ICM_UpdateCustomerProfilePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.DataProvider;

public class ICM_UpdateCustomerProfilePage_Glue {
	
	ICM_UpdateCustomerProfilePage iCM_UpdateCustomerProfilePage=new ICM_UpdateCustomerProfilePage();
	DataProvider dataprovider = new DataProvider();
	DataSync_ICDD_ICM datasync = new DataSync_ICDD_ICM();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	
	 @When("^searches for client by ICM ID: \"([^\"]*)\"$")
		public void searches_for_client_by_ICM_ID(String arg1) throws Throwable {
		}
	
	@Given("^searches for client by ICM ID: \"([^\"]*)\" \"([^\"]*)\"$")
	public void searches_for_client_by_ICM_ID(String arg1, String arg2) throws Throwable {
	dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
	iCM_UpdateCustomerProfilePage.ICMInformation_validattion(arg1,excelHashMapValues);
	} 
	
	@Then("^verify updated CDD information from client which includes CDD risk code,CDD status, LRD,NRD ,ICM ID Relationship ID, CDD refernce number and determine that it matches with values in ICDD system \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_updated_CDD_information_from_client_which_includes_CDD_risk_code_CDD_status_LRD_NRD_ICM_ID_Relationship_ID_CDD_refernce_number_and_determine_that_it_matches_with_values_in_ICDD_system(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		iCM_UpdateCustomerProfilePage.ICMInformation_validattion(arg1,excelHashMapValues);
		}
	
	@When("^Update CDD information for the client \"([^\"]*)\"$")
	public void update_CDD_information_for_the_client(String scenarioName) throws Throwable {
		dataprovider.extractExcelData(scenarioName, excelHashMapValues);
		iCM_UpdateCustomerProfilePage.ICM_Information_Modification(scenarioName, excelHashMapValues);
		iCM_UpdateCustomerProfilePage.ICMInformation_modifn_validattion(scenarioName, excelHashMapValues);
	}
	
	@Then("^verify CDD information for \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_CDD_information_for(String arg1, String arg2) throws Throwable {
	}
	
	@Then("^check/copy the data to be verified in ICM \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_copy_the_data_to_be_verified_in_ICM(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.ICM_Data(arg1, excelHashMapValues, arg2);
	}
	
	@Then("^check/copy the data to be verified in ICDD \"([^\"]*)\" \"([^\"]*)\"$")
	public void check_copy_the_data_to_be_verified_in_ICDD(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.ICDD_Data(arg1, excelHashMapValues, arg2);
	}

	@Then("^Verify the datasync between ICDD and ICM \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_the_datasync_between_ICDD_and_ICM(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		datasync.DataSyncVerify(arg1, excelHashMapValues, arg2);
	}

}
