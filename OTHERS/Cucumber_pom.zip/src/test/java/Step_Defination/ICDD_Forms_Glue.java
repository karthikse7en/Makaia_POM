package Step_Defination;

import java.util.HashMap;

import Business_Methods.ICDD_WorkItem;
import Object_Repository.ICDD_Forms_Obj;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utillities.DataProvider;
import Business_Methods.ICDD_Forms;
import Business_Methods.ICDD_CustomerRecord;

public class ICDD_Forms_Glue {
	
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	ICDD_WorkItem iCDD_WorkItem=new ICDD_WorkItem();
	ICDD_Forms ICDD_Forms = new ICDD_Forms();
	ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();


	@And("^fills the Perform Review Check E-forms \"([^\"]*)\" \"([^\"]*)\"$")
	public void fills_the_Perform_Review_Check_E_forms(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		ICDD_Forms.fillForms_PerformReviewChecks(arg1, excelHashMapValues);
	}
	
	@And("^fills the Client Contact forms \"([^\"]*)\" \"([^\"]*)\"$")
	public void fills_Client_Contact_forms(String arg1,String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		if(!excelHashMapValues.get("CLIENT_CONTACT_FROM").trim().isEmpty()){
		ICDD_Forms.createClientContact(arg1, excelHashMapValues);
		ICDD_Forms.completeClientContact(arg1, excelHashMapValues);
		}
	}
	
	@And("^Create and export PDF \"([^\"]*)\"$")
	public void create_And_Export(String arg1) throws Throwable {
		dataprovider.extractExcelData(arg1, excelHashMapValues);
		ICDD_CustomerRecord.createSavePDF(arg1, excelHashMapValues);
	}
	
	@And("^Add Attachment \"([^\"]*)\"$")
	public void add_Attachment(String arg1) throws Throwable {
		dataprovider.extractExcelData(arg1, excelHashMapValues);
		//ICDD_CustomerRecord.addAttachment(arg1, excelHashMapValues);
	}
	
	@And("^View Attachment \"([^\"]*)\"$")
	public void View_Attachment(String arg1) throws Throwable {
		dataprovider.extractExcelData(arg1, excelHashMapValues);
		ICDD_CustomerRecord.viewAttachment(arg1, excelHashMapValues);
	}
	
	@And("^Clone Form \"([^\"]*)\" \"([^\"]*)\"$")
	public void Clone_Form(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		ICDD_Forms.cloneForm(arg1, excelHashMapValues);
	}
	
	@And("^changes the step to Submit$")
	public void changes_the_step_to_Submit() throws Throwable {
		//To implement change the step to submit
	}
	
	@And("^clones the e-form to transfer all the e-forms from alert(\\d+) to alert(\\d+)$")
	public void clones_the_e_form_to_transfer_all_the_e_forms_from_alert_to_alert(int arg1, int arg2) throws Throwable {
	}
	
	@And("^verify review check is complete for trigger review alert(\\d+)$")
	public void verify_review_check_is_complete_for_trigger_review_alert(int arg1) throws Throwable {
	}
	
	//RFI
	@Given("^that the CDD Ops Maker has created and exported a PDF of the PEP e-form for alert$")
	public void that_the_CDD_Ops_Maker_has_created_and_exported_a_PDF_of_the_PEP_e_form_for_alert() throws Throwable {
	}

	@When("^the CDD Ops Maker selects Create RFI in the Alert Detail page$")
	public void the_CDD_Ops_Maker_selects_Create_RFI_in_the_Alert_Detail_page() throws Throwable {
	}

	@When("^fills in the details \"([^\"]*)\"$")
	public void fills_in_the_details(String arg1) throws Throwable {
	}

	@When("^adds a mandatory note on transition \"([^\"]*)\"$")
	public void adds_a_mandatory_note_on_transition(String arg1) throws Throwable {
	}


	@When("^attaches the PDF export of the PEP e-form$")
	public void attaches_the_PDF_export_of_the_PEP_e_form() throws Throwable {
	}


	@When("^clicks Send as Email to send the RFI to the CDD Advisor$")
	public void clicks_Send_as_Email_to_send_the_RFI_to_the_CDD_Advisor() throws Throwable {
	}
	
	//RFI Email confirmation
	@Given("^that the CDD Advisor has received the RFI in their email from the CDD Ops Maker$")
	public void that_the_CDD_Advisor_has_received_the_RFI_in_their_email_from_the_CDD_Ops_Maker() throws Throwable {
	}

	@When("^CDD Advisor reviews the information filled in within the PEP E-Form and confirms PEP$")
	public void cdd_Advisor_reviews_the_information_filled_in_within_the_PEP_E_Form_and_confirms_PEP() throws Throwable {
	}

	@When("^sends a confirmation note in the email to the CDD Ops Maker \"([^\"]*)\"$")
	public void sends_a_confirmation_note_in_the_email_to_the_CDD_Ops_Maker(String arg1) throws Throwable {
	}

	@Then("^the RFI should be assigned to the CDD Ops Maker under View RFI in the Alert Detail page and \"([^\"]*)\" is confirmed$")
	public void the_RFI_should_be_assigned_to_the_CDD_Ops_Maker_under_View_RFI_in_the_Alert_Detail_page_and_is_confirmed(String arg1) throws Throwable {
	}
	
	@When("^Complete filling PEP E-form \"([^\"]*)\"$")
	public void complete_Filling_PEP_eForm(String arg1) throws Throwable {
	}
	
	@When("^changes step to Decision on PEP$")
	public void changes_step_to_Decision_on_PEP() throws Throwable {
	}
	
	@When("verifies that the e-forms and checklists are completed$")
	public void verifies_that_the_eforms_and_checklists_are_completed() throws Throwable {
	}
	
	
	

}

