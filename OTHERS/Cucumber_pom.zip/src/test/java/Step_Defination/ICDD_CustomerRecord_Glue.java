package Step_Defination;

import java.util.HashMap;

import Business_Methods.ICDD_WorkItem;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import utillities.DataProvider;
import Business_Methods.ICDD_CustomerRecord;

public class ICDD_CustomerRecord_Glue {
	
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	ICDD_CustomerRecord ICDD_CustomerRecord=new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();

	@Given("^Search and open customer using ICDD_ID \"([^\"]*)\" \"([^\"]*)\"$")
	public void search_for_customer_using_ICDD_ID(String arg1, String arg2) throws Throwable {
		DataProvider dataprovider = new DataProvider();
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		ICDD_CustomerRecord.searchCustomer_ICDD_ID(arg1, excelHashMapValues);
	}


	@Given("^Create a manual Trigger \"([^\"]*)\" \"([^\"]*)\"$")
	public void create_a_manual_Trigger(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1, arg2, excelHashMapValues);
		ICDD_WorkItem.CreateManualTrigger(arg1, excelHashMapValues, arg2);
	}	

	
	@Given("^Create a Periodic Review Trigger \"([^\"]*)\"$")
	public void create_a_Periodic_Trigger(String arg1) throws Throwable {
		dataprovider.extractExcelData(arg1, excelHashMapValues);
		//ICDD_WorkItem.CreatePeriodicReviewAlert(arg1, excelHashMapValues);
	}
	
	@Given("^Create a Periodic Review Trigger \"([^\"]*)\" \"([^\"]*)\"$")
	public void create_a_Periodic_Trigger(String arg1, String arg2) throws Throwable {
		dataprovider.extractExcelData(arg1,arg2, excelHashMapValues);
		ICDD_WorkItem.CreatePeriodicReviewAlert(arg1, excelHashMapValues, arg2);
	}
	
	@And("^Verify if alert is present in overdue periodic review \"([^\"]*)\"$")
	public void verify_if_alert_is_present_in_overdue_periodic_review(String arg1) throws Throwable {
		System.out.println("Overdue scenarios has to be scripted");
	}
	
	@And("^Verify Trigger review \"([^\"]*)\"$")
	public void verify_Trigger_review(String arg1) throws Throwable {
		//Verify Trigger script 
	}
	
	@And("^Verify Trigger review for joint account \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_Trigger_review_for_joint_account(String arg1, String arg2) throws Throwable {
	}
	
	@And("^Verify the overdue_periodic_alert \"([^\"]*)\"$")
	public void verify_Overdue_Periodic_alert(String arg1) throws Throwable {
		///overdue
	}
	
	@And("^Verify periodic review \"([^\"]*)\"$")
	public void verify_periodic_review(String arg1) throws Throwable {
		//Verify periodic review script 
	}
	
	@When("^verifies the alert in workflow$")
	public void verifies_the_alert_in_workflow() throws Throwable {
	}
	
	
	@Given("^is assigned to the \"([^\"]*)\" workgroup$")
	public void is_assigned_to_the_workgroup(String arg1) throws Throwable {
	}
	

	@And("^verify periodic review status Auto Close due to WIP Triggers \"([^\"]*)\"$")
	public void verify_periodic_review_status_AutoClose_duetoWIP_Triggers(String arg1) throws Throwable {
	}
	
	
	
	
	@And("^Verify Trigger review for \"([^\"]*)\" and \"([^\"]*)\" \"([^\"]*)\"$")
	public void verify_Trigger_review_for_and(String arg1, String arg2, String arg3) throws Throwable {
	 //Verify Trigger script for 2 customers
	}
	
	
}
