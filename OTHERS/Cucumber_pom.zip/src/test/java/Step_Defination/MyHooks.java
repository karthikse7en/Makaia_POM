package Step_Defination;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.standardchartered.genie.model.GenieScenario;

import utillities.BaseTestSetup;
import utillities.ScreenshotUtil_old;
import utillities.SetupPropertiesLoader;
import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;

/**
 * @author 1542375 Utility to capture screenshot of the failed scenario and
 *         embed the same in report
 */

public class MyHooks {

    public static GenieScenario genieScenario;
    public static boolean logoutTag = false;
    private static Logger Log              = LogManager.getLogger(MyHooks.class.getName());
    String screenShotPath = SetupPropertiesLoader.getProperty("screenshot_dir", "directory");
    ScreenshotUtil_old screenshot=new ScreenshotUtil_old();

    @Before
    public void checkLogoutTag(Scenario scenario) {
        final ArrayList<String> scenarioTags = new ArrayList<String>();
        scenarioTags.addAll(scenario.getSourceTagNames());
        System.out.println(scenarioTags);
        
        if (scenarioTags.contains("@Logout")) {

            logoutTag = true;
        }
    }

  /*  @After
    public void getScreenShotAfterScenarios(Scenario scenario) throws Exception {
        if (!logoutTag) {
            try {
                byte[] imageInBytes = ((TakesScreenshot) BaseTestSetup.driver).getScreenshotAs(OutputType.BYTES);
                File src = ((TakesScreenshot) BaseTestSetup.driver).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(src, new File(screenShotPath +screenshot.getScreenCaptureName()+"_" +(new SimpleDateFormat("yyyy-MM-dd_HH.mm").format(new Date())+ ".png")));
                scenario.embed(imageInBytes, "image/png");
                if (scenario.isFailed()) {
                    Log.info(scenario.getName()+"==> FAILED");
                    BaseTestSetup.wait = new WebDriverWait(BaseTestSetup.driver, 20);
                }
                else if(scenario.getStatus().equalsIgnoreCase("passed")){
                    Log.info(scenario.getName()+"==> PASSED");                    
                }
            }
            catch (IOException e) {
                System.out.println("Error while taking screenshot");
            }
        }
        else{
            killBrowser(scenario);
        }
    }*/

    @After("@Logout")
    public void killBrowser(Scenario scenario) throws Exception {
        if (scenario.getName().toLowerCase().contains("logout")){
        logoutTag = false;
        BaseTestSetup.tearDown();
        Thread.sleep(5000);
        }
    }

    @Before
    public static GenieScenario setupGlue(Scenario scenario) {
        Log.info("Executing Scenario: "+scenario.getName());
        return genieScenario = (GenieScenario) scenario;

    }

}
