package Business_Methods;

import java.util.HashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;


public class ICDD_Forms extends Common_Utils {
	
	ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	
	
	public void clickOnAlert() throws Exception{
		//click(Fill_Forms_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		//click(Fill_Forms_Obj.CHECK_FIRST_ALERT);
		click(ICDD_Forms_Obj.CLICK_ALERT);sleep(mediumWaitVal);
		//assign_to_me(); 
	}
	

	public void fillForms_PerformReviewChecks(String scenarioName, HashMap<String, String> testData) throws Exception{
		String[] expectedForms= testData.get("Perform_Review_Check_Forms").split("\\|");
		for(int i=0; i<expectedForms.length; i++){
			switch (expectedForms[i]){
			case "SOW":
				createSOWForm(scenarioName, testData);
				completeSOW(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				
				break;
				
			case "PEP":
				createPEPForm(scenarioName, testData);
				completePEP(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;	
			
			case "AdverseMedia":
				createAdverseMediaForm(scenarioName, testData);
				completeAdverse(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;	
				
			case "Tax-E":
				//createTaxEForm(scenarioName, testData);
				//completeTax(scenarioName, testData);
				break;
				
			case "AdditionalCDD":
				AdditionCDDform(scenarioName, testData);
				break;
				
			case "CreateReviewChecklist":
				//CreateReviewChecklist(scenarioName, testData);
				NewCreateReviewChecklist(scenarioName, testData);
				completeCreateReviewChecklist(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;
				
			default:
				break;
			}
		}
	}
	
	public void completeSOW(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.SOW_WORKITEM);
		ICDD_WorkItem.changestep("Decision on SOW");
		click(ICDD_Forms_Obj.SOW_WORKITEM);	
	}
	 public void searchAlertForForm(String scenarioName,HashMap<String, String> testData) throws Exception{
		 /*WebElement element1=BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
	     element1.click();
	     List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
	     for (WebElement option : listOfOptions) {
	     if (option.getText().trim().equalsIgnoreCase("Trigger Review - Alert Status".trim())) {
	     triggerOnClick(option);
	     break;}
	     }
	    iCDD_WorkItem.searchcustomeralerts(testData.get("ICDD_ID"));sleep(minWaitVal);
    	iCDD_WorkItem.click_ref_id();sleep(mediumWaitVal);*/
		 String alertNo = testData.get("ALERT_TYPE");
		 enterInputText(ICDD_WorkItem_Obj.SEARCH, testData.get(alertNo));sleep(minWaitVal);
		 	webDriverwait(By.xpath("//a[text()='"+testData.get(alertNo)+"']"));
		 	click(By.xpath("//a[text()='"+testData.get(alertNo)+"']"));sleep(mediumWaitVal);
	 }
	      
     public void completePEP(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.PEP_WORKITEM);
		ICDD_WorkItem.changestep("Decision on PEP");
		click(ICDD_Forms_Obj.PEP_WORKITEM);	
	}
	
	public void completeAdverse(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.ADVERSE_WORKITEM);
		ICDD_WorkItem.changestep("Decision on AM");
		click(ICDD_Forms_Obj.ADVERSE_WORKITEM);
	}
	
	public void completeTax(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.TAX_WORKITEM);
		ICDD_WorkItem.changestep("Decision on Tax");
		click(ICDD_Forms_Obj.TAX_WORKITEM);
	}
	
	public void completeCreateReviewChecklist(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.CREATEREVIEWCHECKLIST_WORKITEM);
		ICDD_WorkItem.changestep("Submit");
		click(ICDD_Forms_Obj.CREATEREVIEWCHECKLIST_WORKITEM);
	}
	
	public void completeClientContact(String scenarioName,HashMap<String, String> testData) throws Exception{
		
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
    	ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.CLIENT_CONTACT_WORKITEM);
		ICDD_WorkItem.changestep("Submit");
		click(ICDD_Forms_Obj.CLIENT_CONTACT_WORKITEM);
	}
	
	public void cloneForm(String scenarioName,HashMap<String, String> testData) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName, testData);
		ICDD_CustomerRecord.clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		String[] expectedCloneForms= testData.get("Clone_Forms").split("\\|");
		for(int i=0; i<expectedCloneForms.length; i++){
			switch (expectedCloneForms[i]){
			case "SOW":
				click(ICDD_Forms_Obj.SOW_WORKITEM);
				sleep(minWaitVal);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.SOW_WORKITEM);
				completeCreateReviewChecklist(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;
				
			case "PEP":
				click(ICDD_Forms_Obj.PEP_WORKITEM);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.PEP_WORKITEM);
				completeCreateReviewChecklist(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;
				
			case "AdverseMedia":
				click(ICDD_Forms_Obj.ADVERSE_WORKITEM);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.ADVERSE_WORKITEM);
				break;	
				
			case "Tax-E":
				click(ICDD_Forms_Obj.TAX_WORKITEM);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.TAX_WORKITEM);
				break;
				
			case "AdditionalCDD":
				click(ICDD_Forms_Obj.SOW_WORKITEM);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.SOW_WORKITEM);
				break;
				
			case "CreateReviewChecklist":
				click(ICDD_Forms_Obj.CREATEREVIEWCHECKLIST_WORKITEM);
				sleep(minWaitVal);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.CREATEREVIEWCHECKLIST_WORKITEM);
				completeCreateReviewChecklist(scenarioName, testData);
				searchAlertForForm(scenarioName, testData);
				break;
				
			case "ClientContactForm":
				click(ICDD_Forms_Obj.CLIENT_CONTACT_WORKITEM);
				actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLONEFORM);
				acceptAlert();
				click(ICDD_Forms_Obj.CLIENT_CONTACT_WORKITEM);
				break;
				
			default:
				break;
			}
		}
	}
	
	public void createSOWForm(String scenarioName,HashMap<String, String> testData){
		sleep(mediumWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.SOWFORM);
		switchToWindow();
		inputText(ICDD_Forms_Obj.DEPOSITS_ANTICIPATED_NO, testData.get("DEPOSITS_ANTICIPATED_NO"));
		inputText(ICDD_Forms_Obj.DEPOSITS_ANTICIPATED_TOTAL, testData.get("DEPOSITS_ANTICIPATED_TOTAL"));
		inputText(ICDD_Forms_Obj.WITHDRAWAL_ANTICIPATED_TOTAL, testData.get("WITHDRAWAL_ANTICIPATED_TOTAL"));
		inputText(ICDD_Forms_Obj.WITHDRAWAL_ANTICIPATED_NO, testData.get("WITHDRAWAL_ANTICIPATED_NO"));
		
		enterInputText(ICDD_Forms_Obj.SOURCE_OF_DEPOSIT, testData.get("Source_Of_Deposit"));
		enterInputText(ICDD_Forms_Obj.COUNTRIES_OF_DEPOSIT, testData.get("Countries_Of_Deposit"));
		enterInputText(ICDD_Forms_Obj.COUNTIRES_INIT_DEPOSIT, testData.get("Countries_Initi_Deposit"));
		screenshot();
		enterInputText(ICDD_Forms_Obj.EMPLOYMENT_JOB_TITLE, testData.get("EMPLOYMENT_JOB_TITLE"));
		enterInputText(ICDD_Forms_Obj.EMPLOYMENT_EMP_NAME, testData.get("EMPLOYMENT_EMP_NAME"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.EMPLOYMENT_NATURE, testData.get("EMPLOYMENT_NATURE"));
		screenshot();
		inputText(ICDD_Forms_Obj.EMPLOYMENT_TOTAL_EXP, testData.get("EMPLOYMENT_TOTAL_EXP"));
		inputText(ICDD_Forms_Obj.EMPLOYMENT_ANNUAL_INCOME, testData.get("EMPLOYMENT_ANNUAL_INCOME"));
		inputText(ICDD_Forms_Obj.INVESTEMENT_INCOME, testData.get("INVESTEMENT_INCOME"));
		inputText(ICDD_Forms_Obj.PROPERTY_INCOME, testData.get("PROPERTY_INCOME"));
		//inputText(ICDD_Forms_Obj.BUSINESS_ESTABLISHED, testData.get("BUSINESS_ESTABLISHED"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.BUSINESS_NATURE, testData.get("BUSINESS_NATURE"));
		inputText(ICDD_Forms_Obj.BUSINESS_OWNERSHIP_PERCENTAGE, testData.get("BUSINESS_OWNERSHIP_PERCENTAGE"));
		inputText(ICDD_Forms_Obj.BUSINESS_CLIENT_PAY, testData.get("BUSINESS_CLIENT_PAY"));
		screenshot();
		inputText(ICDD_Forms_Obj.BUSINESS_TOTAL_INCOM, testData.get("BUSINESS_TOTAL_INCOM"));
		inputText(ICDD_Forms_Obj.OTHER_SOURCE_INCOME, testData.get("OTHER_SOURCE_INCOME"));
		inputText(ICDD_Forms_Obj.OTHER_TOTAL_INCOME, testData.get("OTHER_TOTAL_INCOME"));
		inputText(ICDD_Forms_Obj.INHERITANCE_YEAR, testData.get("INHERITANCE_YEAR"));
		inputText(ICDD_Forms_Obj.INHERITANCE_TYPE, testData.get("INHERITANCE_TYPE"));
		inputText(ICDD_Forms_Obj.INHERITANCE_ORIGINAL_AMOUNT, testData.get("INHERITANCE_ORIGINAL_AMOUNT"));
		inputText(ICDD_Forms_Obj.INHERITANCE_RELATIONSHIP, testData.get("INHERITANCE_SOURCE"));
		inputText(ICDD_Forms_Obj.SAVINGS_TOTALAMOUNT_ON, testData.get("SAVINGS_TOTALAMOUNT_ON"));
		screenshot();
		inputText(ICDD_Forms_Obj.SAVINGS_TOTALAMOUNT_OFF, testData.get("SAVINGS_TOTALAMOUNT_OFF"));
		inputText(ICDD_Forms_Obj.MORTGAGE_LIABILITIES_ON, testData.get("MORTGAGE_LIABILITIES_ON"));
		inputText(ICDD_Forms_Obj.MORTGAGE_TOTALAMOUNT_OFF, testData.get("MORTGAGE_TOTALAMOUNT_OFF"));
		inputText(ICDD_Forms_Obj.INVESTMENTS_TOTALAMOUNT_ON, testData.get("INVESTMENTS_TOTALAMOUNT_ON"));
		inputText(ICDD_Forms_Obj.INVESTMENTS_TOTALAMOUNT_OFF, testData.get("INVESTMENTS_TOTALAMOUNT_OFF"));
		inputText(ICDD_Forms_Obj.LOANS_LIABILITIES_ON, testData.get("LOANS_LIABILITIES_ON"));
		inputText(ICDD_Forms_Obj.LOANS_TOTALAMOUNT_OFF, testData.get("LOANS_TOTALAMOUNT_OFF"));
		inputText(ICDD_Forms_Obj.PROPERTY_TOTALAMOUNT_ON, testData.get("PROPERTY_TOTALAMOUNT_ON"));
		inputText(ICDD_Forms_Obj.PROPERTY_TOTALAMOUNT_OFF, testData.get("PROPERTY_TOTALAMOUNT_OFF"));
		inputText(ICDD_Forms_Obj.OTHER_LIABILITIES_ON, testData.get("OTHER_LIABILITIES_ON"));
		inputText(ICDD_Forms_Obj.OTHER_TOTALAMOUNT_OFF, testData.get("OTHER_TOTALAMOUNT_OFF"));sleep(minWaitVal);sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.COUNTRIES_SIGNIFICANT_WEALTH, testData.get("COUNTRIES_SIGNIFICANT_WEALTH"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.INDUSTRIES_SIGNIFICANT_WEALTH, testData.get("INDUSTRIES_SIGNIFICANT_WEALTH"));
		checkboxClick(ICDD_Forms_Obj.DEFENCE_WEAPONS, testData.get("DEFENCE_WEAPONS"));
		checkboxClick(ICDD_Forms_Obj.MONY_SERVICE, testData.get("MONY_SERVICE"));
		checkboxClick(ICDD_Forms_Obj.GAMING_INDUSTRIES, testData.get("GAMING_INDUSTRIES"));
		checkboxClick(ICDD_Forms_Obj.PRECIOUS_METALS, testData.get("PRECIOUS_METALS"));
		selectDropdown(ICDD_Forms_Obj.ROUGH_DIAMONDS, testData.get("ROUGH_DIAMONDS"));
		selectDropdown(ICDD_Forms_Obj.KIMBERLEY_PROCESS, testData.get("KIMBERLEY_PROCESS"));
		
		selectDropdown(ICDD_Forms_Obj.GAMLING_INDUSTRY_CLIENT_DRIVE, testData.get("GAMLING_INDUSTRY_CLIENT_DRIVE"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_CONTROLLING_DIRECTOR_HNW, testData.get("CLIENT_CONTROLLING_DIRECTOR_HNW"));
		
		screenshot();
		selectDropdown(ICDD_Forms_Obj.CONCLUSION_INCOME_OR_WEALTH, testData.get("CONCLUSION_INCOME_OR_WEALTH"));
		selectDropdown(ICDD_Forms_Obj.CONCLUSION_CORROBORATED, testData.get("CONCLUSION_CORROBORATED"));
		inputText(ICDD_Forms_Obj.CONCLUSION_DETAILED_CORROBORATED, testData.get("CONCLUSION_DETAILED_CORROBORATED"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CONCLUSION_CONCERN_CLIENT_SOURCE, testData.get("CONCLUSION_CONCERN_CLIENT_SOURCE"));
		inputText(ICDD_Forms_Obj.CONCLUSION_PROVIDE_REASON, testData.get("CONCLUSION_PROVIDE_REASON"));
		screenshot();
		inputText(ICDD_Forms_Obj.CONCLUSION_EXPLAIN, testData.get("CONCLUSION_EXPLAIN"));
		click(ICDD_Forms_Obj.AM_NEXT);sleep(mediumWaitVal);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		//driver.switchTo().frame("noteModelFreeTextNote_ifr");
		//actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		inputText(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
	
	
	public void createPEPForm(String scenarioName,HashMap<String, String> testData) throws InterruptedException{
		sleep(mediumWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.PEP_EFORM);
		switchToWindow();sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.SOURCEOF_PEP_TRIGGER, testData.get("SOURCEOF_PEP_TRIGGER"));
		selectDropdown(ICDD_Forms_Obj.RELATIONSHIP_WITH_CLIENT, testData.get("RELATIONSHIP_WITH_CLIENT"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CLIENT_PEP_OR_PEPLINKED, testData.get("CLIENT_PEP_OR_PEPLINKED"));
		inputText(ICDD_Forms_Obj.NAME_OF_PROMINENTPFH, testData.get("NAME_OF_PROMINENTPFH"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.COUNTRY_OF_RESIDENCE_PFH, testData.get("COUNTRY_OF_RESIDENCE_PFH"));
		inputText(ICDD_Forms_Obj.LATEST_PUBLIC_FUNCTION, testData.get("LATEST_PUBLIC_FUNCTION"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.LATEST_COUNTRY_POWER_OR_AUTHORITY, testData.get("LATEST_COUNTRY_POWER_OR_AUTHORITY"));
		screenshot();
		inputText(ICDD_Forms_Obj.LATEST_FROM_YEAR, testData.get("LATEST_FROM_YEAR"));
		inputText(ICDD_Forms_Obj.LATEST_TO_YEAR, testData.get("LATEST_TO_YEAR"));
		inputText(ICDD_Forms_Obj.PREVIOUS_PUBLIC_FUNCTION, testData.get("PREVIOUS_PUBLIC_FUNCTION"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PREVIOUS_COUNTRY_POWER_OR_AUTHORITY, testData.get("PREVIOUS_COUNTRY_POWER_OR_AUTHORITY"));
		inputText(ICDD_Forms_Obj.PREVIOUS_FROM_YEAR, testData.get("PREVIOUS_FROM_YEAR"));
		inputText(ICDD_Forms_Obj.PREVIOUS_TO_YEAR, testData.get("PREVIOUS_TO_YEAR"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.PUBLIC_FUNCTION_HOLDING, testData.get("PUBLIC_FUNCTION_HOLDING"));sleep(minWaitVal);
		inputText(ICDD_Forms_Obj.DESCRIBE_THE_ORG, testData.get("DESCRIBE_THE_ORG"));
		screenshot();
		inputText(ICDD_Forms_Obj.DESCRIBE_THE_INDIVIDUAL, testData.get("DESCRIBE_THE_INDIVIDUAL"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PFH_STILL_IN_OFFICE, testData.get("PFH_STILL_IN_OFFICE"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PFH_LEFT_OFFICE_MONTH, testData.get("PFH_LEFT_OFFICE_MONTH"));
		inputText(ICDD_Forms_Obj.PFH_LEFT_OFFICE_YEAR, testData.get("PFH_LEFT_OFFICE_YEAR"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.FINAL_PEP_STATUS, testData.get("FINAL_PEP_STATUS"));
		inputText(ICDD_Forms_Obj.REASON_THE_CLIENT_IS_PEP, testData.get("REASON_THE_CLIENT_IS_PEP"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PEP_CATEGORY, testData.get("PEP_CATEGORY"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.COUNTRYOF_PEP_DERIVES_POWER, testData.get("COUNTRYOF_PEP_DERIVES_POWER"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PEP_DECLASSIFICATION_REQ, testData.get("PEP_DECLASSIFICATION_REQ"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.PEP_LINK_OF_INFLUENCE, testData.get("PEP_LINK_OF_INFLUENCE"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.PEP_INDUSTRY_INFLUENCE, testData.get("PEP_INDUSTRY_INFLUENCE"));sleep(minWaitVal);
		inputText(ICDD_Forms_Obj.PEP_INVOLVEMENT_IN_INDUSTRY, testData.get("PEP_INVOLVEMENT_IN_INDUSTRY"));
		screenshot();
		selectDropdown(ICDD_Forms_Obj.ADVERSE_MEDIA_ON_PEP, testData.get("ADVERSE_MEDIA_ON_PEP"));
		selectDropdown(ICDD_Forms_Obj.PEP_OTHER_SUBSTANTIAL_INCOME, testData.get("PEP_OTHER_SUBSTANTIAL_INCOME"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PEP_RECEIVED_LARGE_AMOUNT_OF_MONEY, testData.get("PEP_RECEIVED_LARGE_AMOUNT_OF_MONEY"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PEP_ASKED_FOR_ADDITIONAL_SECRECY, testData.get("PEP_ASKED_FOR_ADDITIONAL_SECRECY"));
		inputText(ICDD_Forms_Obj.PEP_SECRECY_PROVIDE_DETAILS, testData.get("PEP_SECRECY_PROVIDE_DETAILS"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.PEP_BASED_ON_TRANSACTION_REVIEW, testData.get("PEP_BASED_ON_TRANSACTION_REVIEW"));
		inputText(ICDD_Forms_Obj.PROVIDE_DETAILS_TRANSACTION_REVIEW, testData.get("PROVIDE_DETAILS_TRANSACTION_REVIEW"));sleep(minWaitVal);
		
		
		selectDropdown(ICDD_Forms_Obj.SUSPICIOUS_ACTIVITY_FILE, testData.get("SRA_SUSPICIOUS_ACTIVITY_FILE"));sleep(minWaitVal);
//		selectDropdown(ICDD_Forms_Obj.OTHER_DOMESTIC_FOREIGN_PEP, testData.get("OTHER_DOMESTIC_FOREIGN_PEP"));sleep(minWaitVal);
//		selectDropdown(ICDD_Forms_Obj.OTHER_HNW_PEP, testData.get("OTHER_HNW_PEP"));sleep(minWaitVal);
//		selectDropdown(ICDD_Forms_Obj.OTHER_PEP_VERY_HIGH_RISK_COUNTRY, testData.get("OTHER_PEP_VERY_HIGH_RISK_COUNTRY"));sleep(minWaitVal);
     	screenshot();
		selectDropdown(ICDD_Forms_Obj.DECISION_TO_ONBOARD, testData.get("DECISION_TO_ONBOARD"));
		inputText(ICDD_Forms_Obj.REASON_TO_ONBOARD_OR_RETAIN, testData.get("REASON_TO_ONBOARD_OR_RETAIN"));
		inputText(ICDD_Forms_Obj.ADDITIONAL_CONTROLS, testData.get("ADDITIONAL_CONTROLS"));
		click(ICDD_Forms_Obj.AM_NEXT);sleep(mediumWaitVal);
		
		driver.switchTo().frame("noteModelFreeTextNote_ifr");
		System.out.println("Switched to Text area Frame");
		//actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		inputText(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
		
		
	public void createAdverseMediaForm(String scenarioName,HashMap<String, String> testData){
		sleep(mediumWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.ADVERSE_MEDIA_FORM);
		switchToWindow();sleep(minWaitVal);
		webDriverwait(ICDD_Forms_Obj.NAME_OF_THE_PARTY);
		inputText(ICDD_Forms_Obj.NAME_OF_THE_PARTY, testData.get("NAME_OF_THE_PARTY"));
		selectDropdown(ICDD_Forms_Obj.RELATIONSHIP_WITH_BANK_CUSTOMER, testData.get("RELATIONSHIP_WITH_BANK_CUSTOMER"));
		inputText(ICDD_Forms_Obj.MEDIA_REPORT_HEADLINE, testData.get("MEDIA_REPORT_HEADLINE"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.TYPE_OF_ADVERSE, testData.get("TYPE_OF_ADVERSE"));sleep(minWaitVal);
		//selectDropdown(ICDD_Forms_Obj.COUNTRYOF_INCIDENT, testData.get("COUNTRYOF_INCIDENT"));
		screenshot();
		inputText(ICDD_Forms_Obj.DATEOF_ADVERSE_NEWS, testData.get("DATEOF_ADVERSE_NEWS"));
		selectDropdown(ICDD_Forms_Obj.REGULATORY_ACTION, testData.get("REGULATORY_ACTION"));
		inputText(ICDD_Forms_Obj.DATE_OF_REGULATORY_ACTION, testData.get("DATE_OF_REGULATORY_ACTION"));
		inputText(ICDD_Forms_Obj.TYPEOF_REGULATORY_ACTION, testData.get("TYPEOF_REGULATORY_ACTION"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.SOURCEOF_ADVERSE_MEDIA, testData.get("SOURCEOF_ADVERSE_MEDIA"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CREADIBLE_NONCREADIBLE_SOURCE, testData.get("CREADIBLE_NONCREADIBLE_SOURCE"));
		screenshot();
		enterInputText(ICDD_Forms_Obj.FACTS_ALLEGATION_SPECULATION, testData.get("FACTS_ALLEGATION_SPECULATION"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.RISK_OF_ADVERSE_MEDIA, testData.get("RISK_OF_ADVERSE_MEDIA"));
		inputText(ICDD_Forms_Obj.DETAILS_ADVERSEMEDIA_REPUTATION, testData.get("DETAILS_ADVERSEMEDIA_REPUTATION"));
		inputText(ICDD_Forms_Obj.DETAILS_AM_ASSOCIATED_PARTY_BG, testData.get("DETAILS_AM_ASSOCIATED_PARTY_BG"));
		inputText(ICDD_Forms_Obj.DETAILS_AM_ASSOCIATED_PARTY_REPUTATION, testData.get("DETAILS_AM_ASSOCIATED_PARTY_REPUTATION"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CONFIRM_AM_ON_CLIENT, testData.get("CONFIRM_AM_ON_CLIENT"));
		selectDropdown(ICDD_Forms_Obj.RECOMMENDATION_BY_RM, testData.get("RECOMMENDATION_BY_RM"));
		screenshot();
		inputText(ICDD_Forms_Obj.RM_REASON_FOR_RECOM, testData.get("RM_REASON_FOR_RECOM"));
		click(ICDD_Forms_Obj.AM_NEXT);sleep(mediumWaitVal);
		
		//driver.switchTo().frame("noteModelFreeTextNote_ifr");
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		//actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		inputText(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
			
	public void createTaxEForm(String scenarioName,HashMap<String, String> testData){
		sleep(mediumWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.TAXE_FORM);
		switchToWindow();sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.SUBJECTOF_ADVERSE_TAX_NEWS, testData.get("SUBJECTOF_ADVERSE_TAX_NEWS"));
		inputText(ICDD_Forms_Obj.TAX_NEWS_COMMENTS, testData.get("TAX_NEWS_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_UNWILLING_TO_SHARE_INFO, testData.get("CLIENT_UNWILLING_TO_SHARE_INFO"));
		inputText(ICDD_Forms_Obj.INFO_COMMENTS, testData.get("INFO_COMMENTS"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.INCONSISTENT_CLIENT_PROFILE_NET, testData.get("INCONSISTENT_CLIENT_PROFILE_NET"));
		screenshot();
		inputText(ICDD_Forms_Obj.INCONSISTENCY_COMMENTS, testData.get("INCONSISTENCY_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_LIQUID_ASSET, testData.get("CLIENT_LIQUID_ASSET"));
		inputText(ICDD_Forms_Obj.LIQUID_COMMENT, testData.get("LIQUID_COMMENT"));
		selectDropdown(ICDD_Forms_Obj.PERSONAL_INVESTMENT_VEHICLE, testData.get("PERSONAL_INVESTMENT_VEHICLE"));
		inputText(ICDD_Forms_Obj.PERSONAL_INVESTMENT_COMMENT, testData.get("PERSONAL_INVESTMENT_COMMENT"));
		selectDropdown(ICDD_Forms_Obj.MANAGED_CLIENT_ASSET, testData.get("MANAGED_CLIENT_ASSET"));
		screenshot();
		inputText(ICDD_Forms_Obj.MANAGED_CLIENT_ASSET_COMMENTS, testData.get("MANAGED_CLIENT_ASSET_COMMENTS"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CLIENT_PAYMENT, testData.get("CLIENT_PAYMENT"));
		inputText(ICDD_Forms_Obj.CLIENT_PAYMENT_COMMENTS, testData.get("CLIENT_PAYMENT_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_ACC_MAINTANENCE, testData.get("CLIENT_ACC_MAINTANENCE"));
		inputText(ICDD_Forms_Obj.CLIENT_ACC_MAINTANENCE_COMMENTS, testData.get("CLIENT_ACC_MAINTANENCE_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_COMMERCIAL_TXN, testData.get("CLIENT_COMMERCIAL_TXN"));
		inputText(ICDD_Forms_Obj.CLIENT_COMMERCIAL_TXN_COMMENTS, testData.get("CLIENT_COMMERCIAL_TXN_COMMENTS"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.CONTACT_BTW_CLIENT_AND_BANK, testData.get("CONTACT_BTW_CLIENT_AND_BANK"));
		screenshot();
		inputText(ICDD_Forms_Obj.CONTACT_BTW_CLIENT_AND_BANK_COMMENTS, testData.get("CONTACT_BTW_CLIENT_AND_BANK_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_SAR, testData.get("CLIENT_SAR"));
		inputText(ICDD_Forms_Obj.CLIENT_SAR_COMMENTS, testData.get("CLIENT_SAR_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_TRANSFERRING_FUNDS, testData.get("CLIENT_TRANSFERRING_FUNDS"));
		inputText(ICDD_Forms_Obj.CLIENT_TRANSFERRING_FUNDS_COMMENTS, testData.get("CLIENT_TRANSFERRING_FUNDS_COMMENTS"));
		selectDropdown(ICDD_Forms_Obj.TAX_EVASION_RED_FLAG, testData.get("TAX_EVASION_RED_FLAG"));sleep(minWaitVal);
		inputText(ICDD_Forms_Obj.REASON_FOR_RED_FLAG, testData.get("REASON_FOR_RED_FLAG"));
		selectDropdown(ICDD_Forms_Obj.RM_RECOMMENDATION, testData.get("RM_RECOMMENDATION"));
		screenshot();
		inputText(ICDD_Forms_Obj.REASON_FOR_MAINTAINING_REL, testData.get("REASON_FOR_MAINTAINING_REL"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.SUGGESTED_ACTION, testData.get("SUGGESTED_ACTION"));
		click(ICDD_Forms_Obj.AM_NEXT);sleep(mediumWaitVal);
		driver.switchTo().frame("noteModelFreeTextNote_ifr");
		actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));sleep(minWaitVal);
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
	
	public void createClientContact(String scenarioName,HashMap<String, String> testData){
		sleep(minWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CLIENT_CONTACT_FORM);
		switchToWindow();sleep(minWaitVal);
		inputText(ICDD_Forms_Obj.DATE_AND_TIME_OF_CONTACT, testData.get("DATE_AND_TIME_OF_CONTACT"));
		selectDropdown(ICDD_Forms_Obj.NATURE_OF_CONTACT, testData.get("NATURE_OF_CONTACT"));sleep(minWaitVal);
		actionEnterData(ICDD_Forms_Obj.ATTENDEES, testData.get("ATTENDEES"));
		inputText(ICDD_Forms_Obj.DESCRIPTION_OF_CLIENT_CONTACT, testData.get("DESCRIPTION_OF_CLIENT_CONTACT"));
		selectDropdown(ICDD_Forms_Obj.EVENT_TYPE, testData.get("EVENT_TYPE"));
		inputText(ICDD_Forms_Obj.GENERATED_DATEOF_LETTERSMS, testData.get("GENERATED_DATEOF_LETTERSMS"));
		screenshot();
		inputText(ICDD_Forms_Obj.LETTER_REF_EMAIL, testData.get("LETTER_REF_EMAIL"));
		inputText(ICDD_Forms_Obj.DATE_AND_TIME_OF_CONTACT2, testData.get("DATE_AND_TIME_OF_CONTACT2"));
		selectDropdown(ICDD_Forms_Obj.NATURE_OF_CONTACT2, testData.get("NATURE_OF_CONTACT2"));sleep(minWaitVal);
		actionEnterData(ICDD_Forms_Obj.ATTENDEES2, testData.get("ATTENDEES2"));
		inputText(ICDD_Forms_Obj.DESCRIPTION_OF_CLIENT_CONTACT2, testData.get("DESCRIPTION_OF_CLIENT_CONTACT2"));
		selectDropdown(ICDD_Forms_Obj.EVENT_TYPE2, testData.get("EVENT_TYPE2"));
		inputText(ICDD_Forms_Obj.GENERATED_DATEOF_LETTERSMS2, testData.get("GENERATED_DATEOF_LETTERSMS2"));
		screenshot();
		inputText(ICDD_Forms_Obj.LETTER_REF_EMAIL2, testData.get("LETTER_REF_EMAIL2"));
		inputText(ICDD_Forms_Obj.DATE_AND_TIME_OF_CONTACT3, testData.get("DATE_AND_TIME_OF_CONTACT3"));
		selectDropdown(ICDD_Forms_Obj.NATURE_OF_CONTACT3, testData.get("NATURE_OF_CONTACT3"));sleep(minWaitVal);
		actionEnterData(ICDD_Forms_Obj.ATTENDEES3, testData.get("ATTENDEES3"));
		inputText(ICDD_Forms_Obj.DESCRIPTION_OF_CLIENT_CONTACT3, testData.get("DESCRIPTION_OF_CLIENT_CONTACT3"));
		selectDropdown(ICDD_Forms_Obj.EVENT_TYPE3, testData.get("EVENT_TYPE3"));
		screenshot();
		inputText(ICDD_Forms_Obj.GENERATED_DATEOF_LETTERSMS3, testData.get("GENERATED_DATEOF_LETTERSMS3"));
		inputText(ICDD_Forms_Obj.LETTER_REF_EMAIL3, testData.get("LETTER_REF_EMAIL3"));
		inputText(ICDD_Forms_Obj.DATE_AND_TIME_OF_CONTACT4, testData.get("DATE_AND_TIME_OF_CONTACT4"));
		selectDropdown(ICDD_Forms_Obj.NATURE_OF_CONTACT4, testData.get("NATURE_OF_CONTACT4"));sleep(minWaitVal);
		actionEnterData(ICDD_Forms_Obj.ATTENDEES4, testData.get("ATTENDEES4"));
		inputText(ICDD_Forms_Obj.DESCRIPTION_OF_CLIENT_CONTACT4, testData.get("DESCRIPTION_OF_CLIENT_CONTACT4"));
		selectDropdown(ICDD_Forms_Obj.EVENT_TYPE4, testData.get("EVENT_TYPE4"));
		screenshot();
		inputText(ICDD_Forms_Obj.GENERATED_DATEOF_LETTERSMS4, testData.get("GENERATED_DATEOF_LETTERSMS4"));
		inputText(ICDD_Forms_Obj.LETTER_REF_EMAIL4, testData.get("LETTER_REF_EMAIL4"));
		inputText(ICDD_Forms_Obj.DATE_AND_TIME_OF_CONTACT5, testData.get("DATE_AND_TIME_OF_CONTACT5"));
		selectDropdown(ICDD_Forms_Obj.NATURE_OF_CONTACT5, testData.get("NATURE_OF_CONTACT5"));sleep(minWaitVal);
		actionEnterData(ICDD_Forms_Obj.ATTENDEES5, testData.get("ATTENDEES5"));
		inputText(ICDD_Forms_Obj.DESCRIPTION_OF_CLIENT_CONTACT5, testData.get("DESCRIPTION_OF_CLIENT_CONTACT5"));
		selectDropdown(ICDD_Forms_Obj.EVENT_TYPE5, testData.get("EVENT_TYPE5"));
		screenshot();
		inputText(ICDD_Forms_Obj.GENERATED_DATEOF_LETTERSMS5, testData.get("GENERATED_DATEOF_LETTERSMS5"));
		inputText(ICDD_Forms_Obj.LETTER_REF_EMAIL5, testData.get("LETTER_REF_EMAIL5"));
		click(ICDD_Forms_Obj.AM_NEXT);sleep(mediumWaitVal);
		//driver.switchTo().frame("noteModelFreeTextNote_ifr");
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));sleep(minWaitVal);
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
	
	public void AdditionCDDform(String scenarioName,HashMap<String, String> testData){
		sleep(mediumWaitVal);
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.ADDITIONAL_CDD_FORM);
		switchToWindow();
		selectDropdown(ICDD_Forms_Obj.NAME_SCREENING_TRUE_MATCH, testData.get("NAME_SCREENING_TRUE_MATCH"));sleep(minWaitVal);
		enterInputText(ICDD_Forms_Obj.NAME_SCREENING_MATCH, testData.get("NAME_SCREENING_MATCH"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_SANCTIONED_FINAL_DECISION, testData.get("CLIENT_SANCTIONED_FINAL_DECISION"));
		inputText(ICDD_Forms_Obj.SANCTIONS_LINKS_SUMMARY, testData.get("SANCTIONS_LINKS_SUMMARY"));
		selectDropdown(ICDD_Forms_Obj.SENSITIVE_CLIENT, testData.get("SENSITIVE_CLIENT"));
		selectDropdown(ICDD_Forms_Obj.NTBR, testData.get("NTBR"));
		inputText(ICDD_Forms_Obj.NTBR_RATIONALE, testData.get("NTBR_RATIONALE"));
		selectDropdown(ICDD_Forms_Obj.DORMANT_REACTIVATION, testData.get("DORMANT_REACTIVATION"));
		driver.findElement(ICDD_Forms_Obj.CDD_SAVE).click();
		enter();
		sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
	}
	
	
	public void CreateReviewChecklist(String scenarioName,HashMap<String, String> testData) throws Exception{
		sleep(mediumWaitVal);
		screenshot();
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CREATE_REVIEW_CHECKLIST_FORM);
		switchToWindow();
		selectDropdown(ICDD_Forms_Obj.REVIEW_CHECKS_LATEST_ALERT, testData.get("REVIEW_CHECKS_LATEST_ALERT"));
		inputText(ICDD_Forms_Obj.ALERT_ID, testData.get("ALERT_ID"));
		actionEnterData(ICDD_Forms_Obj.ALERT_DATE, testData.get("ALERT_DATE"));
		inputText(ICDD_Forms_Obj.ALERT_REMARKS, testData.get("ALERT_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.CLIENT_FULL_NAME_UPDATED, testData.get("CLIENT_FULL_NAME_UPDATED"));
		inputText(ICDD_Forms_Obj.CLIENT_FULL_NAME_CURRENT_VALUE, testData.get("CLIENT_FULL_NAME_CURRENT_VALUE"));
		inputText(ICDD_Forms_Obj.CLIENT_FULL_NAME_UPDATED_VALUE, testData.get("CLIENT_FULL_NAME_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.CLIENT_FULL_NAME_REMARKS, testData.get("CLIENT_FULL_NAME_REMARKS"));
		screenshot();
		selectDropdown(ICDD_Forms_Obj.FORMER_UPDATED, testData.get("FORMER_UPDATED"));
		inputText(ICDD_Forms_Obj.FORMER_CURRENT_VALUE, testData.get("FORMER_CURRENT_VALUE"));
		inputText(ICDD_Forms_Obj.FORMER_UPDATED_VALUE, testData.get("FORMER_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.FORMER_REMARKS, testData.get("FORMER_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.ID_DETAILS_UPDATED, testData.get("ID_DETAILS_UPDATED"));
		inputText(ICDD_Forms_Obj.ID_DETAILS_CURRENT_VALUE, testData.get("ID_DETAILS_CURRENT_VALUE"));
		inputText(ICDD_Forms_Obj.ID_DETAILS_UPDATED_VALUE, testData.get("ID_DETAILS_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.ID_DETAILS_REMARKS, testData.get("ID_DETAILS_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.NATIONALITY_UPDATED, testData.get("NATIONALITY_UPDATED"));
		inputText(ICDD_Forms_Obj.NATIONALITY_CURRENT_VALUE, testData.get("NATIONALITY_CURRENT_VALUE"));
		inputText(ICDD_Forms_Obj.NATIONALITY_UPDATED_VALUE, testData.get("NATIONALITY_UPDATED_VALUE"));
		screenshot();
		inputText(ICDD_Forms_Obj.NATIONALITY_REMARKS, testData.get("NATIONALITY_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.RESIDENTIAL_ADDRESS_UPDATED, testData.get("RESIDENTIAL_ADDRESS_UPDATED"));
		inputText(ICDD_Forms_Obj.RESIDENTIAL_ADDRESS_CURRENT_VALUE, testData.get("RESIDENTIAL_ADDRESS_CURRENT_VALUE"));
		inputText(ICDD_Forms_Obj.RESIDENTIAL_ADDRESS_UPDATED_VALUE, testData.get("RESIDENTIAL_ADDRESS_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.RESIDENTIAL_ADDRESS_REMARKS, testData.get("RESIDENTIAL_ADDRESS_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.CONTACT_UPDATED, testData.get("CONTACT_UPDATED"));
		inputText(ICDD_Forms_Obj.CONTACT_URRENT_VALUE, testData.get("CONTACT_URRENT_VALUE"));
		inputText(ICDD_Forms_Obj.CONTACT_UPDATED_VALUE, testData.get("CONTACT_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.CONTACT_REMARKS, testData.get("CONTACT_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.DATE_OF_BIRTH_UPDATED, testData.get("DATE_OF_BIRTH_UPDATED"));
		inputText(ICDD_Forms_Obj.DATE_OF_BIRTH_URRENT_VALUE, testData.get("DATE_OF_BIRTH_URRENT_VALUE"));
		screenshot();
		inputText(ICDD_Forms_Obj.DATE_OF_BIRTH_UPDATED_VALUE, testData.get("DATE_OF_BIRTH_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.DATE_OF_BIRTH_REMARKS, testData.get("DATE_OF_BIRTH_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.COUNTRY_OF_BIRTH_UPDATED, testData.get("COUNTRY_OF_BIRTH_UPDATED"));
		inputText(ICDD_Forms_Obj.COUNTRY_OF_BIRTH_URRENT_VALUE, testData.get("COUNTRY_OF_BIRTH_URRENT_VALUE"));
		inputText(ICDD_Forms_Obj.COUNTRY_OF_BIRTH_UPDATED_VALUE, testData.get("COUNTRY_OF_BIRTH_UPDATED_VALUE"));
		inputText(ICDD_Forms_Obj.COUNTRY_OF_BIRTH_REMARKS, testData.get("COUNTRY_OF_BIRTH_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_ALERT_GENERATED, testData.get("A_ALERT_GENERATED"));
		inputText(ICDD_Forms_Obj.A_ALERT_GENERATED_REMARKS, testData.get("A_ALERT_GENERATED_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_PEP, testData.get("A_CLIENT_PEP"));
		screenshot();
		inputText(ICDD_Forms_Obj.A_CLIENT_REMARKS, testData.get("A_CLIENT_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.C_PISE_TOOL, testData.get("C_PISE_TOOL"));
		inputText(ICDD_Forms_Obj.C_PISE_TOOL_REMARKS, testData.get("C_PISE_TOOL_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_ADVERSE_MEDIA_INFO, testData.get("A_ADVERSE_MEDIA_INFO"));
		inputText(ICDD_Forms_Obj.A_ADVERSE_MEDIA_INFO_REMARKS, testData.get("A_ADVERSE_MEDIA_INFO_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_ADVERSE_MEDIA_eFORM, testData.get("A_ADVERSE_MEDIA_eFORM"));
		inputText(ICDD_Forms_Obj.A_ADVERSE_MEDIA_eFORM_REMARKS, testData.get("A_ADVERSE_MEDIA_eFORM_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.C_CLIENT_ACCOUNT_ACTIVITY, testData.get("C_CLIENT_ACCOUNT_ACTIVITY"));
		inputText(ICDD_Forms_Obj.C_CLIENT_ACCOUNT_ACTIVITY_REMARKS, testData.get("C_CLIENT_ACCOUNT_ACTIVITY_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_CASA_ACCOUNT_OPENING_CONSITENT, testData.get("A_CASA_ACCOUNT_OPENING_CONSITENT"));
		inputText(ICDD_Forms_Obj.A_CASA_ACCOUNT_OPENING_CONSITENT_REMARKS, testData.get("A_CASA_ACCOUNT_OPENING_CONSITENT_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_CASA_FOR_BUSINESS, testData.get("A_CASA_FOR_BUSINESS"));
		inputText(ICDD_Forms_Obj.A_CASA_FOR_BUSINESS_REMARKS, testData.get("A_CASA_FOR_BUSINESS_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT, testData.get("A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT"));
		inputText(ICDD_Forms_Obj.A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT_REMARKS, testData.get("A_CLIENT_MIGRATED_TO_BUSINESS_SEGMENT_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.C_SOWFORM_UPDATED, testData.get("C_SOWFORM_UPDATED"));
		screenshot();
		inputText(ICDD_Forms_Obj.C_SOWFORM_UPDATED_REMARKS, testData.get("C_SOWFORM_UPDATED_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.C_HNW_TAX_FORM, testData.get("C_HNW_TAX_FORM"));
		inputText(ICDD_Forms_Obj.C_HNW_TAX_FORM_REMARKS, testData.get("C_HNW_TAX_FORM_REMARKS"));
		selectDropdown(ICDD_Forms_Obj.A_ADDRESS_INVALID_INDICATOR, testData.get("A_ADDRESS_INVALID_INDICATOR"));
		inputText(ICDD_Forms_Obj.A_ADDRESS_INVALID_INDICATOR_REMARKS, testData.get("A_ADDRESS_INVALID_INDICATOR_REMARKS"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_INDUSTORY_APPEAR_VALID, testData.get("A_CLIENT_INDUSTORY_APPEAR_VALID"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_INDUSTORY_APPEAR_VALID_INDUSTRY, testData.get("A_CLIENT_INDUSTORY_APPEAR_VALID_INDUSTRY"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_JOB_APPEAR_VALID, testData.get("A_CLIENT_JOB_APPEAR_VALID"));
		//selectDropdown(ICDD_Forms_Obj.A_CLIENT_JOB_APPEAR_VALID_OCC, testData.get("A_CLIENT_JOB_APPEAR_VALID_OCC"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_FULL_NAME, testData.get("A_CLIENT_FULL_NAME"));
		screenshot();
		inputText(ICDD_Forms_Obj.A_CLIENT_FULL_NAME_NEWVAL, testData.get("A_CLIENT_FULL_NAME_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_FORMER, testData.get("A_CLIENT_FORMER"));
		inputText(ICDD_Forms_Obj.A_CLIENT_FORMER_NEWVAL, testData.get("A_CLIENT_FORMER_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_ID, testData.get("A_CLIENT_ID"));
		inputText(ICDD_Forms_Obj.A_CLIENT_ID_NEWVAL, testData.get("A_CLIENT_ID_NEWVAL"));sleep(minWaitVal);
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_NATIONALITY, testData.get("A_CLIENT_NATIONALITY"));
		inputText(ICDD_Forms_Obj.A_CLIENT_NATIONALITY_NEWVAL, testData.get("A_CLIENT_NATIONALITY_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_RESIDENTIAL_ADD, testData.get("A_CLIENT_RESIDENTIAL_ADD"));
		inputText(ICDD_Forms_Obj.A_CLIENT_RESIDENTIAL_ADD_NEWVAL, testData.get("A_CLIENT_RESIDENTIAL_ADD_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_ISD_PHONE, testData.get("A_CLIENT_ISD_PHONE"));
		inputText(ICDD_Forms_Obj.A_CLIENT_ISD_PHONE_NEWVAL, testData.get("A_CLIENT_ISD_PHONE_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_DOB, testData.get("A_CLIENT_DOB"));
		screenshot();
		
		inputText(ICDD_Forms_Obj.A_CLIENT_DOB_NEWVAL, testData.get("A_CLIENT_DOB_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_COUNTRYOFBIRTH, testData.get("A_CLIENT_COUNTRYOFBIRTH"));
		inputText(ICDD_Forms_Obj.A_CLIENT_COUNTRYOFBIRTH_NEWVAL, testData.get("A_CLIENT_COUNTRYOFBIRTH_NEWVAL"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_CHANGE_BUSINESS, testData.get("A_CLIENT_CHANGE_BUSINESS"));
		selectDropdown(ICDD_Forms_Obj.A_CLIENT_CHANGE_BUSINESS_NEWVAL, testData.get("A_CLIENT_CHANGE_BUSINESS_NEWVAL"));
		inputText(ICDD_Forms_Obj.A_CLIENT_NAMEOF_CURRENT_EMPLOYER, testData.get("A_CLIENT_NAMEOF_CURRENT_EMPLOYER"));
		inputText(ICDD_Forms_Obj.A_CLIENT_NAMEOF_CURRENT_EMPLOYER_REMARKS, testData.get("A_CLIENT_NAMEOF_CURRENT_EMPLOYER_REMARKS"));
		//selectDropdown(ICDD_Forms_Obj.A_CLIENT_CURRENT_WORKTYPE, testData.get("A_CLIENT_CURRENT_WORKTYPE"));
		inputText(ICDD_Forms_Obj.A_CLIENT_CURRENT_WORKTYPE_REMARKS, testData.get("A_CLIENT_CURRENT_WORKTYPE_REMARKS"));
		//selectDropdown(ICDD_Forms_Obj.A_CLIST_AND_ADVICE_THE_CLIENT, testData.get("A_CLIST_AND_ADVICE_THE_CLIENT"));
		//selectDropdown(ICDD_Forms_Obj.A_CLIENT_PROVIDE_EXPLANATION, testData.get("A_CLIENT_PROVIDE_EXPLANATION"));
		//selectDropdown(ICDD_Forms_Obj.A_CLIENT_RELEVANT_STATIC_DATA_REQ, testData.get("A_CLIENT_RELEVANT_STATIC_DATA_REQ"));
		inputText(ICDD_Forms_Obj.A_CLIENT_USER_COMMENTS, testData.get("A_CLIENT_USER_COMMENTS"));
		screenshot();
		click(ICDD_Forms_Obj.AM_NEXT);
		sleep(minWaitVal);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
        screenshot();
	}
	
	public void NewCreateReviewChecklist(String scenarioName,HashMap<String, String> testData) throws Exception{
		
		sleep(mediumWaitVal);
		sleep(minWaitVal);
		screenshot();
		actionMouseHover(ICDD_Forms_Obj.FORMSTAB, ICDD_Forms_Obj.CREATE_REVIEW_CHECKLIST_FORM);
		switchToWindow();
		selectDropdown(ICDD_Forms_Obj.REVIEW_CHECKS_LATEST_ALERT_NEW, testData.get("REVIEW_CHECKS_LATEST_ALERT_NEW"));
		inputText(ICDD_Forms_Obj.ALERT_ID_NEW, testData.get("ALERT_ID_NEW"));
		actionEnterData(ICDD_Forms_Obj.ALERT_DATE_NEW, testData.get("ALERT_DATE_NEW"));
		inputText(ICDD_Forms_Obj.ALERT_REMARKS_NEW, testData.get("ALERT_REMARKS_NEW"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_STATIC_DATA_INFO, testData.get("CLIENT_STATIC_DATA_INFO"));
		inputText(ICDD_Forms_Obj.CLIENT_STATIC_DATA_REMARKS, testData.get("CLIENT_STATIC_DATA_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_EMPLOYEEMENT_DETAILS, testData.get("CLIENT_EMPLOYEEMENT_DETAILS"));
		inputText(ICDD_Forms_Obj.CLIENT_EMPLOYEEMENT_REMARKS, testData.get("CLIENT_EMPLOYEEMENT_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_WORK_TYPE, testData.get("CLIENT_WORK_TYPE"));
		inputText(ICDD_Forms_Obj.CLIENT_WORK_REMARKS, testData.get("CLIENT_WORK_REMARKS"));
		
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_OCCUPATION, testData.get("CLIENT_OCCUPATION"));
		inputText(ICDD_Forms_Obj.CLIENT_OCCUPATION_REMARKS, testData.get("CLIENT_OCCUPATION_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_INDUSTRY, testData.get("CLIENT_INDUSTRY"));
		inputText(ICDD_Forms_Obj.CLIENT_INDUSTRY_REMARKS, testData.get("CLIENT_INDUSTRY_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_INDICATOR_FLAG_ADDRESS, testData.get("CLIENT_INDICATOR_FLAG_ADDRESS"));
		inputText(ICDD_Forms_Obj.CLIENT_INDICATOR_FLAG_ADDRESS_REMARKS, testData.get("CLIENT_INDICATOR_FLAG_ADDRESS_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.CLIENT_UPDATE_IN_ICM, testData.get("CLIENT_UPDATE_IN_ICM"));
		inputText(ICDD_Forms_Obj.CLIENT_UPDATE_IN_ICM_REMARKS, testData.get("CLIENT_UPDATE_IN_ICM_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_A_RELEATED_PARTIES, testData.get("FOR_A_RELEATED_PARTIES"));
		inputText(ICDD_Forms_Obj.FOR_A_RELEATED_PARTIES_REMARKS, testData.get("FOR_A_RELEATED_PARTIES_REMARKS"));
		screenshot();
		selectDropdown(ICDD_Forms_Obj.FOR_A_PEP_RISK_EVENT, testData.get("FOR_A_PEP_RISK_EVENT"));
		inputText(ICDD_Forms_Obj.FOR_A_PEP_RISK_EVENT_REMARKS, testData.get("FOR_A_PEP_RISK_EVENT_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_A_ADVERSE_MEDIA_EVENT, testData.get("FOR_A_ADVERSE_MEDIA_EVENT"));
		inputText(ICDD_Forms_Obj.FOR_A_ADVERSE_MEDIA_EVENT_REMARKS, testData.get("FOR_A_ADVERSE_MEDIA_EVENT_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_SOW_REVIEW, testData.get("FOR_C_SOW_REVIEW"));
		inputText(ICDD_Forms_Obj.FOR_C_SOW_REVIEW_REMARKS, testData.get("FOR_C_SOW_REVIEW_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_INTERNET_SEARCH, testData.get("FOR_C_INTERNET_SEARCH"));
		inputText(ICDD_Forms_Obj.FOR_C_INTERNET_SEARCH_REMARKS, testData.get("FOR_C_INTERNET_SEARCH_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_NEW_RISK_FACTOR, testData.get("FOR_C_NEW_RISK_FACTOR"));
		inputText(ICDD_Forms_Obj.FOR_C_NEW_RISK_FACTOR_REMARKS, testData.get("FOR_C_NEW_RISK_FACTOR_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_CASA_ACCOUNTS, testData.get("FOR_C_CASA_ACCOUNTS"));
		inputText(ICDD_Forms_Obj.FOR_C_CASA_ACCOUNTS_REMARKS, testData.get("FOR_C_CASA_ACCOUNTS_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_BUSINESS_ACCOUNTS, testData.get("FOR_C_BUSINESS_ACCOUNTS"));
		inputText(ICDD_Forms_Obj.FOR_C_BUSINESS_ACCOUNTS_REMARKS, testData.get("FOR_C_BUSINESS_ACCOUNTS_REMARKS"));
		screenshot();
		selectDropdown(ICDD_Forms_Obj.FOR_C_CASA_CREDIT_TRANSACTION, testData.get("FOR_C_CASA_CREDIT_TRANSACTION"));
		inputText(ICDD_Forms_Obj.FOR_C_CASA_CREDIT_TRANSACTION_REMARKS, testData.get("FOR_C_CASA_CREDIT_TRANSACTION_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_CASA_EXPALNAITION_ON_CREDITS, testData.get("FOR_C_CASA_EXPALNAITION_ON_CREDITS"));
		inputText(ICDD_Forms_Obj.FOR_C_CASA_EXPALNAITION_ON_CREDITS_REMARKS, testData.get("FOR_C_CASA_EXPALNAITION_ON_CREDITS_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_ESCALATED_TO_CDD_ADVISOR, testData.get("FOR_C_ESCALATED_TO_CDD_ADVISOR"));
		inputText(ICDD_Forms_Obj.FOR_C_ESCALATED_TO_CDD_ADVISOR_REMARKS, testData.get("FOR_C_ESCALATED_TO_CDD_ADVISOR_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_HNW_TAX, testData.get("FOR_C_HNW_TAX"));
		inputText(ICDD_Forms_Obj.FOR_C_HNW_TAX_REMARKS, testData.get("FOR_C_HNW_TAX_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_UHNW_CLIENT, testData.get("FOR_C_UHNW_CLIENT"));
		inputText(ICDD_Forms_Obj.FOR_C_UHNW_CLIENT_REMARKS, testData.get("FOR_C_UHNW_CLIENT_REMARKS"));
		
		selectDropdown(ICDD_Forms_Obj.FOR_C_SANCTIONED_CLIENT, testData.get("FOR_C_SANCTIONED_CLIENT"));
		inputText(ICDD_Forms_Obj.FOR_C_SANCTIONED_CLIENT_REMARKS, testData.get("FOR_C_SANCTIONED_CLIENT_REMARKS"));
	    
		selectDropdown(ICDD_Forms_Obj.FOR_C_SANCTIONED_CLIENT_ESCALATION, testData.get("FOR_C_SANCTIONED_CLIENT_ESCALATION"));
		inputText(ICDD_Forms_Obj.FOR_C_SANCTIONED_CLIENT_ESCALATION_REMARKS, testData.get("FOR_C_SANCTIONED_CLIENT_ESCALATION_REMARKS"));
	
		selectDropdown(ICDD_Forms_Obj.CLIENT_CONTACT_ADVISED, testData.get("CLIENT_CONTACT_ADVISED"));
		inputText(ICDD_Forms_Obj.CLIENT_CONTACT_ADVISED_REMARKS, testData.get("CLIENT_CONTACT_ADVISED_REMARKS"));
		screenshot();
		
		click(ICDD_Forms_Obj.AM_NEXT);
		sleep(minWaitVal);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
        screenshot();


		
		
		

	
	}
	
}
