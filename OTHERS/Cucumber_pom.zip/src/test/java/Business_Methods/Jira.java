package Business_Methods;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utillities.BaseTestSetup;
import utillities.Common_Utils;

public class Jira extends Common_Utils{
	WebDriver driver = BaseTestSetup.driver;
	public void getStatosphere() throws Exception{
		inputText(By.id("login-form-username"), "1583388");
		waitForElement(By.id("login-form-password"));
		inputText(By.id("login-form-password"), "Strength@1205");
		click(By.id("login"));sleep(5000);
		//search JIRA_ID
		waitForElement(By.id("quickSearchInput"));
		enterInputText(By.id("quickSearchInput"), "ICDDCR-875");sleep(5000);
		waitForElement(By.id("stateoscope-tabpanel"));
		WebElement Stateoscope = driver.findElement(By.id("stateoscope-tabpanel"));
		scrollUpVertical(Stateoscope);
		Stateoscope.click();sleep(5000);
		//waitForElement(By.id("stateoscope-tabpanel"));
	}
}
