package Business_Methods;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;
import utillities.screenshot;

public class ICDD_WorkItem extends Common_Utils{
	
	public static String riskLevel;
	public static String alertStep;
	public static String issue;
	public static String issuetype;
	public static List<String> inputList;
	public static List<WebElement> UiRowEleList;
	public static List<String> UiTextList=new ArrayList<String>();
	public static String[] newStr;
	public static String[] toCompare;
	public String toadd;
	DataProvider dataprovider = new DataProvider();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	//screenshot screenshot = new screenshot();
	
	public  void loginApplication(String uname, String pwd) throws Exception{
		try{
			BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.LOGINPAGE_USERNAME).sendKeys(uname);
			BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.LOGINPAGE_PASSWORD).sendKeys(pwd);
			BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.LOGINPAGE_LOGIN).click();sleep(minWaitVal);
			Log.info("User is able to logged In Successfully ICCD Application");
			screenshot();}
		catch (Exception e){
			screenshot();
			 Log.error("Unable to Login ICDD Application" + e.getMessage());
			 throw new Exception("Error while login please refer above exception"+" :"+e.getMessage()); }
	   }
	
	
	public void Workbench() throws Exception{
		 try{
			Log.info("Entered into Workbench page");
			Thread.sleep(7000);
			WebElement mainMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.WORKBENCH_MENU_TAB);
			Actions action = new Actions(BaseTestSetup.driver);
			//action.moveToElement(mainMenu).build().perform();
			//WebElement subMenu = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.WORKITEM);
			action.moveToElement(mainMenu).click().build().perform();	
			Log.info("User is able to clicked on Work Item Sucessfully");}
		  catch (Exception e) {
			Log.error("User is able to clicked on Work Item Sucessfully");
			screenshot();
	        throw new Exception("Error while navigating to the page " + e.getMessage());}
		    }
		
	public void selectOptionsInMyItems(String workitem) throws Exception {
		     Thread.sleep(10000);
		     WebElement element1=BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.MYWORK_ITEM_DROPDOWN);
		     element1.click();
		     List<WebElement> listOfOptions = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.WORKITEMS_ALL_OPTIONS);
		     for (WebElement option : listOfOptions) {
		     if (option.getText().trim().equalsIgnoreCase(workitem.trim())) {
		     triggerOnClick(option);
		     Log.info("Use is able to select vlues from drop down Sucessfully");
		     break;}}
		}          
		 
	 public void searchcustomeralerts(String customeralert) throws Exception{
		try{
			sleep(minWaitVal);
	        String refIDText = "document.getElementById('toolbarFilterTextArea').value ='" + customeralert + "';";
	        JavascriptExecutor js = (JavascriptExecutor) BaseTestSetup.driver; 
	       // System.out.println("pKey" + refIDText);
	        WebDriverWait wait = new WebDriverWait(BaseTestSetup.driver, 50);
	        wait.until(ExpectedConditions.elementToBeClickable(By.id("toolbarFilterTextArea")));
	        js.executeScript(refIDText);
	        Thread.sleep(3000);
	        WebElement filterBox = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.SEARCH);
	        filterBox.sendKeys(Keys.ENTER);
	        Log.info("Use is able to Search the Application ID Sucessfully");
	        screenshot(); }
	    catch (Exception e) {
	      	Log.error("Use is Unable to Search the Application ID Sucessfully");
	        	screenshot();
	            throw new Exception("Error while searching the ref_id" + " :" + e.getMessage());}
	        }
	 
	 public void searchOpenAlerts(String customeralert, HashMap<String, String> testData) throws Exception{
		 	sleep(minWaitVal);
		 	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		 	sleep(minWaitVal);
		 	enterInputText(ICDD_WorkItem_Obj.SEARCH, customeralert);sleep(minWaitVal);
		 	webDriverwait(By.xpath("//a[text()='"+customeralert+"']"));
		 	click(By.xpath("//a[text()='"+customeralert+"']"));sleep(mediumWaitVal);
		 	//waitForTextToLoad((ICDD_WorkItem_Obj.INITIATE_TRIGGER_REVIEW), "Initiate Trigger Review");
		 	Log.info(customeralert + " customer alert is opened successfully");
		 	System.out.println(customeralert + " customer alert is opened successfully");
	 		}
	 
	 public String getAlertStep() throws Exception{
		try{
			sleep(minWaitVal);
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	        int stepColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Step");
	        for (int i = 2; i <= n; i++) {
	        WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stepColumnNumber + "]"));
	        alertStep = we.getText();
	        System.out.print("got alert step");}}
		catch (Exception e) {
	    	Log.error("Error while getting the step of the alert" + " :" + e.getMessage());}
	      	return alertStep;
	  		}		
			
		    	
	public String getRiskLevel() throws Exception {
		try {
			Thread.sleep(10000);
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	        int riskColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Risk Level");
	        for (int i = 2; i <= n; i++) {
	        WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + riskColumnNumber + "]"));
			riskLevel = we.getText();
			System.out.print("got Risk level");}}
	    catch (Exception e) {
		    Log.error("Error while getting the risk level of the alert" + " :" + e.getMessage());}
			return riskLevel;
			}
			

	public String getOwnerName() throws Exception {
		try {
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
			int ownerColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Owner");
			for (int i = 2; i <= n; i++) {
            WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + ownerColumnNumber + "]"));
		    System.out.println("Issue Name:" + we.getText());
		    issue = we.getText();}}
		catch (Exception e) {
		     Log.error("Error while getting the issue of the alert" + " :" + e.getMessage());}
		     return issue;
		    }
	
	public String getIssueType() throws Exception {
		try {
			 Thread.sleep(10000);
		     WebElement element = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ISSUE_TYPE);
		     System.out.println("Issue Type:" + element.getText());
		     issuetype = element.getText();
		     System.out.print("got Issue Type");}
		catch (Exception e) {
		     Log.error("Error while getting the Issue Type of the alert" + " :" + e.getMessage());}
		     return issuetype;
		    }
			

	public void getIssue(HashMap<String, String> excelHashMapValues){
			 webDriverWait(ICDD_WorkItem_Obj.ISSUE);
             WebElement element = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ISSUE);
             System.out.println("Issue Name:" + element.getText());
             Log.info("Issue Name:" + element.getText());
             String actualOwnerName = element.getText();
             if (actualOwnerName.equals(excelHashMapValues.get("ownerid"))) {
            	 System.out.println("Expected Owner Name is: " + excelHashMapValues.get("ownerid") + ", Actual Owner Name is: " + actualOwnerName + ". And it matches");
            	 Log.info("Expected Owner Name is: " + excelHashMapValues.get("ownerid") + ", Actual Owner Name is: " + actualOwnerName + ". And it matches");	}
			 else {
				 System.out.println("Expected " + excelHashMapValues.get("ownerid") + " Actual Owner Name is " + actualOwnerName + " So it is not matched");}
             }
	
	public void getIssueType(String expectedItemType) throws Exception {
//			 webDriverwait(ICDD_WorkItem_Obj.ISSUE_TYPE);sleep(minWaitVal);
			 sleep(minWaitVal);
		 	 webDriverwait(By.xpath("//td[@title='"+ expectedItemType +"']"));
		 	 WebElement element = BaseTestSetup.driver.findElement(By.xpath("//td[@title='"+ expectedItemType +"']"));
			 System.out.println("Issue Type:" + element.getText());
			 String actualItemType = element.getText();
			 if (actualItemType.contains(expectedItemType)) {
				  System.out.println("Expected Item Type is: " + expectedItemType + ", Actual Item Type is: " + actualItemType + ". And it matches");}
			 else {
				  System.out.println("Expected " + expectedItemType + " Actual Item Type is " + actualItemType + " So it is not matched");}
	         }

	public void click_ref_id() throws Exception{
		try {
			Thread.sleep(3000);
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
            int stateColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "State");
            for (int i = 2; i <= n; i++) {
                WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stateColumnNumber + "]/div/img"));
                if (we.getAttribute("src").contains("/RCM/themes/new_york_blue/images/acm3.0/Open.png")) {
                    clickPerform(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[5]"));
                    Thread.sleep(2000);
                    try{BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[5]")).click();
                    Thread.sleep(2000);}
                    catch(Exception e){}
                    screenshot();
                    Log.info("Use is able to Clicked on Alert Sucessfully");
                    break;
                	}
                }   
            }
		catch (Exception e) {
			Log.error("Error while selecting customer alerts" + " :" + e.getMessage());
			screenshot();}
			}

	public void click_ref_id_checkbox() throws Exception{
		try {
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
            int stateColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "State");
            int StepColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Step");
            for (int i = 2; i <= n; i++) {
                WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + stateColumnNumber + "]/div/img"));
                WebElement we1 = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + StepColumnNumber + "]"));
                if (we.getAttribute("src").contains("/RCM/themes/new_york_blue/images/acm3.0/Open.png")) {
//                    Thread.sleep(2000);
                    clickPerform(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[1]"));
                    Log.info("Use is able to Clicked On Checkbox of Alert Sucessfully");
                    break;
                	}
                }   
            }
		catch (Exception e) {
            Log.info("Error while selecting customer alerts" + " :" + e.getMessage());
            screenshot();}
			}
 	 
	 public void verify_assigntome() throws Exception{
		try{
			int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	        System.out.println("Table size" + n);
	        int ownColumnNumber = getColumnNumber("//table[@id='alertsModel_headerTbl']//tr[@class='ui-jqgrid-labels ui-sortable']//th", "Owned by me");
	        for (int i = 2; i <= n; i++) {
	            WebElement we = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]/td[" + ownColumnNumber + "]/div/img"));
	            if (we.getAttribute("src").contains("/RCM/themes/new_york_blue/images/acm3.0/User.png")) {
	            	System.out.println("Alert is assigned to User Sucessfully");}
	            else{
	            	System.out.println("Alert is not assigned to user");}     
	             }
	        }
		catch(Exception e){
			throw new Exception("Error while assigned to user :" + e.getMessage());}
		   }	
	 
	 
	 public void verify_ref_id() throws Exception{			
		try{	
//	         Thread.sleep(3000);
	         int n = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
	         for (int i = 2; i <= n; i++) {
	            String searchRow = BaseTestSetup.driver.findElement(By.xpath("//table[@id='alertsModel']//tr[" + i + "]")).getText();
	            if (searchRow.equalsIgnoreCase("No Items to show")){
	            	throw new Exception("No records found in customer alerts");}
	            else {
	            	Log.info("Records found in customer alerts");
	            	screenshot();}}
	        }
		catch (Exception e) {
			 Log.error("Error while selecting customer alerts" + " :" + e.getMessage());}
		 } 
		
	 
	 public void assign_to_me() throws Exception{
		 try {
			sleep(minWaitVal);
			webDriverWait(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
			clickPerform(ICDD_WorkItem_Obj.ASSIGN_TO_ME);sleep(mediumWaitVal);
			String originalWindow =BaseTestSetup.driver.getWindowHandle();
	        Set<String> chwin = BaseTestSetup.driver.getWindowHandles();
	        for (String win1 : chwin) {
	        	if (BaseTestSetup.driver.switchTo().window(win1).getTitle().equals("")){
	        		BaseTestSetup.driver.switchTo().window(win1).close();}}
//	        String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
			Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
	        for (String win : chwin1) { 
	            if (!originalWindow.equals(win)) {
	                BaseTestSetup.driver.switchTo().window(win);
	                screenshot();
	                webDriverwait(ICDD_WorkItem_Obj.OK_BUTTON);
	                BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.OK_BUTTON).click();
	                sleep(minWaitVal);
	                BaseTestSetup.driver.switchTo().window(originalWindow);
	                Log.info("User is able to Assigned alert to user himself Sucessfully");
	                screenshot();}}}
	     catch (Exception e) {
	    	 screenshot();
	         throw new Exception("Error while assigning the alert to user himself" + " :" + e.getMessage());
	         }
	 	 }
	 
	 public void assign_user(String user) throws Exception {
	     try {
	        clickPerform(ICDD_WorkItem_Obj.ASSIGN_TO_ME);
	         String originalWindow = BaseTestSetup.driver.getWindowHandle();
	         System.out.println("Icon has been clicked");
	         Set<String> chwin = BaseTestSetup.driver.getWindowHandles();
	         for (String win : chwin) {
	            if (!originalWindow.equals(win)) {
	                BaseTestSetup.driver.switchTo().window(win);
	                BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ALERTDETAILS_ASSIGNUSER_TEXTBOX).sendKeys(user);
	                Thread.sleep(3000);
	                BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ALERTDETAILS_ASSIGNUSER_TEXTBOX).sendKeys(Keys.ARROW_DOWN, Keys.ENTER);
	                Thread.sleep(3000);
	                BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.OK_BUTTON).click();
	                BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
	                BaseTestSetup.driver.switchTo().window(originalWindow);
	                }
	            }
	        }
	     catch (Exception e) {
		     throw new Exception("Error while assigning the alert to user himself" + " :" + e.getMessage());}
		}
	        
	 public void expandButton() throws Exception{
		try {
			Thread.sleep(2000);
	        int n = BaseTestSetup.driver.findElements(By.tagName("iframe")).size();
	        if (n != 0) {
	        	WebElement we = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.EXPANDICONFRAME);
	            BaseTestSetup.driver.switchTo().frame(we);
	            List<WebElement> expandIcon = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.EXPANDICON);
	            for (WebElement expand : expandIcon) {
	            	expand.click();
	                Thread.sleep(1000);}
	            BaseTestSetup.driver.switchTo().defaultContent();}
	        else {
	        	List<WebElement> expandIcon = BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.EXPANDICON);
	            for (WebElement expand : expandIcon) {
	            	expand.click();}}
	       }
	    catch (Exception e) {
	        throw new Exception("Error while clicking on Expand Button" + " :" + e.getMessage());}
            } 
	
	 public void ValidateMandateCheck() throws Exception{
		 	screenshot();
		 	try{
			UiTextList.clear();
			UiRowEleList=BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.WORKFLOW_TEXTROWS);
			System.out.println("UiRowEleList size is: "+UiRowEleList.size());
			for (WebElement we : UiRowEleList) {
		     	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", we);
		     	toadd=we.getText().replace("\n", "").trim();
		     	UiTextList.add(toadd);}
			scrollUpVertical(driver.findElement(By.xpath("//table[@class='clsButton']/tbody//td[2]")));
			for(int i=0;i<UiTextList.size();i++){
				String UiStr=UiTextList.get(i);
				String str=UiStr.replace("   Check", "");
				Thread.sleep(1000);
				if(str.contains("*")){
				   System.out.println(str);
				   ++i;
		           BaseTestSetup.driver.findElement(By.xpath("(//*[@class='clsButton']//tr//td[2])["+i+"]")).sendKeys("");
		           Thread.sleep(1000);
				   BaseTestSetup.driver.findElement(By.xpath("(//*[@class='clsButton']//tr//td[2])["+i+"]")).click();
				   --i;
				   System.out.println("Document Name is - " +str + "- checked");
				}
			  }
			 screenshot();
		 	}
		 	catch(Exception e){
		 		System.out.println(" There is no mandatory tasks present for this case");
		 		Log.info("There is no mandatory tasks present for this case");
		 	}
			}
	 
	 public void search_second_alert(HashMap<String, String> excelHashMapValue, String ScenarioName, String Sheetname) throws Exception{
		 sleep(minWaitVal);
		 
		 webDriverWait(By.xpath("(//td[text()='Ready']/..//td[@aria-describedby='alertsModel_alertId'])[1]")); 
		 String secondAlert=BaseTestSetup.driver.findElement(By.xpath("(//td[text()='Ready']/..//td[@aria-describedby='alertsModel_alertId'])[1]")).getText();
		 click(By.xpath("(//td[text()='Ready']/..//td[@aria-describedby='alertsModel_alertId'])[1]"));
		 System.out.println("Second alert:"+secondAlert);
		 dataprovider.insertExcelData(ScenarioName, "SECOND_ALERT",Sheetname, secondAlert);
	 }
	 
	 public void verify_uncheck_button(String arg1) throws InterruptedException{
		    UiTextList.clear();
			//UiRowEleList=BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.WORKFLOW_TEXTROWS);
			System.out.println("UiRowEleList size is: "+UiRowEleList.size());
			for (WebElement we : UiRowEleList) {
		     	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", we);
		     	toadd=we.getText().replace("\n", "").trim();
		     	UiTextList.add(toadd);}
			try{
			for(int i=0;i<UiTextList.size();i++){
				String UiStr=UiTextList.get(i);
				String str=UiStr.replace("   Uncheck", "");
				if(str.contains("*")){
				  ++i;
				  WebElement text= BaseTestSetup.driver.findElement(By.xpath("(//*[@class='clsButton']//tr//td[2])["+i+"]"));
				  --i;
				if(text.getText().equals(arg1)){
				  System.out.print("check button become uncheck");}}} 
			}catch(Exception e)
			{
				
			}
	 		}
	 
	 public void click_customerAlert_button() throws Exception{
		 	System.out.print("Click on Customer Alert");
		 	BaseTestSetup.driver.findElement(By.id("detailsBtn")).click();
		 	Thread.sleep(2000);
		 	BaseTestSetup.driver.switchTo().frame("frmDetails");
		 	WebElement link = BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.CUSTOMER_ALERT_BUTTON);
		 	Actions action = new Actions(BaseTestSetup.driver);
		 	action.moveToElement(link).click(link).build().perform();
		 	screenshot();
		 	Log.info("User is able to click on Customer Alert Sucessfully");
		 	}
			
	public void taskNameValidationCheck(String scenarioName,HashMap<String, String> testData) throws Exception{
			UiRowEleList=BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.WORKFLOW_TEXTROWS);
			System.out.println("UiRowEleList size is: "+UiRowEleList.size());
			for (WebElement we : UiRowEleList) {
				((JavascriptExecutor) BaseTestSetup.driver).executeScript("arguments[0].scrollIntoView(true);", we);
				toadd=we.getText().replace("\n", "").trim();
				UiTextList.add(toadd);}
			for(int i=0;i<UiTextList.size();i++){
				String UiStr=UiTextList.get(i);
				String str=UiStr.replace("   Check", "");
				Thread.sleep(1000);
				String testDataValidation = testData.get("TASKNAME");
				if(str.trim().equalsIgnoreCase(testDataValidation)){
					++i;
			        BaseTestSetup.driver.findElement(By.xpath("(//*[@class='clsButton']//tr//td[2])["+i+"]")).sendKeys("");
			        Thread.sleep(1000);
					BaseTestSetup.driver.findElement(By.xpath("(//*[@class='clsButton']//tr//td[2])["+i+"]")).click();
					--i;
					Log.info("Checked document as per task name - Task Name is :" +testData.get("TASKNAME"));}}	
		      screenshot();
		     } 
				
	public void changestep(String next_value) throws Exception {
		try {
//		        String aftrchangestep;
			System.out.println("Starting of next Step");
			    sleep(minWaitVal);
		        click((ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP));
		        BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(2));
		        switchWindow("[Actimize] Change Step");sleep(minWaitVal);
		        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN));
		        click(ICDD_WorkItem_Obj.ALERTDETAILS_CHANGESTEP_DROPDWN);
		        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[contains(text(),'" + next_value + "')]")));
		        BaseTestSetup.waitForTitleisPresent(By.xpath("//td[contains(text(),'" + next_value + "')]"));
		        click(By.xpath("//td[contains(text(),'" + next_value + "')]"));
		        BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.id("changeStatusNoteModelFreeTextNote_ifr")));
		        WebElement we = BaseTestSetup.driver.findElement(By.id("changeStatusNoteModelFreeTextNote_ifr"));
		        BaseTestSetup.wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(we));
		        BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_WorkItem_Obj.ALERTSDETAIL_CHANGESTEP_TEXTFIELD));
		        sleep(minWaitVal);
		        enterInput(ICDD_WorkItem_Obj.ALERTSDETAIL_CHANGESTEP_TEXTFIELD, "Change alert step to " + next_value);
		        BaseTestSetup.driver.switchTo().defaultContent();
		        screenshot();
		        clickPerform(By.id("textButton_changeStatusDialog_SubmitButton"));
		        Log.info("User is able to Change the Alert Step Sucessfully");
		        if (next_value.equals("Submit to Checker") || next_value.equals("Re-assess client risk")) {
		            sleep(mediumWaitVal);
		            BaseTestSetup.driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		            Set<String> currentWindows = null;
		            while (currentWindows == null || currentWindows.size() < 1) {
		            currentWindows = BaseTestSetup.driver.getWindowHandles();}
		        if (currentWindows.size() > 1) {
		            for (String window : currentWindows) {
		            BaseTestSetup.driver.switchTo().window(window);
		            if (BaseTestSetup.driver.getTitle().contains("[Actimize] Error")) {
		               Thread.sleep(3000);
		               BaseTestSetup.driver.findElement(By.id("textButton_close_button")).click();
		               Thread.sleep(2000);
		               break;}}}}
		        if (next_value.startsWith("Decision on")||next_value.contains("Submit")) {
		             BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
		             switchBackToParentWindow("[Actimize] Work Items");}
		        else {
		             BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1)); 
		             switchBackToParentWindow("[Actimize] Item Details");}}
		 catch (Exception e) {
		        Log.error("Error while changing the alert step" + next_value + " :" + e.getMessage());
		        }
		        screenshot();
		    }
			
	public void addNote(String scenarioName,HashMap<String, String> testData) throws Exception{
				
				clickPerform(ICDD_WorkItem_Obj.ADDNOTE);
		        Thread.sleep(6000);
		        String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
				System.out.println("Original wingow:" +originalWindow1);
			    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin1) { 
		        if (!originalWindow1.equals(win)) {
		        BaseTestSetup.driver.switchTo().window(win);
		        /*BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.ADDNOTEDROP).sendKeys("");
		        Thread.sleep(2000);
		        selectElementByNameMethod(ICDD_WorkItem_Obj.ADDNOTEDROP,"[ Free Text ]");
		        Thread.sleep(4000);
		        BaseTestSetup.driver.switchTo().frame("noteModelFreeTextNote_ifr");
		      //  BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(By.id("tinymce")));
		        BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.COMMENTS).sendKeys("");
		        BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.COMMENTS).click();
		        BaseTestSetup.driver.findElement(ICDD_WorkItem_Obj.COMMENTS).sendKeys("testing");
		        BaseTestSetup.driver.switchTo().defaultContent();*/
		        driver.switchTo().frame("noteModelFreeTextNote_ifr");
				actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
				driver.switchTo().defaultContent();
		        screenshot();
		        clickPerform(ICDD_WorkItem_Obj.OKBUTTON);
		        BaseTestSetup.driver.switchTo().window(originalWindow1);
		        Log.info("User is able to Add Note Sucessfully");
		        Thread.sleep(4000);
		       
		        }   
			}
			}	
			public void viewNote() throws Exception
			{
				try{
				clickPerform(ICDD_WorkItem_Obj.VIEWNOTE);
				String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
				System.out.println("Original wingow:" +originalWindow1);
			    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin1) { 
		   	    System.out.println("***Entered Window Handles***");
		        if (!originalWindow1.equals(win)) {
		             System.out.println("Inside New Window***");
		             BaseTestSetup.driver.switchTo().window(win);
		             List<WebElement> val=BaseTestSetup.driver.findElements(By.xpath("//*[@id='viewNotesGridModel']/tbody/tr[2]/td"));
		            int a= val.size();
		             for(int i=2;i<=a;i++)
		             {
		            	 String actualValue=BaseTestSetup.driver.findElement(By.xpath("//*[@id='viewNotesGridModel']/tbody/tr[2]/td["+i+"]")).getText();
		            	 String actualTitle=BaseTestSetup.driver.findElement(By.xpath("//*[@id='viewNotesGridModel_headerTbl']//th["+i+"]/div//div//div//div")).getText();
		            	 System.out.println(actualTitle+ "is : "+actualValue);
		             }
		             screenshot();
		             clickPerform(ICDD_WorkItem_Obj.CANCEL);
			}
		        BaseTestSetup.driver.switchTo().window(originalWindow1);
		        }

		}catch(Exception e){
			System.out.println("Error view the notes"  + e.getMessage());
		}
			}
			public void Verify_WorkItemRecord(String scenarioName,HashMap<String, String> testData)
			{
				try
				{
					List<WebElement> tr_collection = BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.TOTAL_RECORD);
					int row_num=1,col_num=6;
					for (WebElement trElement : tr_collection) {
					     List<WebElement> td_collection = trElement.findElements(By.xpath("(//table[@id='alertsModel']//tr)[2]/td"));
					     int size=td_collection.size();
				//	     int n = td_collection.size();
					    	col_num=6;
					     for (col_num=6;col_num<=size;col_num++) {
					    	String ActualValue = BaseTestSetup.driver.findElement(By.xpath("(//table[@id='alertsModel_headerTbl']//tr/th)["+col_num+"]")).getText().trim();
					    	System.out.println("Actual Value"+ActualValue);
					    	List<WebElement> tdElement=trElement.findElements(By.xpath("((//table[@id='alertsModel']//tr)[2]/td)["+col_num+"]"));
					    	switch (ActualValue) {
							case "Full Name of Client":
								if (!testData.get("CustomerName").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("CustomerName"))){
											   System.out.println("Actual ICCD Reference Number is: " +tdElement.get(0).getText() + ", Expected ICCD Reference Number is: " + testData.get("CustomerName") + ". And it matches");
											    }
										   }
									  
						    	}
							//	col_num++;
								break;
							case "Party Key":
								if (!testData.get("referenceID").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("referenceID"))){
											   System.out.println("Actual ICCD Reference Number is: " +tdElement.get(0).getText() + ", Expected ICCD Reference Number is: " + testData.get("referenceID") + ". And it matches");
											    }
										   }
									  
						    	}
							//	col_num++;
								break;
							case "Item Date":
								if (!testData.get("ItemDate").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("ItemDate"))){
											   System.out.println("Actual Item Date is: " +tdElement.get(0).getText() + ", Expected Item Date is: " + testData.get("ItemDate") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "Step":
								if (!testData.get("Step").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("Step"))){
											   System.out.println("Actual Step is: " +tdElement.get(0).getText() + ", Expected Step is: " + testData.get("Step") + ". And it matches");
											    }
										   }
									  
						    	}
							//	col_num++;
								break;
							case "Business Unit":
								if (!testData.get("BusinessUnit").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("BusinessUnit"))){
											   System.out.println("Actual Business Unit is: " +tdElement.get(0).getText() + ", Expected Business Unit is: " + testData.get("BusinessUnit") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "Item Type":
								if (!testData.get("ItemType").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("ItemType"))){
											   System.out.println("Actual Item Type is: " +tdElement.get(0).getText() + ", Expected Item Type is: " + testData.get("ItemType") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "Risk Level":
								if (!testData.get("RiskLevel").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("RiskLevel"))){
											   System.out.println("Actual Risk Level is: " +tdElement.get(0).getText() + ", Expected Risk Level is: " + testData.get("RiskLevel") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "ICM ID":
								if (!testData.get("icmID").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("icmID"))){
											   System.out.println("Actual ICM ID Number is: " +tdElement.get(0).getText() + ", Expected ICM ID is: " + testData.get("icmID") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "REL ID":
								if (!testData.get("RelationshipId").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("RelationshipId"))){
											   System.out.println("Actual Relationship Number is: " +tdElement.get(0).getText() + ", Expected Relationship Number is: " + testData.get("RelationshipId") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "Last Review Date":
								if (!testData.get("LastReviewDate").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("LastReviewDate"))){
											   System.out.println("Actual Last Review Date is: " +tdElement.get(0).getText() + ", Expected Last Review Date is: " + testData.get("LastReviewDate") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							case "Review Due Date":
								if (!testData.get("DueDate").trim().isEmpty()) {
									  if (tdElement.get(0).getText().trim() != null) {
										   if(tdElement.get(0).getText().equalsIgnoreCase(testData.get("DueDate"))){
											   System.out.println("Actual Review Due Date is: " +tdElement.get(0).getText() + ", Expected Review Due Date is: " + testData.get("DueDate") + ". And it matches");
											    }
										   }
									  
						    	}
								//col_num++;
								break;
							default:
								//col_num++;
					            break;
			}
					     }
					}
					
				}
					catch(Exception e)
					{
						
					}

		}	
			
			public HashMap<String, String> testData;
			
			public void ICDD_Verify_StaticdataChangeAndCustomerInfo(String scenarioName,HashMap<String, String> testData) throws Exception
			{
				this.testData = testData;
			//	ICDD_CustomerRecord.searchiccdId(scenarioName,testData);
		     //		ICDD_CustomerRecord.clickiccdid(scenarioName,testData);
				screenshot();
				sleep(minWaitVal);
				customerProfile();
				addtionalData();
				onBoardingData();
				clientRiskRating();
				prohibitionDetails();
				previousRiskRating();
			}
			public void customerHighlights(){
				try{
				System.out.println("****************** customerHighlights ******************");
				Log.info("User is able to see Customer Highlights data Sucessfully");
				compareByText(ICDD_CustomerRecord_Obj.ICCD_ID, testData.get("ICDD_ID"),"ICCD ID Number");
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_NAME, testData.get("CUSTOMER_NAME"),"CUSTOMER NAME");
				compareByText(ICDD_CustomerRecord_Obj.RECORD_DATE, testData.get("RECORD_DATE"),"RECORD DATE");
				//compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_SCORE, testData.get("CUSTOMER_SCORE")," CUSTOMER SCORE");
				//compareByText(ICDD_CustomerRecord_Obj.RISK_RATING, testData.get("RISK_RATING"),"RISK_RATING");
			//	compareByText(ICDD_CustomerRecord_Obj.ALERT_LEVEL_STATUS, testData.get("ALERT_LEVEL_STATUS"),"ALERT LEVEL STATUS");
				compareByText(ICDD_CustomerRecord_Obj.ONBOARDING_STATUS, testData.get("ONBOARDING_STATUS"),"ONBOARDING STATUS");
				compareByText(ICDD_CustomerRecord_Obj.APPLICATION_REASON, testData.get("APPLICATION_REASON"),"APPLICATION REASON");
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_ICM_ID, testData.get("ICM_ID"),"ICM ID");
				compareByText(ICDD_CustomerRecord_Obj.CDD_STATUS, testData.get("CDD_STATUS"),"CDD STATUS");
				compareByText(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE, testData.get("NEXT_REVIEW_DATE"),"NEXT REVIEW DATE");
				}catch(Exception e){}
			}
			
		public void customerProfile(){
			try{
				System.out.println("****************** customerProfile ******************");
				try{
					BaseTestSetup.driver.switchTo().frame("frmDetails");
				}
				catch(Exception e){}
			
				click(ICDD_CustomerRecord_Obj.CUSTOMER_PROFILE_TAB);sleep(minWaitVal);
				screenshot();
				Log.info("User is able to click on Customer Profile Tab Sucessfully");
				compareByText(ICDD_CustomerRecord_Obj.TYPE, testData.get("TYPE"), "TYPE");
				compareByText(ICDD_CustomerRecord_Obj.RELATIONSHIP_ACTIVATION_DATE, testData.get("RELATIONSHIP_ACTIVATION_DATE"),"RELATIONSHIP ACTIVATION DATE");
				compareByText(ICDD_CustomerRecord_Obj.RELATIONSHIP_CLODES_IND, testData.get("RELATIONSHIP_CLODES_IND"),"RELATIONSHIP CLODES IND");
				compareByText(ICDD_CustomerRecord_Obj.PARTY_REFERENCE_ID, testData.get("PARTY_REFERENCE_ID"),"PARTY REFERENCE ID");
				compareByText(ICDD_CustomerRecord_Obj.RESIDENTIAL_ADDRESS, testData.get("RESIDENTIAL_ADDRESS"),"RESIDENTIAL ADDRESS");
				compareByText(ICDD_CustomerRecord_Obj.CITY, testData.get("CITY"),"CITY");
				compareByText(ICDD_CustomerRecord_Obj.STATE, testData.get("STATE"),"STATE");
				compareByText(ICDD_CustomerRecord_Obj.COUNTRY, testData.get("COUNTRY"),"COUNTRY");
				compareByText(ICDD_CustomerRecord_Obj.EMAIL, testData.get("EMAIL"),"EMAIL");
				compareByText(ICDD_CustomerRecord_Obj.DOB, testData.get("DOB"),"DOB");
				compareByText(ICDD_CustomerRecord_Obj.CLOSED_DATE, testData.get("CLOSED_DATE"),"CLOSED_DATE");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY, testData.get("NATIONALITY"),"NATIONALITY");
				compareByText(ICDD_CustomerRecord_Obj.FIN_NUM, testData.get("FIN_NUM"),"FIN NUM");
				compareByText(ICDD_CustomerRecord_Obj.EDUCATION, testData.get("EDUCATION"),"EDUCATION");
				compareByText(ICDD_CustomerRecord_Obj.PASSPORT_NUMBER, testData.get("PASSPORT_NUMBER"),"PASSPORT NUMBER");
				compareByText(ICDD_CustomerRecord_Obj.OCCUPATION, testData.get("OCCUPATION"),"OCCUPATION");
				compareByText(ICDD_CustomerRecord_Obj.SUB_SEGMENT, testData.get("SUB_SEGMENT"),"SUB SEGMENT");
				compareByText(ICDD_CustomerRecord_Obj.CLIENT_TYPE, testData.get("CLIENT_TYPE"),"CLIENT TYPE");
				compareByText(ICDD_CustomerRecord_Obj.INDUSTRY, testData.get("INDUSTRY"),"INDUSTRY");
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE, testData.get("LAST_REVIEW_DATE"),"LAST_REVIEW_DATE");
			}catch(Exception e){}
		}
		    
		    public void addtionalData(){
		    	try{
		    	System.out.println("****************** AddtionalData ******************");
		    	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB));
		    	click(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);sleep(minWaitVal);
		    	screenshot();
		    	compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_NAME, testData.get("PREVIOUS_NAME"),"PREVIOUS NAME1");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY1, testData.get("NATIONALITY1"),"NATIONALITY1");
				compareByText(ICDD_CustomerRecord_Obj.SEGMENT, testData.get("SEGMENT"),"SEGMENT");
				compareByText(ICDD_CustomerRecord_Obj.BRANCH_CODE, testData.get("BRANCH_CODE"),"BRANCH_CODE");
				compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_NAME2, testData.get("PREVIOUS_NAME2"),"PREVIOUS_NAME2");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY2, testData.get("NATIONALITY2"),"NATIONALITY2");
				compareByText(ICDD_CustomerRecord_Obj.NATURE_OF_EMPLOYMENT, testData.get("NATURE_OF_EMPLOYMENT"),"NATURE OF EMPLOYMENT");
				compareByText(ICDD_CustomerRecord_Obj.COUNTRY_OF_BIRTH, testData.get("COUNTRY_OF_BIRTH"),"COUNTRY OF BIRTH");
				compareByText(ICDD_CustomerRecord_Obj.ANY_OTHER_NAME_KNOWNBY1, testData.get("ANY_OTHER_NAME_KNOWNBY1"),"ANY OTHER NAME KNOWNBY1");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY3, testData.get("NATIONALITY3"),"NATIONALITY3");
				compareByText(ICDD_CustomerRecord_Obj.ARM_CODE, testData.get("ARM_CODE"),"ARM CODE");
				compareByText(ICDD_CustomerRecord_Obj.US_RESIDENT, testData.get("US_RESIDENT"),"US RESIDENT");
				compareByText(ICDD_CustomerRecord_Obj.ANY_OTHER_NAME_KNOWNBY2, testData.get("ANY_OTHER_NAME_KNOWNBY2"),"ANY OTHER NAME KNOWNBY2");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY4, testData.get("NATIONALITY4"),"NATIONALITY4");
				compareByText(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER, testData.get("NAME_OF_EMPLYER"),"NAME OF EMPLYER");
				compareByText(ICDD_CustomerRecord_Obj.US_PERMANENT_RESIDENT_CARD, testData.get("US_PERMANENT_RESIDENT_CARD"),"US PERMANENT RESIDENT CARD");
				compareByText(ICDD_CustomerRecord_Obj.CLIENT_NAME, testData.get("CLIENT_NAME"),"CLIENT_NAME");
				compareByText(ICDD_CustomerRecord_Obj.NATIONALITY5, testData.get("NATIONALITY5"),"NATIONALITY5");
				compareByText(ICDD_CustomerRecord_Obj.EMPLOYEE_ID, testData.get("EMPLOYEE_ID"),"EMPLOYEE ID");
				compareByText(ICDD_CustomerRecord_Obj.DECLARED_ANUUAL_INCOME, testData.get("DECLARED_ANUUAL_INCOME"),"DECLARED ANUUAL INCOME");
				compareByText(ICDD_CustomerRecord_Obj.CLIENT_STATUS, testData.get("CLIENT_STATUS"),"CLIENT STATUS");
				compareByText(ICDD_CustomerRecord_Obj.ACQUISION_CHANNEL, testData.get("ACQUISION_CHANNEL"),"ACQUISION CHANNEL");
				compareByText(ICDD_CustomerRecord_Obj.PRR_EXEMPTED, testData.get("PRR_EXEMPTED"),"PRR EXEMPTED");
				compareByText(ICDD_CustomerRecord_Obj.CASE_OWNER_ID, testData.get("CASE_OWNER_ID"),"CASE OWNER ID");
				compareByText(ICDD_CustomerRecord_Obj.MINOR, testData.get("MINOR"),"MINOR");
		    }catch(Exception e){}
		    }
		    
		    public void onBoardingData(){
		    	try{
		    	System.out.println("****************** OnBoardingData ******************");
		    	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ONBOARDING_TAB));
		    	click(ICDD_CustomerRecord_Obj.ONBOARDING_TAB);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Onboarding Data Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT, testData.get("NAME_SCREENING_HIT"),"NAME SCREENING HIT");
				compareByText(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT, testData.get("NAME_SCREENING_ALERT"),"NAME SCREENING ALERT");
				compareByText(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH, testData.get("MATCH_TRUE_MATCH"),"MATCH TRUE MATCH");
				compareByText(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING, testData.get("TYPE_NAME_SCREENING"),"TYPE NAME SCREENING");
				compareByText(ICDD_CustomerRecord_Obj.POTANTIAL_PEP, testData.get("POTANTIAL_PEP"),"POTANTIAL PEP");
				compareByText(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS, testData.get("CITY"),"CITY");
				compareByText(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA, testData.get("POTANTIAL_ADVERSE_MEDIA"),"POTANTIAL ADVERSE MEDIA");
				compareByText(ICDD_CustomerRecord_Obj.STP_FLAG, testData.get("STP_FLAG"),"STP FLAG");
		    }catch(Exception e){}
		    }  
		    public void clientRiskRating()
		    {
		    	try{
		    	System.out.println("****************** ClientRiskRating ******************");
		    	click(ICDD_CustomerRecord_Obj.CLIENT_RISK_RATING);sleep(minWaitVal);
		    	Log.info("User is able to click on Client Risk Rating Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.FINAL_RISK_RATING, testData.get("FINAL_RISK_RATING"),"FINAL RISK RATING");
				compareByText(ICDD_CustomerRecord_Obj.REASON_FOR_RISK_RATING, testData.get("REASON_FOR_RISK_RATING"),"REASON FOR RISKRATING");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION, testData.get("PROHIBITION"),"PROHIBITION");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_REASON, testData.get("PROHIBITION_REASON"),"PROHIBITION REASON");
				screenshot();
		    	}catch(Exception e){}
		   }
	public void overrideDetails(){
		  try{
		    	System.out.println("****************** OverrideDetails ******************");
		    	click(ICDD_CustomerRecord_Obj.OVERRIDE_DETAILS);sleep(minWaitVal);
		    	Log.info("User is able to click on Override Details Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.CRA_RATING, testData.get("CRA_RATING"),"CRA RATING");
				compareByText(ICDD_CustomerRecord_Obj.SEGMENT_COUNTRY_OVERRIDE, testData.get("SEGMENT_COUNTRY_OVERRIDE"),"SEGMENT COUNTRY OVERRIDE");
				compareByText(ICDD_CustomerRecord_Obj.JOINT_ACCOUNT_OVERRIDE, testData.get("JOINT_ACCOUNT_OVERRIDE"),"JOINT ACCOUNT OVERRIDE");
				compareByText(ICDD_CustomerRecord_Obj.RELATED_ENTRY_OVERRIDE, testData.get("RELATED_ENTRY_OVERRIDE"),"RELATED ENTRY OVERRIDE");
		    }catch(Exception e){}
		    }
		    
	public void keyRiskIndicators(){
		   try{
		    	System.out.println("****************** keyRiskIndicators ******************");
		    	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB));
		    	click(ICDD_CustomerRecord_Obj.KEY_RISK_INDICATOR_TAB);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Key Risk Indicators Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.AUM_IN_USD, testData.get("AUM_IN_USD"),"AUM IN USD");
				compareByText(ICDD_CustomerRecord_Obj.AUM_IN_LCY, testData.get("AUM_IN_LCY"),"AUM IN LCY");
				compareByText(ICDD_CustomerRecord_Obj.APPROVED_BORROWING_LIMIT_IN_USD, testData.get("APPROVED_BORROWING_LIMIT_IN_USD"),"APPROVED BORROWING LIMIT IN USD");
				compareByText(ICDD_CustomerRecord_Obj.APPROVED_BORROWING_LIMIT_IN_LCY, testData.get("APPROVED_BORROWING_LIMIT_IN_LCY"),"APPROVED BORROWING LIMIT IN LCY");
				compareByText(ICDD_CustomerRecord_Obj.PEP_STATUS, testData.get("PEP_STATUS"),"PEP STATUS");
				compareByText(ICDD_CustomerRecord_Obj.PEP_CATEGORY, testData.get("PEP_CATEGORY"),"PEP CATEGORY");
				compareByText(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_STATUS, testData.get("ADVERSE_MEDIA_STATUS"),"ADVERSE MEDIA STATUS");
				compareByText(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_SEVERITY, testData.get("ADVERSE_MEDIA_SEVERITY"),"ADVERSE MEDIA SEVERITY");
				compareByText(ICDD_CustomerRecord_Obj.SANCTION_STATUS, testData.get("SANCTION_STATUS"),"SANCTION STATUS");
				compareByText(ICDD_CustomerRecord_Obj.CLIENT_NET_WORTH_TYPE, testData.get("CLIENT_NET_WORTH_TYPE"),"CLIENT NET WORTH TYPE");
				compareByText(ICDD_CustomerRecord_Obj.SOW_CORROBORATION, testData.get("SOW_CORROBORATION"),"SOW CORROBORATION");
				compareByText(ICDD_CustomerRecord_Obj.NTBR, testData.get("NTBR"),"NTBR");	
				screenshot();
		    }catch(Exception e){}
		    }
		    
	public void previousRiskRating(){
		
		    	System.out.println("****************** PreviousRiskRating ******************");
		    	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PREVIOUS_RISK_RATING_TAB));
		    	click(ICDD_CustomerRecord_Obj.PREVIOUS_RISK_RATING_TAB);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Previous Risk Rating Sucessfully");
		    	try{
		    	compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_CRA_RATING, testData.get("PREVIOUS_CRA_RATING"),"PREVIOUS CRA RATING");
				compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_COUNTRY_OVERRIDE, testData.get("PREVIOUS_COUNTRY_OVERRIDE"),"PREVIOUS COUNTRY OVERRIDE");
				compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_JOINT_ACCOUNT_OVERRIDE, testData.get("PREVIOUS_JOINT_ACCOUNT_OVERRIDE"),"PREVIOUS JOINT ACCOUNT OVERRIDE");
				compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_ENTITY_OVERRIDE, testData.get("PREVIOUS_ENTITY_OVERRIDE"),"PREVIOUS ENTITY OVERRIDE");
				compareByText(ICDD_CustomerRecord_Obj.PREVIOUS_FINAL_RISKRATING, testData.get("PREVIOUS_FINAL_RISKRATING"),"PREVIOUS FINAL RISKRATING");
				compareByText(ICDD_CustomerRecord_Obj.DETECTION_DATETIME, testData.get("DETECTION_DATETIME"),"DETECTION DATETIME");
				screenshot();
		    	}catch(Exception e)
		    	{
		    		
		    	}
		    }
		    
		    public void craDetails()
		    {
		    	try{
		    	System.out.println("****************** craDetails ******************");
		    	click(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on CRA Details Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.PRODUCT_RISK, testData.get("PRODUCT_RISK"),"PRODUCT RISK");
				compareByText(ICDD_CustomerRecord_Obj.ONBoarding_TYPES, testData.get("ONBoarding_TYPES"),"ONBoarding TYPES");
				compareByText(ICDD_CustomerRecord_Obj.ACCOUNT_SERVICING, testData.get("ACCOUNT_SERVICING"),"ACCOUNT SERVICING");
				compareByText(ICDD_CustomerRecord_Obj.BUSINESS_RISK, testData.get("BUSINESS_RISK"),"BUSINESS RISK");
				compareByText(ICDD_CustomerRecord_Obj.CROSS_BORDER_NON_RESIDENCY, testData.get("CROSS_BORDER_NON_RESIDENCY"),"CROSS BORDER NON RESIDENCY");
				compareByText(ICDD_CustomerRecord_Obj.INCIDENCE_OF_FINANCIAL_CRIME, testData.get("INCIDENCE_OF_FINANCIAL_CRIME"),"INCIDENCE OF FINANCIAL CRIME");
				compareByText(ICDD_CustomerRecord_Obj.SCB_COUNTRY, testData.get("SCB_COUNTRY"),"SCB COUNTRY");
				compareByText(ICDD_CustomerRecord_Obj.PEP_STATUS1, testData.get("PEP_STATUS1"),"PEP STATUS1");
				compareByText(ICDD_CustomerRecord_Obj.SANCTION_CONNECTIONS, testData.get("SANCTION_CONNECTIONS"),"SANCTION CONNECTIONS");
				compareByText(ICDD_CustomerRecord_Obj.LENGTH_OF_RELATIONSHIP, testData.get("LENGTH_OF_RELATIONSHIP"),"LENGTH OF RELATIONSHIP");
				compareByText(ICDD_CustomerRecord_Obj.ADVERSE_INFORMATION, testData.get("ADVERSE_INFORMATION"),"ADVERSE INFORMATION");
				compareByText(ICDD_CustomerRecord_Obj.FCC_RISK_EVENT, testData.get("FCC_RISK_EVENT"),"FCC RISK EVENT");	
				compareByText(ICDD_CustomerRecord_Obj.QUALITY_OF_REGULATION, testData.get("QUALITY_OF_REGULATION"),"QUALITY OF REGULATION");	
				screenshot();
		    	}catch(Exception e)
		    	{}
		    } 
		    public void prohibitionDetails()
		    {
		    	try{
		    	System.out.println("****************** prohibitionDetials ******************");
		    	((JavascriptExecutor) BaseTestSetup.driver).executeScript(
		                 "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_TAB));
		    	click(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Prohibition Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA, testData.get("PROHIBITION_BASED_ON_STATIC_DATA"),"PROHIBITION BASED ON STATIC DATA");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING, testData.get("PROHIBITION_BASED_ON_NAME_SCREENING"),"PROHIBITION BASED ON NAME SCREENING");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_MULTIPLE_SAR, testData.get("PROHIBITION_BASED_ON_MULTIPLE_SAR"),"PROHIBITION BASED ON MULTIPLE SAR");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_PROHIBITED_INDUSTRY, testData.get("PROHIBITION_BASED_ON_PROHIBITED_INDUSTRY"),"PROHIBITION BASED ON PROHIBITED INDUSTRY");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_SOW, testData.get("PROHIBITION_BASED_ON_SOW"),"PROHIBITION BASED ON SOW");
				compareByText(ICDD_CustomerRecord_Obj.COUNTRY_PROHIBITION, testData.get("COUNTRY_PROHIBITION"),"COUNTRY PROHIBITION");
				compareByText(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_RISK_RATING, testData.get("PROHIBITION_BASED_ON_RISK_RATING"),"PROHIBITION BASED ON RISK RATING");
				screenshot();
		    	}catch(Exception e)
		    	{}
		    }
		    public void triggerReview()
		    {try{
		    	System.out.println("****************** triggerReview ******************");
		    	screenshot();
		    	Log.info("User is able to click on Trigger Review Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.TRIGGER_IS_SAR, testData.get("TRIGGER_IS_SAR"),"TRIGGER IS SAR");
				compareByText(ICDD_CustomerRecord_Obj.TRIGGER_IS_NCT, testData.get("TRIGGER_IS_NCT"),"TRIGGERIS NCT");
				compareByText(ICDD_CustomerRecord_Obj.TRIGGER_IS_DENY_BUSINESS, testData.get("TRIGGER_IS_DENY_BUSINESS"),"TRIGGER IS DENY BUSINESS");
				compareByText(ICDD_CustomerRecord_Obj.TRIGGER_IS_CONF_ADV_MEDIA, testData.get("TRIGGER_IS_CONF_ADV_MEDIA"),"TRIGGER IS CONF ADV MEDIA");
				compareByText(ICDD_CustomerRecord_Obj.TRIGGER_CHANGE_TO_HNW, testData.get("TRIGGER_CHANGE_TO_HNW"),"TRIGGER CHANGE TO HNW");	
				compareByText(ICDD_CustomerRecord_Obj.RP_PROHIBITION, testData.get("RP_PROHIBITION"),"RP PROHIBITION");
				compareByText(ICDD_CustomerRecord_Obj.RP_NAMESCREEN, testData.get("RP_NAMESCREEN"),"RP NAMESCREEN");	
				compareByText(ICDD_CustomerRecord_Obj.CHANGE_TO_NON_RESIDENCY, testData.get("CHANGE_TO_NON_RESIDENCY"),"CHANGE TO NON RESIDENCY");
		    }catch(Exception e){}
		    }
		    public void selfRestrictionChk()
		    {
		    	try{
		    	System.out.println("****************** selfRestictedChk ******************");
		    	screenshot();
		    	Log.info("User is able to click on Self Restriction Checkk Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.SELF_RESTRICTION_BENF_OWNER, testData.get("SELF_RESTRICTION_BENF_OWNER"),"SELF RESTRICTION BENF OWNER");
				compareByText(ICDD_CustomerRecord_Obj.SELF_RESTRICTION_ADVERSE_MEDIA, testData.get("SELF_RESTRICTION_ADVERSE_MEDIA"),"SELF RESTRICTION ADVERSE MEDIA");
				compareByText(ICDD_CustomerRecord_Obj.SELF_RESRTICTION_UNDULY_COMPLEX, testData.get("SELF_RESRTICTION_UNDULY_COMPLEX"),"SELF RESRTICTION UNDULY COMPLEX");
				compareByText(ICDD_CustomerRecord_Obj.SELF_RESTRICTION_SENSITIVE, testData.get("SELF_RESTRICTION_SENSITIVE"),"SELF RESTRICTION SENSITIVE");
				compareByText(ICDD_CustomerRecord_Obj.SELF_RESTRICTION_HIGH_RISK_COUNTRY, testData.get("SELF_RESTRICTION_HIGH_RISK_COUNTRY"),"SELF RESTRICTION HIGH RISK COUNTRY");	
		    	}catch(Exception e){}
		    }
		    public void transcationMonthlyHistoryProfile()
		    {
		    	System.out.println("****************** trasctionMonthlyHistory ******************");
		    }
		    public void customerAddress()
		    {try{
		    	System.out.println("****************** customerAddress ******************");
		    	screenshot();
		    	Log.info("User is able to click on Customer Address Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_ADDRESS_TYPE, testData.get("CUSTOMER_ADDRESS_TYPE"),"CUSTOMER ADDRESS TYPE");
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_ADDRESS, testData.get("CUSTOMER_ADDRESS"),"CUSTOMER ADDRESS");	
				//compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_COUNTRY, testData.get("CUSTOMER_COUNTRY"),"CUSTOMER COUNTRY");
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_STATE, testData.get("CUSTOMER_STATE"),"CUSTOMER STATE");
				//compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_PO_BOX, testData.get("CUSTOMER_PO_BOX"),"CUSTOMER PO BOX");	
				compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_POSTAL_CODE, testData.get("CUSTOMER_POSTAL_CODE"),"CUSTOMER POSTAL CODE");
				//compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_RETURN_MAIL_FALG, testData.get("CUSTOMER_RETURN_MAIL_FALG"),"CUSTOMER RETURN MAIL FALG");	
				screenshot();
		    }catch(Exception e){}
		    }
		    public void customerPhoneNum()
		    {
		    	try{
		    	System.out.println("****************** customerphoneNumber ******************");
		    	click(ICDD_CustomerRecord_Obj.CUSTOMER_PHONE_NUM);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Customer Phone Number tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.PHONE_TYPE, testData.get("PHONE_TYPE"),"PHONE TYPE");
				compareByText(ICDD_CustomerRecord_Obj.PHONE_TYPE1, testData.get("PHONE_TYPE1"),"PHONE TYPE1");	
				compareByText(ICDD_CustomerRecord_Obj.ISD_CODE, testData.get("ISD_CODE"),"ISD CODE");
				compareByText(ICDD_CustomerRecord_Obj.ISD_CODE1, testData.get("ISD_CODE1"),"ISD CODE1");
				compareByText(ICDD_CustomerRecord_Obj.PHONE, testData.get("PHONE"),"PHONE");	
				compareByText(ICDD_CustomerRecord_Obj.PHONE1, testData.get("PHONE1"),"PHONE1");
				screenshot();
		    	}catch(Exception e){}
		    }
		    
		    public void customerEmailAddress()
		    {try{
		    	System.out.println("****************** customerEmailAddress ******************");
		    	click(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Customer Email Address Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_TYPE, testData.get("EMAIL_ADDRESS_TYPE"),"EMAIL ADDRESS TYPE");
				compareByText(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_TYPE1, testData.get("EMAIL_ADDRESS_TYPE1"),"EMAIL ADDRESS TYPE1");	
				compareByText(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL, testData.get("EMAIL_ADDRESS_EMAIL"),"EMAIL ADDRESS EMAIL");
				compareByText(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1, testData.get("EMAIL_ADDRESS_EMAIL1"),"EMAIL ADDRESS EMAIL1");
		    }catch(Exception e){}
		    }  
		    public void document()
		    {
		    	try{
		    	System.out.println("****************** document ******************");
		    	click(ICDD_CustomerRecord_Obj.DOCUMENT);sleep(minWaitVal);
		    	screenshot();
		    	Log.info("User is able to click on Document Tab Sucessfully");
		    	compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_REQUIRMENT, testData.get("DOCUMENT_REQUIRMENT"),"DOCUMENT REQUIRMENT");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_PRIORITY, testData.get("DOCUMENT_PRIORITY"),"DOCUMENT PRIORITY");	
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_STATUS, testData.get("DOCUMENT_STATUS"),"DOCUMENT STATUS");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_DUE_DATE, testData.get("DOCUMENT_DUE_DATE"),"DOCUMENT DUE DATE");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_TYPE, testData.get("DOCUMENT_TYPE"),"DOCUMENT TYPE");	
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_NUMBER, testData.get("DOCUMENT_NUMBER"),"DOCUMENT NUMBER");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_ISSUER, testData.get("DOCUMENT_ISSUER"),"DOCUMENT ISSUER");	
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_ISSUE_DATE, testData.get("DOCUMENT_ISSUE_DATE"),"DOCUMENT ISSUE DATE");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_ISSUE_COUNTRY, testData.get("DOCUMENT_ISSUE_COUNTRY"),"DOCUMENT ISSUE COUNTRY");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_EXPITY_DATE, testData.get("DOCUMENT_EXPITY_DATE"),"DOCUMENT EXPITY DATE");	
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_ALTERNATIVE_APPLIED, testData.get("DOCUMENT_ALTERNATIVE_APPLIED"),"DOCUMENT ALTERNATIVE APPLIED");
				compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_DETAILS, testData.get("DOCUMENT_DETAILS"),"DOCUMENT DETAILS");	
		    	} catch(Exception e){}
		    }
		    
		    public void accountTab()throws Exception{
		    	clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT_TAB);
		    	Log.info("User is able to Clicked on Account Tab Sucessfully");
		    	screenshot();
		    	clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT);
		    	screenshot();
		    }
		    
	public void accountSummary() throws Exception{
		
		    	clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT_TAB);
		    	screenshot();
		    	compareByText(ICDD_CustomerRecord_Obj.ACCOUNT_TYPE, testData.get("ACCOUNT_TYPE"),"ACCOUNT TYPE");
				compareByText(ICDD_CustomerRecord_Obj.ACCOUNT_TYPE_DESCRIPTION, testData.get("ACCOUNT_TYPE_DESCRIPTION"),"ACCOUNT TYPE DESCRIPTION");	
				compareByText(ICDD_CustomerRecord_Obj.NUMBER_OF_ACCOUNT, testData.get("NUMBER_OF_ACCOUNT"),"NUMBER OF ACCOUNT");
				compareByText(ICDD_CustomerRecord_Obj.NUMBER_OF_ACCOUNT, testData.get("NUMBER_OF_ACCOUNT"),"NUMBER OF ACCOUNT");
				
			    String noofaccount=BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NUMBER_OF_ACCOUNT).getText();
			    int noofaccount1=Integer.parseInt(noofaccount);
			    String accountNumber = null;
			    BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//td[@class='collapserCaption' and contains(text(),'Active Account Details (5)')]")));
			    for (WebElement element : BaseTestSetup.driver.findElements(By.xpath("//td[@class='collapserCaption']"))) {
			    	if (element.getText().trim().contains("Active Account Details (5)")) {
			        element.click();
			        break;
			            }
			        }
			    for (WebElement element : BaseTestSetup.driver.findElements(By.xpath("//td[@class='collapserCaption']"))) {
			    	if (element.getText().trim().contains("Account:")) {
			            accountNumber = element.getText().trim();
			            System.out.println(accountNumber);}
			        if(element.getText().trim().equals("Account Profile Tab")) {
			            System.out.println(element.getText());
				        element.click();
				        }
			        }
			               
			    for(int i=1;i<=noofaccount1;i++){
			        if(!(testData.get("CLIENT_RELATIONSHIPTO_ACCOUNT")).trim().isEmpty()){
			            if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Client Relationship to Account:'])["+i+"]/../td[3]")).getText().equalsIgnoreCase(testData.get("CLIENT_RELATIONSHIPTO_ACCOUNT"))){
			                System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Client Relationship to Account:'])[1]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("CLIENT_RELATIONSHIPTO_ACCOUNT") + ". And it matches");}}
			        if(!(testData.get("PRODUCT")).trim().isEmpty()){
				        if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Product:'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("PRODUCT"))){
				            System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Product:'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("PRODUCT") + ". And it matches");}}
				    if(!(testData.get("ACCOUNT_OPENING_CHANNEL")).trim().isEmpty()){
					    if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Opening Channel:'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_OPENING_CHANNEL"))){
					        System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Opening Channel:'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_OPENING_CHANNEL") + ". And it matches");}}
					if(!(testData.get("FEDERAL_TAX")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Federal Tax Withholding Code:'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("FEDERAL_TAX"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Federal Tax Withholding Code:'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("FEDERAL_TAX") + ". And it matches");}}
				    if(!(testData.get("ACCOUNT_OPEN_DATE")).trim().isEmpty()){
				    	if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Open Date:'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_OPEN_DATE"))){
				    		System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Open Date:'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_OPEN_DATE") + ". And it matches");}}
				    if(!(testData.get("ACCOUNT_ACTIVE")).trim().isEmpty()){
				    	if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Client Relationship to Account:'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_ACTIVE"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Client Relationship to Account:'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_ACTIVE") + ". And it matches");}}
				    if(!(testData.get("ACCCOUNT_SUBPRODUCT")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Sub-product Code:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCCOUNT_SUBPRODUCT"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Sub-product Code:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCCOUNT_SUBPRODUCT") + ". And it matches");}  }
					if(!(testData.get("ACCOUNT_SUBPRODUCT_DESCRIPTION")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Sub-product Description:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_SUBPRODUCT_DESCRIPTION"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Sub-product Description:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_SUBPRODUCT_DESCRIPTION") + ". And it matches");}   }
				    if(!(testData.get("ACCOUNT_BRANCH")).trim().isEmpty()){
				    	if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Branch:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_BRANCH"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Branch:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_BRANCH") + ". And it matches");} }  
				    if(!(testData.get("ACCOUNT_BRANCH_PHONE")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Branch Phone:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_BRANCH_PHONE"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Branch Phone:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_BRANCH_PHONE") + ". And it matches");} }              		
				    if(!(testData.get("ACCOUNT_OFFICER")).trim().isEmpty()){
				    	if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Officer#:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_OFFICER"))){
				    		System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Officer#:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_OFFICER") + ". And it matches");}  } 
					if(!(testData.get("ACCOUNT_OFFICER_NAME")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Officer Name:'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_OFFICER_NAME"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Officer Name:'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_OFFICER_NAME") + ". And it matches");}  } 
					if(!(testData.get("ACCOUNT_CURRENCY")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Currency'])[1]/../td[3]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_CURRENCY"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Currency'])["+i+"]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_CURRENCY") + ". And it matches");}  } 
					if(!(testData.get("PURPOSE_REASON_RELATIONSHIP")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Purpose and reason for establishing relationship'])["+i+"]/../td[3]")).getText().equalsIgnoreCase(testData.get("PURPOSE_REASON_RELATIONSHIP"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Purpose and reason for establishing relationship'])[1]/../td[3]")).getText()+ ", The Actual Value : "+testData.get("PURPOSE_REASON_RELATIONSHIP") + ". And it matches");} }             
					if(!(testData.get("ACCOUNT_NUMBER")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Number'])[1]/../td[5]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_NUMBER"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Number'])["+i+"]/../td[5]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_NUMBER") + ". And it matches");}}
					if(!(testData.get("ACCOUNT_STATUS")).trim().isEmpty()){
						if(BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Status'])[1]/../td[7]")).getText().equalsIgnoreCase(testData.get("ACCOUNT_STATUS"))){
							System.out.println("The expected Value : "+BaseTestSetup.driver.findElement(By.xpath("(//*[text()='Account Status'])["+i+"]/../td[7]")).getText()+ ", The Actual Value : "+testData.get("ACCOUNT_STATUS") + ". And it matches");}}
												                
					                		
					         }
			      }
			        
			    public void onBoardingQuestion() throws Exception
			    {
			    	clickPerform(ICDD_CustomerRecord_Obj.ONBOARDING_QUESTION_TAB);
			    	compareByText(ICDD_CustomerRecord_Obj.CLIENT, testData.get("CLIENT"),"CLIENT");
					compareByText(ICDD_CustomerRecord_Obj.COUNTRY_ACCOUNT_OPENING, testData.get("COUNTRY_ACCOUNT_OPENING"),"COUNTRY ACCOUNT OPENING");	
					compareByText(ICDD_CustomerRecord_Obj.NAME_OF_CUSTOMER, testData.get("NAME_OF_CUSTOMER"),"NAME OF CUSTOMER");
					compareByText(ICDD_CustomerRecord_Obj.TITLE, testData.get("TITLE"),"TITLE");
					compareByText(ICDD_CustomerRecord_Obj.FIRST_NAME, testData.get("CustomerName"),"CustomerName");
					compareByText(ICDD_CustomerRecord_Obj.SURNAME_NT_AVAILABLE, testData.get("SURNAME_NT_AVAILABLE"),"SURNAME NT AVAILABLE");	
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_TYPE, testData.get("ADDRESS_TYPE"),"ADDRESS TYPE");
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_LINE1, testData.get("ADDRESS_LINE1"),"ADDRESS LINE1");
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_LINE2, testData.get("ADDRESS_LINE2"),"ADDRESS LINE2");
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_CITY, testData.get("ADDRESS_CITY"),"ADDRESS CITY");	
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_COUNTRY, testData.get("ADDRESS_COUNTRY"),"ADDRESS COUNTRY");
					compareByText(ICDD_CustomerRecord_Obj.ADDRESS_STATE, testData.get("ADDRESS_STATE"),"ADDRESS STATE");
					compareByText(ICDD_CustomerRecord_Obj.CONTACT_PHONE_DETAILS, testData.get("CONTACT_PHONE_DETAILS"),"CONTACT PHONE DETAILS");
					compareByText(ICDD_CustomerRecord_Obj.CONATCT_EMAIL_DETAILS, testData.get("CONATCT_EMAIL_DETAILS"),"CONATCT EMAIL DETAILS");	
					compareByText(ICDD_CustomerRecord_Obj.DOCUMENT_INFORMATION, testData.get("DOCUMENT_INFORMATION"),"DOCUMENT_INFORMATION");
					compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_DOB, testData.get("CUSTOMER_DOB"),"CUSTOMER_DOB");
					compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_COUNTRY_OFBIRTH, testData.get("CUSTOMER_COUNTRY_OFBIRTH"),"CUSTOMER COUNTRY OF BIRTH");
					compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_NATIONALITY1, testData.get("CUSTOMER_NATIONALITY1"),"CUSTOMER NATIONALITY1");	
					compareByText(ICDD_CustomerRecord_Obj.CUSTOMER_NATIONALITY2, testData.get("CUSTOMER_NATIONALITY2"),"CUSTOMER NATIONALITY2");
					compareByText(ICDD_CustomerRecord_Obj.GENDER, testData.get("GENDER"),"GENDER");
					compareByText(ICDD_CustomerRecord_Obj.EMPLOYMENT_NATURE_OF_EMPLOYMENT, testData.get("EMPLOYMENT_NATURE_OF_EMPLOYMENT"),"EMPLOYMENT_NATURE_OF_EMPLOYMENT");
					compareByText(ICDD_CustomerRecord_Obj.EMPLOYMENT_OCCUPATION, testData.get("EMPLOYMENT_OCCUPATION"),"EMPLOYMENT OCCUPATION");	
					compareByText(ICDD_CustomerRecord_Obj.INCOME_CURRENCY, testData.get("INCOME_CURRENCY"),"INCOME CURRENCY");
					compareByText(ICDD_CustomerRecord_Obj.FATCA_US_RESIDENT, testData.get("FATCA_US_RESIDENT"),"FATCA US RESIDENT");
					compareByText(ICDD_CustomerRecord_Obj.FATCA_PER_US_RESIDENT, testData.get("FATCA_PER_US_RESIDENT"),"FATCA PER US RESIDENT");
					compareByText(ICDD_CustomerRecord_Obj.DOMICILE_COUNTRY_CODE, testData.get("DOMICILE_COUNTRY_CODE"),"DOMICILE COUNTRY CODE");	
					compareByText(ICDD_CustomerRecord_Obj.INTERNAL_SEGMENT, testData.get("INTERNAL_SEGMENT"),"INTERNAL SEGMENT");
					compareByText(ICDD_CustomerRecord_Obj.INTERNAL_BRANCHCODE, testData.get("INTERNAL_BRANCHCODE"),"INTERNAL BRANCHCODE");
					compareByText(ICDD_CustomerRecord_Obj.INTERNAL_ARM_CODE, testData.get("INTERNAL_ARM_CODE"),"INTERNAL ARM CODE");	
					compareByText(ICDD_CustomerRecord_Obj.SUSPICIOUS_FLAG, testData.get("SUSPICIOUS_FLAG"),"SUSPICIOUS FLAG");
					compareByText(ICDD_CustomerRecord_Obj.SELF_RESTRICTION_CHK, testData.get("SELF_RESTRICTION_CHK"),"SELF RESTRICTION CHK");		
			    }
			    
				
				public String CreatePeriodicReviewAlert(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
					webDriverwait(ICDD_WorkItem_Obj.INITIATE_PERIODIC_REVIEW);
					click(ICDD_WorkItem_Obj.INITIATE_PERIODIC_REVIEW);sleep(mediumWaitVal);
					switchToWindow();
					webDriverWait(ICDD_WorkItem_Obj.TRIGGER_REASON);
					actionEnterData(ICDD_WorkItem_Obj.TRIGGER_REASON, testData.get("PERIODIC_TRIGGER_REASON"));
					click(ICDD_WorkItem_Obj.PERIODIC_REVIEW_CONFIRM);sleep(mediumWaitVal);
					webDriverWait(ICDD_WorkItem_Obj.GET_PERIODIC_ALERT);
					String Periodic_review = driver.findElement(ICDD_WorkItem_Obj.GET_PERIODIC_ALERT).getText();
					System.out.println(Periodic_review);
					dataprovider.insertExcelData(scenarioName, "PERIODIC_ALERT_ID", sheetname, Periodic_review);
					click(ICDD_WorkItem_Obj.PERIODIC_ALERT_CLOSE_BUTTON);sleep(minWaitVal);
					switchBackToParentWindow("[Actimize] Customers");
//					driver.switchTo().defaultContent();
					return Periodic_review;
				}
	
	
	 
			public void verifyAlert(String Scenario_Name,HashMap<String, String> testData) throws Exception
			{
			
				 int p = BaseTestSetup.driver.findElements(By.xpath("//table[@id='alertsModel']/tbody/tr")).size();
			        for (int j = 2; j <= p; j++) {
			        	String step=BaseTestSetup.driver.findElement(By.xpath("(//table[@id='alertsModel']//tr)["+j+"]/td[13]")).getText();	
			        	if(step.equalsIgnoreCase("Ready")){
			        		WebElement checkbox=BaseTestSetup.driver.findElement(By.xpath("(//table[@id='alertsModel']//tr)["+j+"]/td[5]"));
			        		checkbox.click();
			        		Thread.sleep(1000);
			        		compareByText(ICDD_CustomerRecord_Obj.CDD_STATUS, testData.get("CDD_STATUS"),"CDD_STATUS");
			        		compareByText(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE, testData.get("NEXT_REVIEW_DATE"),"NEXT_REVIEW_DATE");
			        		compareByText(ICDD_CustomerRecord_Obj.LAST_REVIEW_DATE, testData.get("LAST_REVIEW_DATE"),"LAST_REVIEW_DATE"); }
			        }	     
			        
			}
			
			
	public void ICDD_TagDoc_DocumentsLinkeclassify(String scenarioName,HashMap<String, String> testData) throws Exception{
			    if (!testData.get("FILNET_OPETIONS").trim().isEmpty()) {
					List<WebElement> listOfOptions=BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.FILNET_OPETIONS);
					for (WebElement option : listOfOptions) {
						 System.out.println("Filnet Option" +option.getText());
						 if (option.getText().trim().equalsIgnoreCase(testData.get("FILNET_OPETIONS").trim())) {
							triggerOnClick(option);
								     System.out.println("Acual Filnet Type" +testData.get("FILNET_OPETIONS") + ", Expected Filnet Type is: "+option.getText()+ ". And sucessfully Selected" );}
						}
					}
				String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
				System.out.println("Original wingow:" +originalWindow1);
			    Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		        for (String win : chwin1) { 
		   	    System.out.println("***Entered Window Handles***");
		        if (!originalWindow1.equals(win)) {
		             System.out.println("Inside New Window***");
		             BaseTestSetup.driver.switchTo().window(win);
				if (!testData.get("ID_DOCUMENT_NUMBER").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.ID_DOCUMENT_NUMBER,testData.get("ID_DOCUMENT_NUMBER"));
					System.out.print("ID Document Number entered Sucessfully");}
				if (!testData.get("ACCOUNT_NUMBER1").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.ACCOUNT_NUMBER,testData.get("ACCOUNT_NUMBER1"));
					System.out.print("Account Number entered Sucessfully");}
				if (!testData.get("CARD_NUMBER").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.CARD_NUMBER,testData.get("CARD_NUMBER"));
					System.out.print("Card Number entered Sucessfully");}
				if (!testData.get("LOAN_NUMBER").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.LOAN_NUMBER,testData.get("LOAN_NUMBER"));
					System.out.print("Loan Number entered Sucessfully");}
				if (!testData.get("CUSTOMER_TYPE").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.CUSTOMER_TYPE,testData.get("CUSTOMER_TYPE"));
					System.out.print("Customer Type entered Sucessfully");}
				if (!testData.get("PRODUCT").trim().isEmpty()) {
					inputText(ICDD_WorkItem_Obj.PRODUCT,testData.get("PRODUCT"));
					System.out.print("Product entered Sucessfully");}
				if (!testData.get("DOCUMENT_TYPE_OPTION").trim().isEmpty()) {
					 List<WebElement> listOfOptions=BaseTestSetup.driver.findElements(ICDD_WorkItem_Obj.DOCUMENT_TYPE_OPTION);
					 for (WebElement option : listOfOptions) {
						 System.out.println("Document Type Option" +option.getText());
						 if (option.getText().trim().equalsIgnoreCase(testData.get("DOCUMENT_TYPE_OPTION").trim())) {
							triggerOnClick(option);
								     System.out.println("Acual Dosument Type" +testData.get("DOCUMENT_TYPE_OPTION") + ", Expected Document Type is: "+option.getText()+ ". And sucessfully Selected" );
							   }}
						   
					   }
		        }
		        switchBackToParentWindow(originalWindow1);
		        String originalWindow2 =BaseTestSetup.driver.getWindowHandle();
				System.out.println("Original wingow:" +originalWindow1);
			    Set<String> chwin2 = BaseTestSetup.driver.getWindowHandles();
		        for (String win2 : chwin2) { 
		   	    System.out.println("***Entered Window Handles***");
		        if (!originalWindow1.equals(win2)) {
		             System.out.println("Inside New Window***");
		             BaseTestSetup.driver.switchTo().window(win2);}	
		        }
		  
		}
		}	
			
			
	
	public void viewNote(String scenarioName,HashMap<String, String> testData) throws Exception{
		
			clickPerform(ICDD_WorkItem_Obj.VIEWNOTE);
			String originalWindow1 =BaseTestSetup.driver.getWindowHandle();
			System.out.println("Original wingow:" +originalWindow1);
			Set<String> chwin1 = BaseTestSetup.driver.getWindowHandles();
		    for (String win : chwin1) { 
		   	    System.out.println("***Entered Window Handles***");
		        if (!originalWindow1.equals(win)) {
		             System.out.println("Inside New Window***");
		             BaseTestSetup.driver.switchTo().window(win);
		             List<WebElement> val=BaseTestSetup.driver.findElements(By.xpath("//*[@id='viewNotesGridModel']/tbody/tr[2]/td"));
		             int a= val.size();
		             for(int i=2;i<=a;i++){
		            	 String actualValue=BaseTestSetup.driver.findElement(By.xpath("//*[@id='viewNotesGridModel']/tbody/tr[2]/td["+i+"]")).getText();
		            	 String actualTitle=BaseTestSetup.driver.findElement(By.xpath("//*[@id='viewNotesGridModel_headerTbl']//th["+i+"]/div//div//div//div")).getText();
		            	 System.out.println(actualTitle+ "is : "+actualValue);
		             }
		             clickPerform(ICDD_WorkItem_Obj.CANCEL);
			}
		        BaseTestSetup.driver.switchTo().window(originalWindow1);
		        }

		}
		
			    
	    public void CreateManualTrigger(String scenarioName,HashMap<String, String> testData, String Sheetname) throws Exception{
			//assignToMeAlert();  Click ICDD search ID
	    	sleep(minWaitVal);
		//	driver.switchTo().frame("frmDetails");
			click(ICDD_WorkItem_Obj.INITIATE_TRIGGER_REVIEW);sleep(mediumWaitVal);
			switchWindow("[Actimize] Manual Trigger Review");
			selectDropdown(ICDD_WorkItem_Obj.TRIGGER_REASON, testData.get("MANUAL_TRIGGER_REASON"));
			screenshot();
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_TAB);
    	    robot.keyRelease(KeyEvent.VK_TAB);
    	    enter();sleep(mediumWaitVal);
    	    enter();
		//	click(ICDD_WorkItem_Obj.MANUAL_TRIGGER_CONFIRM);
		//	((JavascriptExecutor) driver).executeScript("window.confirm = function(msg) { return true; }");
			switchBackToParentWindow("[Actimize] Customers");
			webDriverwait(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
			click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
			sleep(minWaitVal);
			String date = getCurrentDate();
			webDriverWait(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']"));
			String Trigger_review=driver.findElement(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']")).getText();
			screenshot();
			Log.info(Trigger_review + " Manual Trigger alert is created");
			System.out.println(Trigger_review + " Manual Trigger alert is created");
			dataprovider.insertExcelData(scenarioName, "MANUAL_TRIGGER_ALERT_ID",Sheetname, Trigger_review);
	    }
				
	/*	public void CreatePeriodicReviewAlert(String scenarioName,HashMap<String, String> testData) throws Exception{
			//assignToMeAlert();
			driver.switchTo().frame("frmDetails");
			click(ICDD_WorkItem_Obj.INITIATE_PERIODIC_REVIEW);sleep(mediumWaitVal);
			switchToWindow();
			actionEnterData(ICDD_WorkItem_Obj.TRIGGER_REASON, testData.get("PERIODIC_TRIGGER_REASON"));
			click(ICDD_WorkItem_Obj.PERIODIC_REVIEW_CONFIRM);sleep(minWaitVal);
			String Periodic_review = driver.findElement(ICDD_WorkItem_Obj.GET_PERIODIC_ALERT).getText();
			dataprovider.insertExcelData(scenarioName, "PERIODIC_ALERT_ID", Periodic_review);
			click(ICDD_WorkItem_Obj.PERIODIC_ALERT_CLOSE_BUTTON);sleep(minWaitVal);
			driver.switchTo().defaultContent();
		}*/
		
	public void logout() throws Exception{
		
			System.out.print("Enter into lOGOUT");
			try{
		    	BaseTestSetup.driver.switchTo().defaultContent();
		    	if (BaseTestSetup.driver.getWindowHandles().size() > 1) {
		            BaseTestSetup.driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		            Set<String> currentWindows = null;
		            while (currentWindows == null || currentWindows.size() < 1) {
		                currentWindows = BaseTestSetup.driver.getWindowHandles();
		            }
		            for (String window : currentWindows) {
		                BaseTestSetup.driver.switchTo().window(window);
		                System.out.println("Window title" + BaseTestSetup.driver.getTitle());
		                if (BaseTestSetup.driver.getTitle().contains("[Actimize] Work Items") || BaseTestSetup.driver.getTitle().contains("[Actimize] Customers") || BaseTestSetup.driver.getTitle().contains("[Actimize] Item Details")) {
		                    break;
		                }
		            }}
		        }catch(Exception e){}
		    	try{
		    		Thread.sleep(4000);
		    		clickPerform(ICDD_WorkItem_Obj.LOGOUT_USERDRPDOWN);   	
		        }
		        catch(Exception e){
		        		jsClickPerform(ICDD_WorkItem_Obj.LOGOUT_USERDRPDOWN);}
		       Thread.sleep(2000);
		       clickPerform(ICDD_WorkItem_Obj.LOGOUT_LOGOUTLINK);
		}	
	
	public void editPrviousForm(String formStep,HashMap<String, String> testData) throws Exception{
		String date = getCurrentDate();
		click(By.xpath("(//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[1])[1]"));
		webDriverWait(By.xpath("(//td[@title='"+date+"']/../td[@title='"+formStep+"']/../td[1])[1]"));
		click(By.xpath("(//td[@title='"+date+"']/../td[@title='"+formStep+"']/../td[1])[1]"));
		screenshot();
		changestep("Capture Data");sleep(minWaitVal);
		sleep(maxWaitVal);
		mouseHoverClick(By.xpath("//a[@id='icon_default_a']"), By.xpath("//li[@title='Edit Item']/a"));
		screenshot();
		sleep(maxWaitVal);
		
		switchToWindow();
		// Start -  Eidt the required feilds in the adverse media form
		selectDropdown(ICDD_Forms_Obj.RISK_OF_ADVERSE_MEDIA, testData.get("RISK_OF_ADVERSE_MEDIA1"));
		screenshot();
	    // End -   Eidt the required feilds in the adverse media form
		
		click(ICDD_Forms_Obj.AM_NEXT);
		sleep(minWaitVal);
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@title='Rich Text AreaPress ALT-F10 for toolbar. Press ALT-0 for help'][@id='noteModelFreeTextNote_ifr']")));
		actionEnterData(ICDD_Forms_Obj.AM_NOTE, testData.get("AM_NOTE"));
		screenshot();
		driver.switchTo().defaultContent();
		click(ICDD_Forms_Obj.AM_FINISH);sleep(maxWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.numberOfWindowsToBe(1));
        switchToParentWindow();
        screenshot();

	
	}


	public void WorkingOnSecondAlert(String scenarioName,HashMap<String, String> testData, String Sheetname) throws Exception {
		sleep(mediumWaitVal);
		/*try{
		acceptAlert();
		enter();
		switchToParentWindow();}
		catch (Exception e) {
			System.out.println(e);
		}*/
		//Navigate to workbench and get the latest open alert
		webDriverwait(ICDD_WorkItem_Obj.CUSTOMER_ALERT);
		click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		String date = getCurrentDate();
		webDriverWait(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']"));
		String Trigger_review=driver.findElement(By.xpath("//td[@title='"+date+"']/../td[@title='High Risk Client']/../td[@aria-describedby='alertsModel_alertId']")).getText();
		screenshot();
		Log.info(Trigger_review + " Manual Trigger alert is created");
		System.out.println(Trigger_review + " Manual Trigger alert is created");
		dataprovider.insertExcelData(scenarioName, "SECOND_MANUAL_TRIGGER_ALERT_ID",Sheetname, Trigger_review);
	}
	}


