package Business_Methods;

import java.util.HashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Object_Repository.ICCD_OnboardingForm_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class ICCD_OnBoardingForm extends Common_Utils{
	
	DataProvider dataprovider = new DataProvider();
	public static HashMap<String, String> excelHashMapValues = new HashMap<String, String>();
	utillities.screenshot screenshot = new utillities.screenshot();
	
	public void primaryOnBoardingForm(String scenarioName, HashMap<String, String> testData) throws Exception{
		
	clickPerform(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_MNUONBOARDING);
    BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_CLINTLINK));
    clickPerform(ICCD_OnboardingForm_Obj.NAVIGATETOPAGES_CLINTLINK);			
	selectElementByNameMethod(Object_Repository.ICCD_OnboardingForm_Obj.OBFORM_CLIENTTYPE, testData.get("CLIENTTYPE"));
	selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_RELATIONTYPE, testData.get("RELATIONTYPE"));
	selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ACCOPENING, testData.get("ACCOPENING"));
   // selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_TITLE, testData.get("TITLE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FIRSTNAME, testData.get("FIRSTNAME"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_MIDDLENAME, testData.get("MIDDLENAME"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_SURNAME, testData.get("SURNAME"));
    screenshot();
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES, testData.get("OTHERKNOWNBYNAMES"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES2, testData.get("OTHERKNOWNBYNAMES2"));
   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES3, testData.get(""));
   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES4, testData.get(""));
   // enterInput(ICCD_OnboardingForm_Obj.OBFORM_FORMERANDORANYOTHERKNOWNBYNAMES5, testData.get(""));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ADDRESSTYPE, testData.get("ADDRESSTYPE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE1, testData.get("ADDLINE1"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE2, testData.get("ADDLINE2"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_ADDLINE3, testData.get("ADDLINE3"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_CITY1, testData.get("CITY1"));
    //waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1);
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_COUNTRY1, testData.get("COUNTRY1"));
  //  enterInput(ICCD_OnboardingForm_Obj.OBFORM_STATE1, testData.get("STATE1"));
    //enterInput(ICCD_OnboardingForm_Obj.OBFORM_POSTAL1, testData.get("POSTAL1"));
    screenshot();
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_PHONETYPE, testData.get("PHONETYPE"));
    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE);
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_COUNTRYCODE, testData.get("COUNTRYCODE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_AREACODE, testData.get("AREACODE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_PHONEDETAILS, testData.get("PHONEDETAILS"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_EMAILTYPE, testData.get("EMAILTYPE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EMAILADDRESS, testData.get("EMAILADDRESS"));
    screenshot();
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCTYPE, testData.get("IDENTITYDOCTYPE"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_IDENTITYDOCUMENTNUMBER, testData.get("IDENTITYDOCUMENTNUMBER"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_EXPIRYDATE, testData.get("EXPIRYDATE"));
    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_DOB);
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_DOB, testData.get("DOB"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_COB, testData.get("COB"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS1, testData.get("NATIONALITIESORCITIZENSHIPS1"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS2, testData.get("NATIONALITIESORCITIZENSHIPS2"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS3, testData.get("NATIONALITIESORCITIZENSHIPS3"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NATIONALITIESORCITIZENSHIPS4, testData.get("NATIONALITIESORCITIZENSHIPS4"));
    screenshot();
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_GENDER, testData.get("GENDER"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NATUREOFEMPLOYMENT, testData.get("NATUREOFEMPLOYMENT"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_OCCUPATION, testData.get("OCCUPATION"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_INDUSTRY, testData.get("INDUSTRY"));
    screenshot();
    try{
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_NAMEOFEMPLOYER, testData.get("NAMEOFEMPLOYER"));
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_NAMEOFEMPLOYER1, testData.get("NAMEOFEMPLOYER1"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_RESIDENT, testData.get("RESIDENT"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_PERMRESIDENT, testData.get("PERMRESIDENT"));
    }catch(Exception e){}
    Thread.sleep(2000);
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTTAB);
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_PRODUCTNAME, testData.get("PRODUCTNAME"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_SUBPRODUCT, testData.get("SUBPRODUCT"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ACCOUNTCURRENCY, testData.get("ACCOUNTCURRENCY"));
    BaseTestSetup.driver.findElement(By.xpath("//option[text()='" + testData.get("REASONESTABLOSHRELATION") + "']")).click();
    screenshot();
    enterInput(ICCD_OnboardingForm_Obj.OBFORM_AMTINIDEPOSIT, testData.get("AMTINIDEPOSIT"));
   try{
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_CURRENCY, testData.get("CURRENCY"));
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("//option[text()='" + testData.get("REASONESTABLOSHRELATION") + "']")));
    BaseTestSetup.driver.findElement(By.xpath("(//option[text()='" + testData.get("TYPEINIDEPOSIT") + "'])[2]")).click();
    Thread.sleep(1000);
    BaseTestSetup.driver.findElement(By.xpath("(//option[text()='" + testData.get("SOURCEOFINITIALFUNDING") + "'])[2]")).click();
    Thread.sleep(1000);
    ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("(//span[text()='Country(s) of initial Deposit'])[2]/../../../following-sibling::div//option[text()='" + testData.get("COUNTRYOFINITIALFUNDING") + "']")));
    BaseTestSetup.driver.findElement(By.xpath("(//span[text()='Country(s) of initial Deposit'])[2]/../../../following-sibling::div//option[text()='" + testData.get("COUNTRYOFINITIALFUNDING") + "']")).click();
   }catch(Exception e){}
    Thread.sleep(2000);
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_INTERNALINFO);
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ACQUISITIONCHANNEL, testData.get("ACQUISITIONCHANNEL"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_SEGMENT, testData.get("SEGMENT"));
    screenshot();
    try{
    if(!(testData.get("SEGMENT").equals("Others"))){
    	selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT, testData.get("SUBSEGMENT"));
    }else{
    	enterInput(ICCD_OnboardingForm_Obj.OBFORM_SUBSEGMENT1, testData.get("SUBSEGMENT"));
    }
    }
    catch(Exception e){}
    
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_BRANCHCODE, testData.get("BRANCHCODE"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ARMCODE1, testData.get("ARMCODE1"));
    BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.BOFORM_OWNERID).clear();
    Thread.sleep(500);
    enterInput(ICCD_OnboardingForm_Obj.BOFORM_OWNERID, testData.get("OWNERID"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_PEPORNOT, testData.get("PEPORNOT"));
    screenshot();
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_SUSSANCTION, testData.get("SUSSANCTION"));
    selectElementByNameMethod(ICCD_OnboardingForm_Obj.OBFORM_ADVERSEINFO, testData.get("ADVERSEINFO"));
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_SUMMARY);
    Thread.sleep(2000);
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_SAVE);
    Thread.sleep(7000);
    screenshot();
    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_VALIDATE);
    Thread.sleep(18000);
    screenshot();
    waitForElement(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
    clickPerform(ICCD_OnboardingForm_Obj.OBFORM_SUBMIT);
    Thread.sleep(10000);
    if (BaseTestSetup.driver.getPageSource().contains("Success")) {
        String partKey=BaseTestSetup.driver.findElement(ICCD_OnboardingForm_Obj.OBFORM_PARTYKEY).getText();
        System.out.println("Partkey value2" +partKey);
        dataprovider.insertExcelData(scenarioName, "MANUAL_TRIGGER_ALERT_ID",partKey);}
    Thread.sleep(2000);
    screenshot();
    for(int i=3;i<=7;i=i+2)
    {
    	 int size=BaseTestSetup.driver.findElements(By.xpath("//*[@id='tab_SUMMARY']/div["+i+"]//tr[1]")).size();
    	 for(int j=1;j<size;j=j+2)
    	 {
    		 ((JavascriptExecutor) BaseTestSetup.driver).executeScript(
    		            "arguments[0].scrollIntoView(true);", BaseTestSetup.driver.findElement(By.xpath("(//*[@id='tab_SUMMARY']/div["+i+"]//tr[1])["+j+"]"))); 
    		 screenshot();
    	 }
    }

}
}
