package Business_Methods;

import java.util.HashMap;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.Minutes;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import Object_Repository.ICM_UpdateCustomerProfilePage_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.SetupPropertiesLoader;

public class ICM_UpdateCustomerProfilePage extends Common_Utils{
	public int minval=500;
	public int medval=1000;
	public int minWaitVal = 2000;
	public int mediumWaitVal = 8500;
	public int maxWaitVal = 15000;
	public HashMap<String, String> testData = null;
	ICM_UpdateCustomerProfilePage_Obj ICM_UpdateCustomerProfilePage_Obj = new ICM_UpdateCustomerProfilePage_Obj();
	 private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	
	int i;

	public void ICMInformation_validattion(String scenarioName,HashMap<String, String> testData) throws Exception {
		this.testData = testData;
		this.login();
		serachForIcmId(testData);
		verify_script();

	}
	
	public void ICMInformation_modifn_validattion(String scenarioName,HashMap<String, String> testData) throws Exception {
		this.testData = testData;
		this.login();
		searchForIcmId_CheckerQueqe();
		this.login();
		serachForIcmId(testData);
//		employmentAndWealthTab();
		Verify_nationality();
		//contactTab();

	}

	public void ICM_Information_Modification(String scenarioName,HashMap<String, String> testData) throws Exception
	{
		this.testData = testData;
		this.login();
		serachForIcmId(testData);
	//	employmentAndWealth_modify();
		nationality_modify();
	//	modify_address();
	//	contact_modify();
   }

	public void login() {
		String UserName = SetupPropertiesLoader.getProperty("ICM_User", "roles"); 
		String Password = SetupPropertiesLoader.getProperty("ICM_Password", "roles");
		webDriverWait(ICM_UpdateCustomerProfilePage_Obj.BANKID);
		inputTextTab(ICM_UpdateCustomerProfilePage_Obj.BANKID, UserName);sleep(minWaitVal);
		inputTextTab(ICM_UpdateCustomerProfilePage_Obj.PASSWORD, Password);sleep(minval);
		webDriverwait(ICM_UpdateCustomerProfilePage_Obj.LOGIN);
		click(ICM_UpdateCustomerProfilePage_Obj.LOGIN);
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			/*WebElement username = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKID);
			username.sendKeys("1");
			username.sendKeys("5");
			username.sendKeys("8");
			username.sendKeys("1");
			username.sendKeys("1");
			username.sendKeys("1");
			username.sendKeys("9");
			//username.sendKeys(Keys.ENTER);
			WebElement password = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PASSWORD);
			password.click();
			password.click();sleep(medval);
			password.sendKeys("S");sleep(minval);
			password.sendKeys("c");sleep(minval);
			password.sendKeys("b");sleep(minval);
			password.sendKeys("@");sleep(minval);
			password.sendKeys("1");sleep(minval);
			password.sendKeys("2");sleep(minval);
			password.sendKeys("3");sleep(minval);
			password.sendKeys("4");sleep(minval);
			password.sendKeys("5");sleep(minval);*/
		//	password.sendKeys(Keys.ENTER);
			/*js.executeScript("arguments[0].click();", driver.findElement(ICM_UpdateCustomerProfilePage_Obj.LOGIN));
			sleep(4000);*/
			Log.info("############## User is able to logged In Successfully ICM Application ###################");
			System.out.println("############## User is able to logged In Successfully ICM Application ###################");
		} catch (Exception e) {
			System.out.println("Unable to Login e-Bundle Application" + e.getMessage());
			Log.error("Unable to Login ICM Application" + e.getMessage());
		}
	}

	public void serachForIcmId(HashMap<String, String> testData) throws Exception {
		//BaseTestSetup.waitForPageLoad(); 
		sleep(minWaitVal);
		BaseTestSetup.wait.until(ExpectedConditions.visibilityOfElementLocated(ICM_UpdateCustomerProfilePage_Obj.ICM_EXPAND));
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ICM_EXPAND);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ENQUIRY);
		webDriverWait(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY);sleep(minWaitVal);
		Log.info("User is able clicked on Profile Enquiry Tab");
		webDriverWait(ICM_UpdateCustomerProfilePage_Obj.ICM_ID);
		click(ICM_UpdateCustomerProfilePage_Obj.ICM_ID);sleep(minval);
		inputText(ICM_UpdateCustomerProfilePage_Obj.ICM_ID, testData.get("icmID").trim());
		Log.info("User is able to search ICM ID Sucessfully");
		webDriverwait(ICM_UpdateCustomerProfilePage_Obj.ENQUIRY_SUBMIT);sleep(minval);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ENQUIRY_SUBMIT);sleep(mediumWaitVal);
		clickIcmId(testData);}
	
	
	public void searchForIcmId_CheckerQueqe()
	{
		sleep(mediumWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ICM_EXPAND);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.QUEQUES);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.CHECKEER_QUEQUES);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.UPDATE_COSTOMER_PROFILE);
		Log.info("User is able to clicked on Update Customer Profile Tab");
		inputText(ICM_UpdateCustomerProfilePage_Obj.SEARCH_FILTER, testData.get("icmID"));
		driver.findElement(By.xpath("//a[text()='" + testData.get("icmID") + "']")).click();sleep(minval);
		sleep(mediumWaitVal);
		Log.info("User is able to search ICM Id Sucessfully");
		actionClick(ICM_UpdateCustomerProfilePage_Obj.APPROVE_BUTTON);
		sleep(mediumWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);
		Log.info("User is able to clicked on Approve Button");
		actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
		Log.info("User is able to Logged Out Sucessfully");
	}

	public void clickIcmId(HashMap<String, String> testData) {
		//waitForTextToLoad(By.xpath("//h1[text()='List Of Profiles - Already Exist']"), "List Of Profiles - Already Exist");
		webDriverwait(By.xpath("//a[text()='" + testData.get("icmID") + "']"));
		click(By.xpath("//a[text()='" + testData.get("icmID") + "']")); //sleep(mediumWaitVal);
		boolean alertPresents = false;
		Alert alert = null;
		for (String winHandle : driver.getWindowHandles()) {
			driver.switchTo().window(winHandle);
			try {
				sleep(5000);
				alert = driver.switchTo().alert();
				alertPresents = true;
				break;
			} catch (NoAlertPresentException Ex) {
			}
		}
		if (alertPresents) {
			alert.accept();sleep(minWaitVal);
			Log.info("User is able to clicked on ICM Id Sucessfully");}
	}

	public void basicInfoTab()
	{
		if (!testData.get("RelationshipNo").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value").contains(testData.get("RelationshipNo"))){
					System.out.println("Actual ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipNo") + ". And it matches");
					Log.info("Actual ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipNo") + ". And it matches");
				}
			}
		}
		if (!testData.get("Reopencounter").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_COUNTER).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_COUNTER).getAttribute("value").contains(testData.get("Reopencounter"))){
					System.out.println("Actual REOPEN COUNTER valueis: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_COUNTER).getAttribute("value") + ", Expected REOPEN COUNTER value is: " + testData.get("Reopencounter") + ". And it matches");
					Log.info("Actual REOPEN COUNTER valueis: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_COUNTER).getAttribute("value") + ", Expected REOPEN COUNTER value is: " + testData.get("Reopencounter") + ". And it matches");
				}
			}
		}

		if (!testData.get("ReopenReasoncode").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_REASON_CODE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_REASON_CODE).getAttribute("ReopenReasoncode").contains(testData.get("ReopenReasoncode"))){
					System.out.println("Reopen Reason Code Value is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_REASON_CODE).getAttribute("value") + ", Expected Reopen Reason Code Value is: " + testData.get("status") + ". And it matches");
					Log.info("Reopen Reason Code Value is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REOPEN_REASON_CODE).getAttribute("value") + ", Expected Reopen Reason Code Value is: " + testData.get("status") + ". And it matches");
				}
			}
		}

		if (!testData.get("DeDupNumber").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_NUMBER).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_NUMBER).getAttribute("value").contains(testData.get("DeDupNumber"))){
					System.out.println("DEDUPE NUMBER is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_NUMBER).getAttribute("value") + ", Expected DEDUPE NUMBER is: " + testData.get("DeDupNumber") + ". And it matches");
					Log.info("DEDUPE NUMBER is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_NUMBER).getAttribute("value") + ", Expected DEDUPE NUMBER is: " + testData.get("DeDupNumber") + ". And it matches");
				}
			}
		}
		if (!testData.get("DeDupReason").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_REASON).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_REASON).getAttribute("value").contains(testData.get("DeDupReason"))){
					System.out.println("DEDUPE REASON is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_REASON).getAttribute("value") + ", Expected DEDUPE REASON is: " + testData.get("DeDupReason") + ". And it matches");
					Log.info("DEDUPE REASON is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DEDUPE_REASON).getAttribute("value") + ", Expected DEDUPE REASON is: " + testData.get("DeDupReason") + ". And it matches");}
			}
		}
		if (!testData.get("DeDupComments").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DESDUPE_COMMENT).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DESDUPE_COMMENT).getAttribute("value").contains(testData.get("DeDupComments"))){
					System.out.println("DESDUPE COMMENT is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DESDUPE_COMMENT).getAttribute("value") + ", Expected DESDUPE COMMENT is: " + testData.get("DeDupComments") + ". And it matches");
					Log.info("DESDUPE COMMENT is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DESDUPE_COMMENT).getAttribute("value") + ", Expected DESDUPE COMMENT is: " + testData.get("DeDupComments") + ". And it matches");
				}
			}
		}
		if (!testData.get("ProfileCloseDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_CLOSED_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_CLOSED_DATE).getAttribute("value").contains(testData.get("ProfileCloseDate"))){
					System.out.println("PROFILE CLOSED DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_CLOSED_DATE).getAttribute("value") + ", Expected PROFILE CLOSED DATE is: " + testData.get("ProfileCloseDate") + ". And it matches");
					Log.info("PROFILE CLOSED DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_CLOSED_DATE).getAttribute("value") + ", Expected PROFILE CLOSED DATE is: " + testData.get("ProfileCloseDate") + ". And it matches");
				}
			}
		}
		if (!testData.get("ProfileType").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText().trim() != null) {
				System.out.println(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText());
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText().contains(testData.get("ProfileType"))){
					System.out.println("PROFILE TYPE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText() + ", Expected PROFILE TYPE is: " + testData.get("ProfileType") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("status").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_STATUS).getText().trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_STATUS).getText().contains(testData.get("status"))){
					System.out.println("status  is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_STATUS).getText() + ", Expected status  is: " + testData.get("status") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("Title").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value").contains(testData.get("Title"))){
					System.out.println("TITLE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value") + ", Expected TITLE is: " + testData.get("Title") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("FullName").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value").contains(testData.get("FullName"))){
					System.out.println("FULL NAME is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value") + ", Expected FULL NAME is: " + testData.get("FullName") + ". And it matches");
					Log.info("");
				}
			}
		}


		/*   List<WebElement> tr_collection_alias= driver.findElements(ICM_UpdateCustomerProfilePage_Obj.BASIC_ALIAS_TOTAL_ROWS);
	   int row=1,col=1;
	   for (WebElement trElement2 : tr_collection_alias) 
	   {
         List<WebElement> td_collection_alias = trElement2.findElements(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div)["+row+"]/div/div//md-select")); 
	    int n = td_collection_alias.size();
	    	col=1;
	    for (WebElement tdElement  :td_collection_alias)
	    {
	    	String ExpectedValue = driver.findElement(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-toolbar/div/div)["+col+"]")).getText().trim();
	    	System.out.println("Expected Value"+ExpectedValue);
	    	switch (ExpectedValue) {
			case "Alias Type":
				if (!testData.get("AliasType").trim().isEmpty()) {
					  if (tdElement.getText().trim() != null) {
						   if(tdElement.getText().equalsIgnoreCase(testData.get("AliasType"))){
							   System.out.println("Alias Type Value is: " +tdElement.getText() + ", Expected Alias Type Value is: " + testData.get("AliasType") + ". And it matches");
							    }
						   }
		    	}
				col++;
				break;
			case "Alias":
				if (!testData.get("Alias").trim().isEmpty()) {
					  if (tdElement.getText().trim() != null) {
						   if(tdElement.getText().equalsIgnoreCase(testData.get("Alias"))){
							   System.out.println("Alias Value is: " +tdElement.getText() + ", Expected Alias Value is: " + testData.get("Alias") + ". And it matches");
							    }
						   }
		    	}	


			default:
				col++;
	            break;
	    	}
	    }
	    if(row<=tr_collection_alias.size())
	     row++;
	  }  */


		if (!testData.get("Gender").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText().trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText().contains(testData.get("Gender"))){
					System.out.println("Gender is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText() + ", Expected Gender is: " + testData.get("Gender") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("DateofBirth").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value").contains(testData.get("DateofBirth"))){
					System.out.println("Date of Birth is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value") + ", Expected Date of Birth is: " + testData.get("DateofBirth") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("Nationality").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").contains(testData.get("Nationality"))){
					System.out.println("Nationality is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value") + ", Expected Nationality is: " + testData.get("Nationality") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("EducationalQualification").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value").contains(testData.get("EducationalQualification"))){
					System.out.println("Educational Qualification is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value") + ", Expected Educational Qualification is: " + testData.get("EducationalQualification") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("MaritalStatus").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getAttribute("value").contains(testData.get("MaritalStatus"))){
					System.out.println("Marital Status is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getAttribute("value") + ", Expected Marital Status is: " + testData.get("MaritalStatus") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("PreferredStatementLanguage").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value").contains(testData.get("PreferredStatementLanguage"))){
					System.out.println("Preferred Statement Language is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value") + ", Expected Preferred Statement Language is: " + testData.get("PreferredStatementLanguage") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("ResidenceCountry").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REDIDENCE_COUNTRY).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REDIDENCE_COUNTRY).getAttribute("value").contains(testData.get("ResidenceCountry"))){
					System.out.println("Residence Country is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_REDIDENCE_COUNTRY).getAttribute("value") + ", Expected Residence Country is: " + testData.get("ResidenceCountry") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("CountryOfBirth").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value").contains(testData.get("CountryOfBirth"))){
					System.out.println("Country Of Birth is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value") + ", Expected Country Of Birth is: " + testData.get("CountryOfBirth") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("PlaceofBirth").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").contains(testData.get("PlaceofBirth"))){
					System.out.println("Place of Birth is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value") + ", Expected Place of Birth is: " + testData.get("PlaceofBirth") + ". And it matches");
					Log.info("");
				}
			}
		}
		if (!testData.get("PreferredLanguageofCommunication").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value").contains(testData.get("PreferredLanguageofCommunication"))){
					System.out.println("Preferred Language of Communication is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value") + ", Expected Preferred Language of Communication is: " + testData.get("PreferredLanguageofCommunication") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("NoofDependants").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getText().trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getText().contains(testData.get("NoofDependants"))){
					System.out.println("No of Dependants is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getText() + ", Expected No of Dependants is: " + testData.get("NoofDependants") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("Residence Status").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RESIDNECE_STATUS).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RESIDNECE_STATUS).getAttribute("value").contains(testData.get("RelationshipNo"))){
					System.out.println("ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RESIDNECE_STATUS).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipNo") + ". And it matches");
					Log.info("");
				}
			}
		}

		if(!testData.get("ResidenceStatus").trim().isEmpty()){
			List<WebElement> residencestatus=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.TOTAL_RESIDENCE_STATUS);
			for(i=1;i<=residencestatus.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='tab-content-0']//div[19]/div//md-radio-group/md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("ResidenceStatus").equalsIgnoreCase("Resident"))){
					System.out.println("Residence status value is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("ResidenceStatus").equalsIgnoreCase("Non Resident"))){
					System.out.println("Residence status value is No");
					Log.info("");}
			}		
		}

		List<WebElement> tr_collection_alias= driver.findElements(ICM_UpdateCustomerProfilePage_Obj.BASIC_ALIAS_TOTAL_ROWS);
		int row=1,col=1;
		int rowNum=0;
		for (WebElement trElement2 : tr_collection_alias) 
		{
			List<WebElement> td_collection_alias = trElement2.findElements(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div)["+row+"]/div/div")); 
			int n = td_collection_alias.size();
			col=1;
			for (WebElement tdElement  :td_collection_alias)
			{
				String ExpectedValue = driver.findElement(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-toolbar/div/div)["+col+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Alias Type":
					if (!testData.get("AliasType").trim().isEmpty()) {
						String array1[] = testData.get("AliasType").split("\\|");
						WebElement tdElement1=driver.findElement(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div)["+row+"]/div/div["+col+"]//md-input-container"));
						System.out.print(tdElement1.getText());  
						if (tdElement1.getText().trim() != null) {
							if(testData.get("AliasType").contains(tdElement1.getText())){
								System.out.println("Alias Type Value is: " +tdElement1.getText() + ", Expected Alias Type Value is: " + testData.get("AliasType") + ". And it matches");
								Log.info("");
							}
						}
					}
					col++;
					break;
				case "Alias":
					if (!testData.get("Alias").trim().isEmpty()) {
						String array1[] = testData.get("Alias").split("\\|");
						WebElement tdElement2=driver.findElement(By.xpath("(//*[starts-with(@id,'tab-content')]/div/md-content/div/div/form/div/div[11]/div/md-content/md-card/md-card-content/div)["+row+"]/div/div["+col+"]//md-input-container/input"));
						if (tdElement2.getAttribute("value").trim() != null) {
							if(tdElement2.getAttribute("value").equalsIgnoreCase(testData.get("Alias"))){
								System.out.println("Alias Value is: " +tdElement2.getAttribute("value") + ", Expected Alias Value is: " + testData.get("Alias") + ". And it matches");
								Log.info("");
							}
						}
					}	
					col++;
					break;

				default:
					col++;
					break;
				}
			}
			if(row<=tr_collection_alias.size())
				row++;
		}
		rowNum++;





	}  

	public void addressTab()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_NO_OF_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='addressForm']/div[3]/div/table//tr[1])[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Type":
					if (!testData.get("AddressType").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("AddressType"))){
								System.out.println("Address Type Value is: " +tdElement.getText() + ", Expected Address Type Value is: " + testData.get("AddressType") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Address 1":
					if (!testData.get("Address1").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Address1"))){
								System.out.println("Address1 is: " +tdElement.getText() + ", Expected Address1 is: " + testData.get("Address1") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Address 2":
					if (!testData.get("Address2").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Address2"))){
								System.out.println("Address2 is: " +tdElement.getText() + ", Expected Address2 is: " + testData.get("Address2") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Address 3":
					if (!testData.get("Address3").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Address3"))){
								System.out.println("Address3 is: " +tdElement.getText() + ", Expected Address3 is: " + testData.get("Address3") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "City":
					if (!testData.get("City").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("City"))){
								System.out.println("City is: " +tdElement.getText() + ", Expected City is: " + testData.get("City") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "State":
					if (!testData.get("State").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("State"))){
								System.out.println("State is: " +tdElement.getText() + ", Expected State is: " + testData.get("State") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Postal Code":
					if (!testData.get("PostalCode").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("PostalCode"))){
								System.out.println("Postal Code Value is: " +tdElement.getText() + ", Expected Postal Code Value is: " + testData.get("PostalCode") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Country":
					if (!testData.get("Country").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Country"))){
								System.out.println("Country Value is: " +tdElement.getText() + ", Expected Country Value is: " + testData.get("Country") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Mailing Address":
					if (!testData.get("MailingAddress").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("MailingAddress"))){
								System.out.println("Mailing Address is: " +tdElement.getText() + ", Expected Mailing Address is: " + testData.get("MailingAddress") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Address Invalid Indicator":
					if (!testData.get("AddressInvalidIndicatorA").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("AddressInvalidIndicatorA"))){
								System.out.println("Address Invalid Indicator Value is: " +tdElement.getText() + ", Expected Address Invalid Indicator Value is: " + testData.get("AddressInvalidIndicatorA") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Action":
					if (!testData.get("AdressAction").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("AdressAction"))){
								System.out.println("AdressAction Value is: " +tdElement.getText() + ", Expected AdressAction Value is: " + testData.get("AdressAction") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;

				default:
					col_num++;
					break;
				}	

			}
			// row_num++;
		}
	}

	public void contactTab()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_DETAILS_TABLE_ROW);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String value=driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]/td[1]")).getText();
				if(testData.get("Classification").equalsIgnoreCase(value))	
				{
			    driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]")).click();
			    String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-2']//div[3]/div/table//tr[1])[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
			    switch (ExpectedValue) {
				
				case "Type":
					if (!testData.get("Type").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Type"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("Type") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Home/Office":
					if (!testData.get("Home/Office").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Home/Office"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("Home/Office") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Details":
					if (!testData.get("Details").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Details"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("Details") + ". And it matches");
								Log.info("");
							}
						}

					}
					col_num++;
					break;
				case "Primary Contact":
					if (!testData.get("PrimaryContact").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("PrimaryContact"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("PrimaryContact") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Action":
					if (!testData.get("Action").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Action"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("Action") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;

				default:
					col_num++;
					break;
				}	
				}
				
			}
			if(row_num<=tr_collection.size())
				row_num++;
		}
	} 

	public void documentTab()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_DETAILS_ROW);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-3']//form/div[3]/div/table//tr)[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Document Category":
					if (!testData.get("DocumentCategory").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("DocumentCategory"))){
								System.out.println("Document Category Value is: " +tdElement.getText() + ", Expected Document Category Value is: " + testData.get("DocumentCategory") + ". And it matches");
								Log.info("");
							}
						}				  
					}
					col_num++;
					break;
				case "Name":
					if (!testData.get("DocumentName").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("DocumentName"))){
								System.out.println("Document Name Value is: " +tdElement.getText() + ", Expected Document Name is: " + testData.get("DocumentName") + ". And it matches");
								Log.info("");
							}
						}	  
					}
					col_num++;
					break;
				case "Number":
					if (!testData.get("DocumentNumber").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("DocumentNumber"))){
								System.out.println("Document Number is: " +tdElement.getText() + ", Expected Document Number is: " + testData.get("Document Number") + ". And it matches");
								Log.info("");
							}
						}  
					}
					col_num++;
					break;
				case "Expiry Date":
					if (!testData.get("ExpiryDate").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("ExpiryDate"))){
								System.out.println("Expiry Date Value is: " +tdElement.getText() + ", Expected Expiry Date Value is: " + testData.get("ExpiryDate") + ". And it matches");
								Log.info("");}
						}
					}
					col_num++;
					break;
				case "Country of Tax Residency":
					if (!testData.get("CountryofTaxResidency").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("CountryofTaxResidency"))){
								System.out.println("Country of TaxR esidency Value is: " +tdElement.getText() + ", Expected Country of TaxResidency Value is: " + testData.get("CountryofTaxResidency") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;
				case "Action":
					if (!testData.get("Action1").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("Action1"))){
								System.out.println("Type Value is: " +tdElement.getText() + ", Expected Type Value is: " + testData.get("Action1") + ". And it matches");
								Log.info("");
							}
						}
					}
					col_num++;
					break;

				default:
					col_num++;
					break;
				}		
			}
		}
	} 

	public void fatcaTab()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.FATCA_TAB).click();
		if(!testData.get("USResident").trim().isEmpty()){
			List<WebElement> usresidenttab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_RESIDENT);
			for(i=1;i<=usresidenttab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]/md-card//div[1]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("USResident").equalsIgnoreCase("Yes"))){
					System.out.println("USResident value is Yes");
					Log.info("");
				}  else if (str.equals("true")&&(testData.get("USResident").equalsIgnoreCase("No"))){
					System.out.println("USResident value is No");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("USResident").equalsIgnoreCase("Not Applicable"))){
					System.out.println("USResident value is Not Applicable");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("USResident").equalsIgnoreCase("Not Answered"))){
					System.out.println("USResident value is Not Answered");
					Log.info("");}
			}}


		if(!testData.get("USCitizen").trim().isEmpty()){
			List<WebElement> uscitizentab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_CITIZEN);
			for(i=1;i<=uscitizentab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[3]/div[2]/md-input-container/md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("USCitizen").equalsIgnoreCase("Yes"))){
					System.out.println("USCitizen value is Yes");
					Log.info("");
				}  else if (str.equals("true")&&(testData.get("USCitizen").equalsIgnoreCase("No"))){
					System.out.println("USCitizen value is No");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("USCitizen").equalsIgnoreCase("Not Applicable"))){
					System.out.println("USCitizen value is Not Applicable");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("USCitizen").equalsIgnoreCase("Not Answered"))){
					System.out.println("USCitizen value is Not Answered");
					Log.info("");}
			}}

		if(!testData.get("GreenCardHolder").trim().isEmpty()){
			List<WebElement> greencardholdertab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.GREEN_CARD_HOLDER);
			for(i=1;i<=greencardholdertab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[4]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("GreenCardHolder").equalsIgnoreCase("Yes"))){
					System.out.println("GreenCardHolder value is Yes");
					Log.info("");
				}  else if (str.equals("true")&&(testData.get("GreenCardHolder").equalsIgnoreCase("No"))){
					System.out.println("GreenCardHolder value is No");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("GreenCardHolder").equalsIgnoreCase("Not Applicable"))){
					System.out.println("GreenCardHolder value is Not Applicable");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("GreenCardHolder").equalsIgnoreCase("Not Answered"))){
					System.out.println("GreenCardHolder value is Not Answered");
					Log.info("");}
			}}

		if(!testData.get("USIndiciaIdentifier").trim().isEmpty()){
			List<WebElement> usindiciaindentifiertab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_INDICIA_INDENFIER);
			for(i=1;i<=usindiciaindentifiertab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[5]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("USIndiciaIdentifier").equalsIgnoreCase("Yes"))){
					System.out.println("US Indicia Identifier value is Yes");
					Log.info("");
				}  else if (str.equals("true")&&(testData.get("USIndiciaIdentifier").equalsIgnoreCase("No"))){
					System.out.println("US Indicia Identifier value is No");
					Log.info("");}
			}
		}

		if(!testData.get("USPersonIndicator").trim().isEmpty()){
			List<WebElement> uspersonindicatortab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_PERSON_INDICATOR);
			for(i=1;i<=uspersonindicatortab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[6]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("USPersonIndicator").equalsIgnoreCase("Yes"))){
					System.out.println("US Person Indicator value is Yes");
					Log.info("");
				}  else if (str.equals("true")&&(testData.get("USPersonIndicator").equalsIgnoreCase("No"))){
					System.out.println("US Person Indicator value is No");
					Log.info("");}
			}
		}
		if(!testData.get("ReporttoIRSIndicator").trim().isEmpty()){
			List<WebElement> reporttoirsindicatortab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.REPORT_TO_IRS_INDICATOR);
			for(i=1;i<=reporttoirsindicatortab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[7]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("ReporttoIRSIndicator").equalsIgnoreCase("Yes"))){
					System.out.println("Report to IRS Indicator value is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("ReporttoIRSIndicator").equalsIgnoreCase("No"))){
					System.out.println("Report to IRS Indicator value is No");
					Log.info("");}
			}		
		}
		if(!testData.get("WithholdForFATCAIndicator").trim().isEmpty()){
			List<WebElement> withholdforfatcaindicatortab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.WITHHOLD_FOR_FATCA_INDICATOR);
			for(i=1;i<=withholdforfatcaindicatortab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[6]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("WithholdForFATCAIndicator").equalsIgnoreCase("Yes"))){
					System.out.println("With hold For FATCA Indicator value is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("WithholdForFATCAIndicator").equalsIgnoreCase("No"))){
					System.out.println("With hold For FATCA Indicator value is No");
					Log.info("");}
			}	
		}
		if(!testData.get("RecalcitrantFlag").trim().isEmpty()){
			List<WebElement> recalcitrantflag=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_FLAG);
			for(i=1;i<=recalcitrantflag.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[2]//div[1]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("RecalcitrantFlag").equalsIgnoreCase("Yes"))){
					System.out.println("Recalcitrant Flag value is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("RecalcitrantFlag").equalsIgnoreCase("No"))){
					System.out.println("Recalcitrant Flag value is No");
					Log.info("");}
			}	
		}
		if (!testData.get("Recalcitrantidentifierassigneddate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_ASSIGN_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_ASSIGN_DATE).getAttribute("value").equalsIgnoreCase(testData.get("Recalcitrantidentifierassigneddate"))){
					System.out.print("RECALCITRANT IND ASSIGN DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_ASSIGN_DATE).getAttribute("value") + ", Expected RECALCITRANT IND ASSIGN DATE is: " + testData.get("Recalcitrantidentifierassigneddate") + ". And it matches");
					Log.info("");
				}
			}
		}

		if (!testData.get("Recalcitrantidentifiercleareddate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_CLEARED_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_CLEARED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("Recalcitrantidentifiercleareddate"))){
					System.out.print("RECALCITRANT IND CLEARED DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RECALCITRANT_IND_CLEARED_DATE).getAttribute("value") + ", Expected RECALCITRANT IND CLEARED DATE is: " + testData.get("Recalcitrantidentifiercleareddate") + ". And it matches");
					Log.info("");
				}
			}
		} 

		if(!testData.get("EnhancedReview").trim().isEmpty()){
			List<WebElement> enhancereviewtab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW);
			for(i=1;i<=enhancereviewtab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[2]/md-card//div[4]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("EnhancedReview").equalsIgnoreCase("Yes"))){
					System.out.println("Enhanced Review value is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("EnhancedReview").equalsIgnoreCase("No"))){
					System.out.println("Enhanced Review value is No");
					Log.info("");}	
			}

		}

		if (!testData.get("EnhancedReviewStartdate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_START_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_START_DATE).getAttribute("value").equalsIgnoreCase(testData.get("EnhancedReviewStartdate"))){
					System.out.print("ENHANCE REVIEW START DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_START_DATE).getAttribute("value") + ", Expected ENHANCE REVIEW START DATE is: " + testData.get("EnhancedReviewStartdate") + ". And it matches");
					Log.info("");
				}
			}
		} 

		if (!testData.get("EnhancedReviewEnddate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_END_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_END_DATE).getAttribute("value").equalsIgnoreCase(testData.get("EnhancedReviewEnddate"))){
					System.out.print("ENHANCE REVIEW END DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ENHANCE_REVIEW_END_DATE).getAttribute("value") + ", Expected ENHANCE REVIEW END DATE is: " + testData.get("EnhancedReviewEnddate") + ". And it matches");
					Log.info("");
				}
			}
		}  

		if(!testData.get("FATCADocumentsubmitted").trim().isEmpty()){
			List<WebElement> fatcadocumentsubmited=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.FATCA_DOCUMENT_SUBMITED);
			for(i=1;i<=fatcadocumentsubmited.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[2]//div[7]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("FATCADocumentsubmitted").equalsIgnoreCase("Yes"))){
					System.out.println("FATCA Document submitted is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("FATCADocumentsubmitted").equalsIgnoreCase("No"))){
					System.out.println("FATCA Document submitted is No");
					Log.info("");}	
			}

		}


		if (!testData.get("DueFromDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DUE_FROM_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DUE_FROM_DATE).getAttribute("value").equalsIgnoreCase(testData.get("DueFromDate"))){
					System.out.print("DUE FROM DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DUE_FROM_DATE).getAttribute("value") + ", Expected DUE FROM DATE is: " + testData.get("DueFromDate") + ". And it matches");
					Log.info("");}
			}
		}  

		if (!testData.get("USIndiciaLastUpdatedDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_INDICIA_LAST_UPDATED_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_INDICIA_LAST_UPDATED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("USIndiciaLastUpdatedDate"))){
					System.out.print("US INDICIA LAST UPDATED DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_INDICIA_LAST_UPDATED_DATE).getAttribute("value") + ", Expected US INDICIA LAST UPDATED DATE is: " + testData.get("USIndiciaLastUpdatedDate") + ". And it matches");
					Log.info("");}
			}
		}  

		if (!testData.get("USPersonLastUpdatedDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_PERSON_LAST_UPDATE_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_PERSON_LAST_UPDATE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("USPersonLastUpdatedDate"))){
					System.out.print("US PERSON LAST UPDATE DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.US_PERSON_LAST_UPDATE_DATE).getAttribute("value") + ", Expected US PERSON LAST UPDATE DATE is: " + testData.get("USPersonLastUpdatedDate") + ". And it matches");
					Log.info("");}
			}
		}  
	}   

	public void cddTab() {
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD).click();
		if (!testData.get("CustomerCDDStatus").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value").equalsIgnoreCase(testData.get("CustomerCDDStatus"))){
					System.out.print("CDD Status is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value") + ", Expected CDD status is: " + testData.get("CustomerCDDStatus") + ". And it matches");
					Log.info("");}
			}
		}

		if (!testData.get("CDDRemarks").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_REMARK).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_REMARK).getAttribute("value").equalsIgnoreCase(testData.get("CDDRemarks"))){
					System.out.print("CDD REMARK is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_REMARK).getAttribute("value") + ", Expected CDD REMARK is: " + testData.get("CDDRemarks") + ". And it matches");
					Log.info("");}
			}
		} 
		if (!testData.get("CDDLastReviewedDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CDDLastReviewedDate"))){
					System.out.print("CDD LAST REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value") + ", Expected CDD LAST REVIEW DATE is: " + testData.get("CDDLastReviewedDate") + ". And it matches");
					Log.info("");}
			}
		}
		if (!testData.get("CDDNextReviewBy").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_BY).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_BY).getAttribute("value").equalsIgnoreCase(testData.get("CDDNextReviewBy"))){
					System.out.print("CDD LAST REVIEW BY is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_BY).getAttribute("value") + ", Expected CDD LAST REVIEW BY is: " + testData.get("CDDNextReviewBy") + ". And it matches");
					Log.info("");}
			}
		}
		if (!testData.get("CDDNextReviewDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CDDNextReviewDate"))){
					System.out.print("CDD NEXT REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value") + ", Expected CDD NEXT REVIEW DATE is: " + testData.get("CDDNextReviewDate") + ". And it matches");
					Log.info("");}
			}
		}
		if (!testData.get("SDDEligibleDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SDD_ELIGIABLE_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SDD_ELIGIABLE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("SDDEligibleDate"))){
					System.out.print("SDD ELIGIABLE DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SDD_ELIGIABLE_DATE).getAttribute("value") + ", Expected SDD ELIGIABLE DATE is: " + testData.get("SDDEligibleDate") + ". And it matches");
					Log.info("");}
			}
		}
		if (!testData.get("RiskRatingDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_RATING_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_RATING_DATE).getAttribute("value").equalsIgnoreCase(testData.get("RiskRatingDate"))){
					System.out.print("RISK RATING DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_RATING_DATE).getAttribute("value") + ", Expected RISK RATING DATE is: " + testData.get("RiskRatingDate") + ". And it matches");
					Log.info("");}
			}
		}
		if (!testData.get("CDDRiskCode").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value").trim() != null) {
				System.out.println(testData.get("CDDRiskCode"));
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value").equalsIgnoreCase(testData.get("CDDRiskCode"))){
					System.out.print("CDD RISK CODE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value") + ", Expected CDD RISK CODE is: " + testData.get("CDDRiskCode") + ". And it matches");
					Log.info("");}
			}
		}

		if(!testData.get("CDDReviewedFlag").trim().isEmpty())
		{
			List<WebElement> cddreviewflagradioButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CDD_REVIEWED_FLAG);
			for(i=1;i<=cddreviewflagradioButton.size();i++)
			{
				String str = driver.findElement(By.xpath("(//*[@id='tab-content-6']//div[1]/div[1]/div[1]//md-radio-group/div/md-radio-button)"+"["+i+"]"))
						.getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("CDDReviewedFlag").equalsIgnoreCase("Yes"))){
					System.out.println("CDD Reviewed Flag is Yes");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("CDDReviewedFlag").equalsIgnoreCase("No"))){
					System.out.println("CDD Reviewed Flag is No");
					Log.info("");}
			}
		}
		if(!testData.get("SDDEligible").trim().isEmpty())
		{
			List<WebElement> cddreviewflagradioButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CDD_REVIEWED_FLAG);
			for(i=1;i<=cddreviewflagradioButton.size();i++)
			{
				String str = driver.findElement(By.xpath("(//*[@id='tab-content-6']//div[1]/div[2]/div[3]/div/md-input-container/md-radio-group/div/md-radio-button)"+"["+i+"]"))
						.getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("SDDEligible").equalsIgnoreCase("Yes"))){
					System.out.println("SDD Eligible Flag is Yes");
					Log.info("");}
				else if (str.equals("true")&&(testData.get("SDDEligible").equalsIgnoreCase("No"))){
					System.out.println("SDD Eligible Flag is No");
					Log.info("");}
			}
		}

	}

	public void risk()
	{ 
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_RISK).click();

		if (!testData.get("RelationshipNo").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value").contains(testData.get("RelationshipNo"))){
					System.out.println("ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipNo") + ". And it matches");
					Log.info("");}
			}
		}
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.RISK_CODE_TABLE_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(ICM_UpdateCustomerProfilePage_Obj.RISK_CODE_TABLE_COLUME); 

			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-7']//div[2]/div/table//tr[1])[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Risk Code - Description":
					if (!testData.get("RiskCodeDescription").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("RiskCodeDescription"))){
								System.out.println("Document Category Value is: " +tdElement.getText() + ", Expected Document Category Value is: " + testData.get("RiskCodeDescription") + ". And it matches");
								Log.info("");
							}
							else
							{
								System.out.println("Document Category Value is: " +tdElement.getText() + ", Expected Document Category Value is: " + testData.get("RiskCodeDescription") + ". And it does not matches");
								Log.info("");
							}
						}				  
					}
					col_num++;
					break;
				case "Start Date":
					if (!testData.get("StartDate").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("StartDate"))){
								System.out.println("Start Date Value is: " +tdElement.getText() + ", Expected Start Date Value is: " + testData.get("StartDate") + ". And it matches");
								Log.info("");}
							else{
								System.out.println("Start Date Value is: " +tdElement.getText() + ", Expected Start Date Value is: " + testData.get("StartDate") + ". And it does not matches");
								Log.info("");}
						}	  
					}
					col_num++;
					break;
				case "Expiry Date":
					if (!testData.get("ExpiryDate").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("ExpiryDate"))){
								System.out.println("Expiry Date is: " +tdElement.getText() + ", Expected Expiry Date is: " + testData.get("ExpiryDate") + ". And it matches");
								Log.info("");}
							else{
								System.out.println("Expiry Date is: " +tdElement.getText() + ", Expected Expiry Date is: " + testData.get("StartDate") + ". And it matches");
								Log.info("");}
						}  
					}
					col_num++;
					break;
				case "Department Code":
					if (!testData.get("DepartmentCode").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("DepartmentCode"))){
								System.out.println("Department Code Value is: " +tdElement.getText() + ", Expected Department Code Value is: " + testData.get("DepartmentCode") + ". And it matches");
								Log.info("");}
							else{
								System.out.println("Department Code Value is: " +tdElement.getText() + ", Expected Department Code Value is: " + testData.get("DepartmentCode") + ". And it does not matches");
								Log.info("");}

						}
					}
					col_num++;
					break;
				case "Reason Remarks":
					if (!testData.get("ReasonRemarks").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("ReasonRemarks"))){
								System.out.println("Reason Remarks is: " +tdElement.getText() + ", Expected Reason Remarks is: " + testData.get("ReasonRemarks") + ". And it matches");
								Log.info("");}
							else{
								System.out.println("Reason Remarks is: " +tdElement.getText() + ", Expected Reason Remarks is: " + testData.get("DepartmentCode") + ". And it does not matches");
								Log.info("");}
						}
					}
					col_num++;
					break;
				case "Action":
					if (!testData.get("RiskAction").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							if(tdElement.getText().equalsIgnoreCase(testData.get("RiskAction"))){
								System.out.println("Risk Action is: " +tdElement.getText() + ", Expected Risk Action is: " + testData.get("RiskAction") + ". And it matches");
								Log.info("");}
							else{
								System.out.println("Risk Action is: " +tdElement.getText() + ", Expected Risk Action is: " + testData.get("RiskAction") + ". And it does not matches");
								Log.info("");}
						}
					}
					col_num++;
					break;

				default:
					col_num++;
					break;
				}		
			}
		}
	} 

	public void employmentAndWealthTab()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_AND_WEALTH).click();
		Log.info("User ia able to clicked on Employment And Wealth Tab Sucessfully for Verification");
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_TOTOL_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.xpath("//*[@id='tab-content-4']//form/div[1]//table[1]//tbody/tr["+row_num+"]/td//input[1]")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("(((//*[@id='tab-content-4']/div//div[1]//md-card-content/table[1])[1]//tr)[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Work Type *":
					if (!testData.get("WorkType").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							if(driver.findElement(By.xpath("//*[@id='tab-content-4']//form/div[1]//table[1]//tbody/tr["+row_num+"]/td//input[2]")).getAttribute("value").equalsIgnoreCase(testData.get("WorkType"))){
								System.out.println("Work Type Value is: " +tdElement.getAttribute("value") + ", Expected Work Type Value is: " + testData.get("WorkType") + ". And it matches");
								Log.info("Work Type Value is: " +tdElement.getAttribute("value") + ", Expected Work Type Value is: " + testData.get("WorkType") + ". And it matches");}
						}				  
					}
					col_num++;
					break;

				case "Occupation *":
					if (!testData.get("Occupation").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							if(tdElement.getAttribute("value").equalsIgnoreCase(testData.get("Occupation"))){
								System.out.println("Occupation Value is: " +tdElement.getAttribute("value") + ", Expected Occupation is: " + testData.get("Occupation") + ". And it matches");
								Log.info("Occupation Value is: " +tdElement.getAttribute("value") + ", Expected Occupation is: " + testData.get("Occupation") + ". And it matches");}
						}	  
					}
					col_num++;
					break;
				case "ISIC *":
					if (!testData.get("ISIC").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							if(tdElement.getAttribute("value").equalsIgnoreCase(testData.get("ISIC"))){
								System.out.println("ISIC Number is: " +tdElement.getAttribute("value") + ", Expected ISIC Number is: " + testData.get("ISIC") + ". And it matches");
								Log.info("ISIC Number is: " +tdElement.getAttribute("value") + ", Expected ISIC Number is: " + testData.get("ISIC") + ". And it matches");}
						}  
					}
					col_num++;
					break;
				case "Staff Category":
					if (!testData.get("StaffCategory").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							if(tdElement.getAttribute("value").equalsIgnoreCase(testData.get("StaffCategory"))){
								System.out.println("Staff Category Value is: " +tdElement.getAttribute("value") + ", Expected Staff Category Value is: " + testData.get("StaffCategory") + ". And it matches");
								Log.info("Staff Category Value is: " +tdElement.getAttribute("value") + ", Expected Staff Category Value is: " + testData.get("StaffCategory") + ". And it matches");}
						}
					}
					col_num++;
					break;
				default:
					col_num++;
					break;
				}		
			}
			if(row_num<=tr_collection.size())
				row_num++;

		}


/*
		List<WebElement> tr_collection_name = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_NAME_TOTOL_ROWS);
		int row_num1=1,col_num1=1;
		for (WebElement trElement1 : tr_collection_name) 
		{
			List<WebElement> td_collection_name = trElement1.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_NAME_TOTOL_COLUMN); 
			int n = td_collection_name.size();
			col_num1=1;
			for (WebElement tdElement1  :td_collection_name)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-4']//div[1]/md-content/md-card//table[2]//tr)[1]/th)["+col_num1+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Employer Name":
					if (!testData.get("EmployerName").trim().isEmpty()) {
						if (tdElement1.getText().trim() != null) {
							if(tdElement1.getText().equalsIgnoreCase(testData.get("EmployerName"))){
								System.out.println("Employer Name is: " +tdElement1.getText() + ", Expected Employer Name is: " + testData.get("EmployerName") + ". And it matches");
							}
						}				  
					}
					col_num1++;
					break;
				default:
					col_num1++;
					break;
				}
			}

		}*/

		/*List<WebElement> tr_collection_income = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_INCOME_TOTAL_ROWS);
		int row_num2=1,col_num2=1;
		for (WebElement trElement2 : tr_collection_income) 
		{
			List<WebElement> td_collection_income = trElement2.findElements(By.tagName("td")); 
			int n = td_collection_income.size();
			col_num2=1;
			for (WebElement tdElement2  :td_collection_income)
			{
				String ExpectedValue = driver.findElement(By.xpath("(//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tr/th)["+col_num2+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Type Of Income":
					if (!testData.get("TypeOfIncome").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("TypeOfIncome"))){
								System.out.println("Type Of Income is: " +tdElement2.getText() + ", Expected Type Of Income is: " + testData.get("TypeOfIncome") + ". And it matches");
							}
						}				  
					}
					col_num2++;
					break;
				case "Currency of Income":
					if (!testData.get("CurrencyofIncome").trim().isEmpty()) {
						if (driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").trim() != null) {
							if(driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").equalsIgnoreCase(testData.get("CurrencyofIncome"))){
								System.out.println("Currency of Income is: " +driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value") + ", Expected Currency of Income is: " + testData.get("CurrencyofIncome") + ". And it matches");
							}
						}				  
					}
					col_num2++;
					break;
				case "Income Amount":
					if (!testData.get("IncomeAmount").trim().isEmpty()) {
						if (driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").trim() != null) {
							if(driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").equalsIgnoreCase(testData.get("IncomeAmount"))){
								System.out.println("Income Amount is: " +driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value") + ", Expected Income Amount is: " + testData.get("IncomeAmount") + ". And it matches");
							}
						}				  
					}
					col_num2++;
					break;
				case "Income LastUpdateDate":
					if (!testData.get("IncomeLastUpdateDate").trim().isEmpty()) {
						if (driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").trim() != null) {
							if(driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value").equalsIgnoreCase(testData.get("IncomeLastUpdateDate"))){
								System.out.println("Income Last Update Date is: " +driver.findElement(By.xpath("//*[@id='tab-content-4']//div[2]/md-content//md-card-content/table//tbody/tr["+row_num2+"]/td//input")).getAttribute("value") + ", Expected Income Last Update Date is: " + testData.get("TypeOfIncome") + ". And it matches");
							}
						}				  
					}
					col_num2++;
					break;
				default:
					col_num2++;
					break;
				}
			}
			if(row_num2<=tr_collection_income.size())
				row_num2++;

		}
		List<WebElement> tr_collection_wealth = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_WEALTH_TOTAL_ROWS);
		int row_num3=1,col_num3=1;
		for (WebElement trElement2 : tr_collection_wealth) 
		{
			List<WebElement> td_collection_income = trElement2.findElements(By.tagName("td")); 
			int n = td_collection_income.size();
			col_num3=1;
			for (WebElement tdElement2  :td_collection_income)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-4']/div//div[3]/md-content/md-card//table[1]//tr)[1]/th)["+col_num3+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Wealth investment Classification(PI/AI profile)":
					if (!testData.get("WealthinvestmentClassification").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("WealthinvestmentClassification"))){
								System.out.println("Wealth investment Classification is: " +tdElement2.getText() + ", Expected Wealth investment Classification is: " + testData.get("WealthinvestmentClassification") + ". And it matches");
							}
						}				  
					}
					col_num3++;
					break;
				case "Wealth investment classification expiry date":
					if (!testData.get("Wealthinvestmentclassificationexpirydate").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("Wealthinvestmentclassificationexpirydate"))){
								System.out.println("Wealth investment classification expiry date is: " +tdElement2.getText() + ", Expected Wealth investment classification expiry date is: " + testData.get("Wealthinvestmentclassificationexpirydate") + ". And it matches");
							}
						}				  
					}
					col_num3++;
					break;
				case "Client Investment Profile Status":
					if (!testData.get("ClientInvestmentProfileStatus").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("ClientInvestmentProfileStatus"))){
								System.out.println("Client Investment Profile Status is: " +tdElement2.getText() + ", Expected Client Investment Profile Status is: " + testData.get("ClientInvestmentProfileStatus") + ". And it matches");
							}
						}				  
					}
					col_num3++;
					break;
				case "Client Investment Profile Verified":

					if(!testData.get("ClientInvestmentProfileVerified").trim().isEmpty())
					{
						List<WebElement> ClientInvestmentProfileVerifiedButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_CLIENT_INVESMENT_RADIO_BUTTON);
						for(i=1;i<=ClientInvestmentProfileVerifiedButton.size();i++)
						{
							String str = driver.findElement(By.xpath("(//*[@id='tab-content-4']/div/md-content/div/form/div[3]//table[1]/tbody/tr/td[4]/font/md-input-container/md-radio-group//md-radio-button)"+"["+i+"]"))
									.getAttribute("aria-checked");
							if (str.equals("true")&&(testData.get("ClientInvestmentProfileVerified").equalsIgnoreCase("Yes"))){
								System.out.println("Client Investment Profile Verified is Yes");}
							else if (str.equals("true")&&(testData.get("ClientInvestmentProfileVerified").equalsIgnoreCase("No"))){
								System.out.println("Client Investment Profile Verified is No");}
						}
					}
					col_num3++;
					break;
				default:
					col_num3++;
					break;

				}
			}

		}
		List<WebElement> tr_collection_wealth1= driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_WEALTH_TOTAL_ROWS1);
		int row_num4=1,col_num4=1;
		for (WebElement trElement2 : tr_collection_wealth1) 
		{
			List<WebElement> td_collection_income = trElement2.findElements(By.xpath("//*[@id='tab-content-4']/div/md-content//div[3]//md-card-content/table[2]/tbody/tr/td//md-input-container")); 
			int n = td_collection_income.size();
			col_num3=1;
			for (WebElement tdElement2  :td_collection_income)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-4']/div/md-content//div[3]//md-card-content/table[2]//tr)[1]/th)["+col_num4+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Client Investment Profile Effective date":
					if (!testData.get("ClientInvestmentProfileEffectivedate").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("ClientInvestmentProfileEffectivedate"))){
								System.out.println("Client Investment Profile Effective date is: " +tdElement2.getText() + ", Expected Client Investment Profile Effective date is: " + testData.get("ClientInvestmentProfileEffectivedate") + ". And it matches");
							}
						}				  
					}
					col_num4++;
					break;
				case "Client Profile Expiry Date":
					if (!testData.get("ClientProfileExpiryDate").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("ClientProfileExpiryDate"))){
								System.out.println("Client Profile Expiry Date is: " +tdElement2.getText() + ", Expected Client Profile Expiry Date is: " + testData.get("ClientProfileExpiryDate") + ". And it matches");
							}
						}				  
					}
					col_num4++;
					break;
				case "Client Investment Profile Rating":
					if (!testData.get("ClientInvestmentProfileRating").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("ClientInvestmentProfileRating"))){
								System.out.println("Client Investment Profile Rating is: " +tdElement2.getText() + ", Expected Client Investment Profile Rating is: " + testData.get("ClientInvestmentProfileRating") + ". And it matches");
							}
						}				  
					}
					col_num4++;
					break;
				case "Overseas Investor":
					if(!testData.get("OverseasInvestor").trim().isEmpty())
					{
						List<WebElement> OverseasInvestorButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLYMENT_CLIENT_OVERSEAS_RADIO_BUTTON);
						for(i=1;i<=OverseasInvestorButton.size();i++)
						{
							String str = driver.findElement(By.xpath("(//*[@id='tab-content-4']/div/md-content/div/form/div[3]//table[2]/tbody/tr/td[4]/font/md-input-container/md-radio-group//md-radio-button)"+"["+i+"]"))
									.getAttribute("aria-checked");
							if (str.equals("true")&&(testData.get("OverseasInvestor").equalsIgnoreCase("Yes"))){
								System.out.println("Overseas Investor is Yes");}
							else if (str.equals("true")&&(testData.get("OverseasInvestor").equalsIgnoreCase("No"))){
								System.out.println("Overseas Investor is No");}
						}
					}
					col_num4++;
					break;
				default:
					col_num4++;
					break;

				}
			}

		}  

		List<WebElement> tr_collection_wealth2= driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_WEALTH_TOTAL_ROWS1);
		int row_num5=1,col_num5=1;
		for (WebElement trElement2 : tr_collection_wealth2) 
		{
			List<WebElement> td_collection_income = trElement2.findElements(By.tagName("td")); 
			int n = td_collection_income.size();
			col_num5=1;
			for (WebElement tdElement2  :td_collection_income)
			{
				String ExpectedValue = driver.findElement(By.xpath("(//*[@id='tab-content-4']/div/md-content//div[3]//md-card-content/table[2]/tbody/tr/td//md-input-container/input)["+col_num4+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Asset Under Management":
					if (!testData.get("AssetUnderManagement").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("AssetUnderManagement"))){
								System.out.println("Asset Under Management is: " +tdElement2.getText() + ", Expected Asset Under Management is: " + testData.get("AssetUnderManagement") + ". And it matches");
							}
						}				  
					}
					col_num5++;
					break;
				case "Asset Under Management Currency":
					if (!testData.get("AssetUnderManagementCurrency").trim().isEmpty()) {
						if (tdElement2.getText().trim() != null) {
							if(tdElement2.getText().equalsIgnoreCase(testData.get("AssetUnderManagementCurrency"))){
								System.out.println("Asset Under Management Currency is: " +tdElement2.getText() + ", Expected Asset Under Management Currency is: " + testData.get("AssetUnderManagementCurrency") + ". And it matches");
							}
						}				  
					}
					col_num5++;
					break;
				default:
					col_num5++;
					break;

				}
			}

		}  

		List<WebElement> tr_collection_Vulnerable_Customer= driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_VULNERABLE_CUSTOMER_ROWS);
		int row_num6=1,col_num6=1;
		for (WebElement trElement2 : tr_collection_Vulnerable_Customer) 
		{
			List<WebElement> td_collection_income = trElement2.findElements(By.tagName("td")); 
			int n = td_collection_income.size();
			col_num6=1;
			for (WebElement tdElement2  :td_collection_income)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-4']/div/md-content/div/form/div[3]/md-content/md-card/md-card-content/table[3]//tr)[1]/th)["+col_num6+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Vulnerable Customer":
					if(!testData.get("VulnerableCustomer").trim().isEmpty())
					{
						List<WebElement> OverseasInvestorButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYEMNT_VULNERABLECUSTOMER);
						for(i=1;i<=OverseasInvestorButton.size();i++)
						{
							String str = driver.findElement(By.xpath("(//*[@id='tab-content-4']/div/md-content/div/form/div[3]/md-content/md-card/md-card-content/table[3]//tbody//md-radio-button)"+"["+i+"]"))
									.getAttribute("aria-checked");
							if (str.equals("true")&&(testData.get("VulnerableCustomer").equalsIgnoreCase("Yes"))){
								System.out.println("Vulnerable Customer is Yes");}
							else if (str.equals("true")&&(testData.get("VulnerableCustomer").equalsIgnoreCase("No"))){
								System.out.println("Vulnerable Customer is No");}
						}
					}
					col_num6++;
					break; 

				default:
					col_num6++;
					break;

				}}
		}*/
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);	 
		   Log.info("User is able to Logged Out Sucessfully");
	}

	
	public void additionalDetails(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ADDITIONAL_DETAILS);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		
		if(!testData.get("Asia Miles Membership No").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ASIA_MILES_MEMBERSHIP_NUMBER).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("Asia Miles Membership No is Validated");}
			Log.info("");}
		
		if(!testData.get("Bankruptcy Court Order No").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_COURT_ORDER_NUMBER).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("Bankruptcy Court Order No is Validated");}
			Log.info("");}
		
		if(!testData.get("Bankruptcy Court Order date").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_COURT_ORDER_DATE).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("Bankruptcy Court Order date is Validated");}
			Log.info("");}
		
		if(!testData.get("Bankruptcy Expiry date").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_EXPIRY_DATE).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("Bankruptcy Expiry date is Validated");}
			Log.info("");}
		
		if(!testData.get("Bankruptcy Petition Filed date").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_PETITION_FILED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("Bankruptcy Petition Filed date is Validated");}
			Log.info("");}
		
		if(!testData.get("International Mobile Preference flag").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.INTERNATIONAL_MOBILE_PREF_FLAG).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("International Mobile Preference flag is Validated");}
			Log.info("");}
		

		if(!testData.get("SMS_NOTIFY_HIGH_RISK_TELLER_FLAG").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SMS_NOTIFY_HIGH_RISK_TELLER_FLAG).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("SMS_NOTIFY_HIGH_RISK_TELLER_FLAG is Validated");}
			Log.info("");}
	}
	
	
	public void multilingual() throws InterruptedException{
		actionClick(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL);sleep(minWaitVal);
		//actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		if(!testData.get("LANGUAGE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.LANGUAGE).getAttribute("value").equalsIgnoreCase(testData.get("LANGUAGE"))){
				System.out.println("LANGUAGE is Validated");}
			Log.info("");}
		
		if(!testData.get("FULLNAME").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.FULLNAME).getAttribute("value").equalsIgnoreCase(testData.get("FULLNAME"))){
				System.out.println("FULLNAME is Validated");}
			Log.info("");}
		
		if(!testData.get("MAILING_TITLE_1").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.LANGUAGE).getAttribute("value").equalsIgnoreCase(testData.get("MAILING_TITLE_1"))){
				System.out.println("MAILING_TITLE_1 is Validated");}
			Log.info("");}
		
		if(!testData.get("MAILING_TITLE_2").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MAILING_TITLE_2).getAttribute("value").equalsIgnoreCase(testData.get("MAILING_TITLE_2"))){
				System.out.println("MAILING_TITLE_2 is Validated");}
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_TYPE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_TYPE).getAttribute("value").equalsIgnoreCase(testData.get("MULTILINGUAL_TYPE"))){
				System.out.println("MULTILINGUAL_TYPE is Validated");}
			Log.info("");}

		
		if(!testData.get("MULTILINGUAL_ADD1").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD1).getAttribute("value").equalsIgnoreCase(testData.get("MULTILINGUAL_ADD1"))){
				System.out.println("MULTILINGUAL_ADD1 is Validated");}
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_ADD2").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD2).getAttribute("value").equalsIgnoreCase(testData.get("MULTILINGUAL_ADD2"))){
				System.out.println("MULTILINGUAL_ADD2 is Validated");}
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_ADD3").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD3).getAttribute("value").equalsIgnoreCase(testData.get("MULTILINGUAL_ADD3"))){
				System.out.println("MULTILINGUAL_ADD3 is Validated");}
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_CITY").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_CITY).getAttribute("value").equalsIgnoreCase(testData.get("MULTILINGUAL_CITY"))){
				System.out.println("MULTILINGUAL_CITY is Validated");}
			Log.info("");}
	}
	
	
	public void customerChoice(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.CUSTOMER_CHOICE);sleep(minWaitVal);
		if(!testData.get("EMAIL_CUST_CHOICE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMAIL_CUST_CHOICE).getAttribute("value").equalsIgnoreCase(testData.get("EMAIL_CUST_CHOICE"))){
				System.out.println("EMAIL_CUST_CHOICE is Validated");}
			Log.info("");}
		
		
		if(!testData.get("EMAIL_LAST_UPDATED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMAIL_LAST_UPDATED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("EMAIL_LAST_UPDATED_DATE"))){
				System.out.println("EMAIL_LAST_UPDATED_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("EMAIL_EFFECTIVE_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMAIL_EFFECTIVE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("EMAIL_EFFECTIVE_DATE"))){
				System.out.println("EMAIL_EFFECTIVE_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("MOBILE_CUST_CHOICE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MOBILE_CUST_CHOICE).getAttribute("value").equalsIgnoreCase(testData.get("MOBILE_CUST_CHOICE"))){
				System.out.println("MOBILE_CUST_CHOICE is Validated");}
			Log.info("");}
		
		if(!testData.get("MOBILE_LAST_UPDATED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MOBILE_LAST_UPDATED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("MOBILE_LAST_UPDATED_DATE"))){
				System.out.println("MOBILE_LAST_UPDATED_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("MOBILE_EFFECTIVE_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MOBILE_EFFECTIVE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("MOBILE_EFFECTIVE_DATE"))){
				System.out.println("MOBILE_EFFECTIVE_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("POST_CUST_CHOICE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.POST_CUST_CHOICE).getAttribute("value").equalsIgnoreCase(testData.get("POST_CUST_CHOICE"))){
				System.out.println("POST_CUST_CHOICE is Validated");}
			Log.info("");}
		
		if(!testData.get("POST_LAST_UPDATED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.POST_LAST_UPDATED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("POST_LAST_UPDATED_DATE"))){
				System.out.println("POST_LAST_UPDATED_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("POST_EFFECTIVE_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.POST_EFFECTIVE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("POST_EFFECTIVE_DATE"))){
				System.out.println("POST_EFFECTIVE_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("PHONE_CUST_CHOICE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PHONE_CUST_CHOICE).getAttribute("value").equalsIgnoreCase(testData.get("PHONE_CUST_CHOICE"))){
				System.out.println("PHONE_CUST_CHOICE is Validated");}
			Log.info("");}
		
		if(!testData.get("PHONE_LAST_UPDATED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PHONE_LAST_UPDATED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("PHONE_LAST_UPDATED_DATE"))){
				System.out.println("PHONE_LAST_UPDATED_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("PHONE_EFFECTIVE_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PHONE_EFFECTIVE_DATE).getAttribute("value").equalsIgnoreCase(testData.get("PHONE_EFFECTIVE_DATE"))){
				System.out.println("PHONE_EFFECTIVE_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("CUST_CHOICE_LAST_REQUESTED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CUST_CHOICE_LAST_REQUESTED_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CUST_CHOICE_LAST_REQUESTED_DATE"))){
				System.out.println("CUST_CHOICE_LAST_REQUESTED_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("STAFF_ON_PHONE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.STAFF_ON_PHONE).getAttribute("value").equalsIgnoreCase(testData.get("STAFF_ON_PHONE"))){
				System.out.println("STAFF_ON_PHONE is Validated");}
			Log.info("");}
		
		if(!testData.get("PHONE_NUM_USED").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PHONE_NUM_USED).getAttribute("value").equalsIgnoreCase(testData.get("PHONE_NUM_USED"))){
				System.out.println("PHONE_NUM_USED is Validated");}
			Log.info("");}
		
		if(!testData.get("REQUEST_OVER_PHONE").trim().isEmpty()){
			for(int i=1; i<3; i++){
				String str = driver.findElement(By.xpath("(//*[@id='CustomerChoice']//div[2]/div[2]/div[1]//md-input-container/md-radio-group//md-radio-button)"+"["+i+"]"))
						.getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("REQUEST_OVER_PHONE").equalsIgnoreCase("Yes"))){
					System.out.println("REQUEST_OVER_PHONE is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("REQUEST_OVER_PHONE").equalsIgnoreCase("No"))){
						System.out.println("REQUEST_OVER_PHONE is No");
						Log.info("");}
				}
			}
		
		if(!testData.get("CONVERSATION_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONVERSATION_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CONVERSATION_DATE"))){
				System.out.println("CONVERSATION_DATE is Validated");}
			Log.info("");}
		
		if(!testData.get("CONVERSATION_TIME").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONVERSATION_TIME).getAttribute("value").equalsIgnoreCase(testData.get("CONVERSATION_TIME"))){
				System.out.println("CONVERSATION_TIME is Validated");}
			Log.info("");}
	}


	public void crossReference() {
		actionClick(ICM_UpdateCustomerProfilePage_Obj.CROSS_REFERENCE);sleep(minWaitVal);
		//actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CROSS_REFERENCE_PRODUCT_ROW);
		int rowNum = 0;
		for (int i=1; i<=tr_collection.size(); i++){
			//to click more details
			driver.findElement(By.xpath("//*[@id='tab-content-10']/div/md-content/div/form//div/table/tbody/tr["+i+"]/td[12]/a")).click();sleep(5000);
		
			if(!testData.get("CR_ACCOUNT_NUMBER").trim().isEmpty()){
				String[] expectedVal= testData.get("CR_ACCOUNT_NUMBER").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CR_ACCOUNT_NUMBER).getAttribute("value"), expectedVal, "CR_ACCOUNT_NUMBER");
				Log.info("");}
			
			
			if(!testData.get("PRODUCT_NAME").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT_NAME").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT_NAME).getAttribute("value"), expectedVal, "PRODUCT_NAME");
				Log.info("");}
			
			if(!testData.get("ACCOUNT_CURRENCY").trim().isEmpty()){
				String[] expectedVal= testData.get("ACCOUNT_CURRENCY").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ACCOUNT_CURRENCY).getAttribute("value"), expectedVal, "ACCOUNT_CURRENCY");
				Log.info("");}
			
			if(!testData.get("ICM_PRODUCT_STATUS").trim().isEmpty()){
				String[] expectedVal= testData.get("ICM_PRODUCT_STATUS").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ICM_PRODUCT_STATUS).getAttribute("value"), expectedVal, "ICM_PRODUCT_STATUS");
				Log.info("");}
			
			if(!testData.get("PRODUCT").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT).getAttribute("value"), expectedVal, "PRODUCT");
				Log.info("");}
			
			if(!testData.get("SUB_PRODUCT").trim().isEmpty()){
				String[] expectedVal= testData.get("SUB_PRODUCT").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SUB_PRODUCT).getAttribute("value"), expectedVal, "SUB_PRODUCT");
				Log.info("");}
			
			if(!testData.get("PRODUCT_SEQUENCE_NUMBER").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT_SEQUENCE_NUMBER").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT_SEQUENCE_NUMBER).getAttribute("value"), expectedVal, "PRODUCT_SEQUENCE_NUMBER");
				Log.info("");}
			
			if(!testData.get("CONSOLIDATED_FLAG").trim().isEmpty()){
				String[] expectedVal= testData.get("CONSOLIDATED_FLAG").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONSOLIDATED_FLAG).getAttribute("value"), expectedVal, "CONSOLIDATED_FLAG");
				Log.info("");}
			
			if(!testData.get("TP_STATUS").trim().isEmpty()){
				String[] expectedVal= testData.get("TP_STATUS").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.TP_STATUS).getAttribute("value"), expectedVal, "TP_STATUS");
				Log.info("");}
			
			if(!testData.get("RELATIONSHIP_NUMBER").trim().isEmpty()){
				String[] expectedVal= testData.get("RELATIONSHIP_NUMBER").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RELATIONSHIP_NUMBER).getAttribute("value"), expectedVal, "RELATIONSHIP_NUMBER");
				Log.info("");}
			
			if(!testData.get("TP_STATUS_DESCRIPTION").trim().isEmpty()){
				String[] expectedVal= testData.get("TP_STATUS_DESCRIPTION").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.TP_STATUS_DESC).getAttribute("value"), expectedVal, "TP_STATUS_DESCRIPTION");
				Log.info("");}
			
			if(!testData.get("NAME_OF_THE_SYSTEM").trim().isEmpty()){
				String[] expectedVal= testData.get("NAME_OF_THE_SYSTEM").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.NAME_OF_THE_SYSTEM).getAttribute("value"), expectedVal, "NAME_OF_THE_SYSTEM");
				Log.info("");}
			
			if(!testData.get("MAILING_ADDRESS").trim().isEmpty()){
				String[] expectedVal= testData.get("MAILING_ADDRESS").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.MAILING_ADDRESS).getAttribute("value"), expectedVal, "MAILING_ADDRESS");
				Log.info("");}
			
			if(!testData.get("CONTACT_TYPE").trim().isEmpty()){
				String[] expectedVal= testData.get("CONTACT_TYPE").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TYPE).getAttribute("value"), expectedVal, "CONTACT_TYPE");
				Log.info("");}
			
			if(!testData.get("ADDRESS_DETAILS").trim().isEmpty()){
				String[] expectedVal= testData.get("ADDRESS_DETAILS").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_DETAILS).getAttribute("value"), expectedVal, "ADDRESS_DETAILS");
				Log.info("");}
			
			if(!testData.get("PRODUCT_INDICATOR").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT_INDICATOR").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT_INDICATOR).getAttribute("value"), expectedVal, "PRODUCT_INDICATOR");
				Log.info("");}
			
			if(!testData.get("PRODUCT_DESCRIPTION").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT_DESCRIPTION").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT_DESCRIPTION).getAttribute("value"), expectedVal, "PRODUCT_DESCRIPTION");
				Log.info("");}
			
			if(!testData.get("OPERATING_INSTRUCTION").trim().isEmpty()){
				String[] expectedVal= testData.get("OPERATING_INSTRUCTION").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.OPERATING_INSTRUCTION).getAttribute("value"), expectedVal, "OPERATING_INSTRUCTION");
				Log.info("");}
			
			if(!testData.get("PROFILE_ROLE").trim().isEmpty()){
				String[] expectedVal= testData.get("PROFILE_ROLE").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ROLE).getAttribute("value"), expectedVal, "PROFILE_ROLE");
				Log.info("");}
			
			if(!testData.get("EMBOSSED_NAME").trim().isEmpty()){
				String[] expectedVal= testData.get("EMBOSSED_NAME").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMBOSSED_NAME).getAttribute("value"), expectedVal, "EMBOSSED_NAME");
				Log.info("");}
			
			if(!testData.get("PRODUCT_OPEN_DATE").trim().isEmpty()){
				String[] expectedVal= testData.get("PRODUCT_OPEN_DATE").split("\\|");
				compareVal(rowNum, driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PRODUCT_OPEN_DATE).getText(), expectedVal, "PRODUCT_OPEN_DATE");
				Log.info("");}
			
			actionClick(ICM_UpdateCustomerProfilePage_Obj.CR_OK_BUTTON);
			rowNum++;
		}
	}
	
	public void internal(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.INTERNAL);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		if(!testData.get("SEGMENTCODE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SEGMENTCODE).getAttribute("value").equalsIgnoreCase(testData.get("SEGMENTCODE"))){
				System.out.println(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SEGMENTCODE).getAttribute("value"));
				System.out.println("SEGMENTCODE is Validated");
				Log.info("");}
			}
		
		if(!testData.get("ARMCODE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ARMCODE).getAttribute("value").equalsIgnoreCase(testData.get("ARMCODE"))){
				System.out.println("ARMCODE is Validated");
				Log.info("");}
			}
		
		if(!testData.get("SUBSEGMENTCODE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SUBSEGMENTCODE).getAttribute("value").equalsIgnoreCase(testData.get("SUBSEGMENTCODE"))){
				System.out.println("SUBSEGMENTCODE is Validated");
				Log.info("");}
			}
		
		if(!testData.get("SERVICEINDICATORCODE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SERVICEINDICATORCODE).getAttribute("value").equalsIgnoreCase(testData.get("SERVICEINDICATORCODE"))){
				System.out.println("SERVICEINDICATORCODE is Validated");
				Log.info("");}
			}
		
		if(!testData.get("SMSBANKINGINDICATOR").trim().isEmpty()){
			for(int i=1; i<3; i++){
				String str = driver.findElement(By.xpath("(//*[@name='smsBankingIndicator']//md-radio-button)"+"["+i+"]"))
						.getAttribute("aria-checked");
				if (str.equals("true")&&(testData.get("SMSBANKINGINDICATOR").equalsIgnoreCase("Yes"))){
					System.out.println("SMSBANKINGINDICATOR is Yes");
					Log.info("");
				}else if (str.equals("true")&&(testData.get("SMSBANKINGINDICATOR").equalsIgnoreCase("No"))){
						System.out.println("SMSBANKINGINDICATOR is No");
						Log.info("");}
				}
			}
		
		
		if(!testData.get("IBANKINGINDICATOR").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.IBANKINGINDICATOR).getAttribute("class").equals("ng-pristine ng-untouched ng-valid md-input ng-not-empty")
					&&(testData.get("IBANKINGINDICATOR").equalsIgnoreCase("Yes"))){
				System.out.println("IBANKINGINDICATOR is Checked");
				Log.info("");}
				else{
					System.out.println("IBANKINGINDICATOR is Not Checked");
					Log.info("");}
			}
		
		if(!testData.get("PHONEBANKINGINDICATOR").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PHONEBANKINGINDICATOR).getAttribute("class").equals("ng-pristine ng-untouched ng-valid md-input ng-not-empty")
					&&(testData.get("PHONEBANKINGINDICATOR").equalsIgnoreCase("Yes"))){
				System.out.println("PHONEBANKINGINDICATOR is Checked");
				Log.info("");}
				else{
					System.out.println("IBANKINGINDICATOR is Not Checked");
					Log.info("");}
			}
		
		
		if(!testData.get("REFERRALID").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.REFERRALID).getAttribute("value").equalsIgnoreCase(testData.get("REFERRALID"))){
				System.out.println("REFERRALID is Validated");
				Log.info("");}
			}
		
		if(!testData.get("SOURCINGID").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SOURCINGID).getAttribute("value").equalsIgnoreCase(testData.get("SOURCINGID"))){
				System.out.println("SOURCINGID is Validated");
				Log.info("");}
			}
		
		if(!testData.get("CLOSINGID").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CLOSINGID).getAttribute("value").equalsIgnoreCase(testData.get("CLOSINGID"))){
				System.out.println("CLOSINGID is Validated");
				Log.info("");}
			}
		
		if(!testData.get("HOMEBRANCH").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.HOMEBRANCH).getAttribute("value").equalsIgnoreCase(testData.get("HOMEBRANCH"))){
				System.out.println("HOMEBRANCH is Validated");
				Log.info("");}
			}
		
		if(!testData.get("RELATIONSHIP_ACTIVATED_DATE").trim().isEmpty()){
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RELATIONSHIP_ACTIVATED_DATE).getAttribute("value").contains(testData.get("RELATIONSHIP_ACTIVATED_DATE"))){
				System.out.println("RELATIONSHIP_ACTIVATED_DATE is Validated");
				Log.info("");}
			}
		
		MISVal();
		referRelationship();
		linkRelationship();
		bankDetails();
		}
	
	public void MISVal(){
        List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.MISROW);
        int colNum=1; int rowNum=1;
		for (WebElement trElement : tr_collection){
			List<WebElement> td_collection = trElement.findElements(By.tagName("td"));
				for (int i=1; i<=td_collection.size(); i++){
					sleep(minWaitVal);
				String ExpectedValue = driver.findElement(By.xpath("(//form[@name='internalTab']//table)[2]//thead/tr/th["+colNum+"]")).getText().trim();
				System.out.println("Row Name is : "+ExpectedValue);
	              switch (ExpectedValue) {
	              	case "MIS Code":
                      if (!testData.get("MISCode").trim().isEmpty()) {
                    	  	if(driver.findElement(By.xpath("(//form[@name='internalTab']//table)[2]//tbody/tr["+rowNum+"]/td[2]/md-input-container/input"))
                    	  			.getAttribute("value").contains(testData.get("MISCode"))){
                            System.out.println("MISCode is verified");
                            Log.info("");}
                      }                          
                      	colNum++;
                      	break;
	              
	              	case "MIS Value":
	                      if (!testData.get("MISValue").trim().isEmpty()) {
	                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[2]//tbody/tr["+rowNum+"]/td[3]/md-input-container/input"))
	                    			  .getAttribute("value").contains(testData.get("MISValue"))) {
	                                              System.out.println("MIS Value is Verified");
	                                              Log.info("");}
	                               }                          
	                     colNum++;
	                     break;
	                     
	              	case "Seq No":
	              		colNum++;
	              		break;
	              		
	              	case "Action":
                      	colNum++;
                      	break; 	
	                     
	              	default:
	              		colNum++;
	              		break;
	              }
			}
			rowNum++;
		}
	}
	
	public void referRelationship(){
		 List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.REFER_RELATIONSHIP_ROW);
		 int colNum=1; int rowNum=1; 
			for (WebElement trElement : tr_collection){
				List<WebElement> td_collection = trElement.findElements(By.tagName("td"));
				for (int i=1; i<=td_collection.size(); i++){
					sleep(minWaitVal);
					String ExpectedValue = driver.findElement(By.xpath("(//form[@name='internalTab']//table)[3]//thead/tr/th["+colNum+"]")).getText().trim();
					System.out.println("Row Name is : "+ExpectedValue);
		              switch (ExpectedValue) {
		              	case "Referred By Relationship No":
	                      if (!testData.get("REFERRED_RELATIONSHIP_NO").trim().isEmpty()) {
	                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[3]//tbody/tr["+rowNum+"]/td[1]/div/md-input-container/input"))
	                    			  .getAttribute("value").contains(testData.get("REFERRED_RELATIONSHIP_NO"))) {
	                                  System.out.println("REFERRED_RELATIONSHIP_NO Value is Verified");}
	                    	  Log.info("");}                          
	                      	colNum++;
	                      	break;
	                      	
		            	case "Referred By":
		                      if (!testData.get("REFERREDBY").trim().isEmpty()) {
		                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[3]//tbody/tr["+rowNum+"]/td[2]/md-input-container/input"))
		                    			  .getAttribute("value").contains(testData.get("REFERREDBY"))) {
		                                              System.out.println("REFERREDBY Value is Verified");}
		                    	  Log.info(""); }                          
		                      	colNum++;
		                      	break;
		                      	
		            	default:
		              		colNum++;
		              		break;
		              }
				}
				rowNum++;
			}
	}
	
	public void linkRelationship(){
		 List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.LINK_RELATIONSHIP_ROW);
		 int colNum=1; 
			for (WebElement trElement : tr_collection){
				int rowNum=1; 
				List<WebElement> td_collection = trElement.findElements(By.tagName("td"));
				for (int i=1; i<=td_collection.size(); i++){
					sleep(minWaitVal);
					String ExpectedValue = driver.findElement(By.xpath("(//form[@name='internalTab']//table)[4]//thead/tr/th["+colNum+"]")).getText().trim();
					System.out.println("Expected Value: "+ExpectedValue);
		              switch (ExpectedValue) {
		              	case "Link Relationship No":
	                      if (!testData.get("Link Relationship No").trim().isEmpty()) {
	                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[4]//tbody/tr["+rowNum+"]/td[1]/div/md-input-container/input"))
	                    			  .getAttribute("aria-label").contains(testData.get("Link Relationship No"))) {
	                                              System.out.println("Link Relationship No Value is Verified");}
	                    	  Log.info("");}                          
	                      	colNum++;
	                      	break;
	                      	
		            	case "Link Relationship Name":
		                      if (!testData.get("Link Relationship Name").trim().isEmpty()) {
		                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[4]//tbody/tr["+rowNum+"]/td[2]/md-input-container/input"))
		                    			  .getAttribute("aria-label").contains(testData.get("Link Relationship Name"))) {
		                                              System.out.println("Link Relationship Name is Verified");}
		                    	  Log.info("");}                          
		                      	colNum++;
		                      	break;  	
		              
		            	case "Relationship Type Code":
		                      if (!testData.get("Relationship Type Code").trim().isEmpty()) {
		                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[4]//tbody/tr["+rowNum+"]/td[3]/md-input-container/input"))
		                    			  .getAttribute("aria-label").contains(testData.get("Relationship Type Code"))) {
		                                              System.out.println("Relationship Type Code is Verified");}
		                    	  Log.info(""); }                          
		                      	colNum++;
		                      	break;  
		                      	
		            	case "Entity Reference ID":
		                      if (!testData.get("Entity Reference ID").trim().isEmpty()) {
		                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[4]//tbody/tr["+rowNum+"]/td[4]/md-input-container/input"))
		                    			  .getAttribute("aria-label").contains(testData.get("Entity Reference ID"))) {
		                                              System.out.println("Entity Reference ID is Verified");}
		                    	  Log.info(""); }                          
		                      	colNum++;
		                      	break;  
		                      	
		            	case "Action":
		                      	colNum++;
		                      	break;  
		              }
				}
				rowNum++;
			}
	}
	
	public void bankDetails(){
		 List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.BANK_DETAILS_ROW);
		 int colNum=1; int rowNum=1; 
			for (WebElement trElement : tr_collection){
				List<WebElement> td_collection = trElement.findElements(By.tagName("td"));
				for (int i=1; i<=td_collection.size(); i++){
					sleep(minWaitVal);
					String ExpectedValue = driver.findElement(By.xpath("(//form[@name='internalTab']//table)[5]//thead/tr/th["+colNum+"]")).getText().trim();
					System.out.println("Expected Value: " +ExpectedValue);
		              switch (ExpectedValue) {
		              	case "Bank Code":
	                      if (!testData.get("Bank Code").trim().isEmpty()) {
	                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[5]//tbody/tr["+rowNum+"]/td[1]/md-input-container/input"))
	                    			  .getAttribute("aria-label").contains(testData.get("Bank Code"))) {
	                                              System.out.println("Bank Code Value is Verified");}
	                    	  Log.info("");}                          
	                      	colNum++;
	                      	break;
	                      	
		            	case "Bank Products":
		                      if (!testData.get("Bank Products").trim().isEmpty()) {
		                    	  if (driver.findElement(By.xpath("(//form[@name='internalTab']//table)[5]//tbody/tr["+rowNum+"]/td[2]/md-input-container/input"))
		                    			  .getAttribute("aria-label").contains(testData.get("Bank Products"))) {
		                                              System.out.println("Bank Products Value is Verified");}
		                    	  Log.info("");}                          
		                      	colNum++;
		                      	break;  
		                      	
		            	case "Action":
	                      	colNum++;
	                      	break;  
	                      	
		            	default:
		              		colNum++;
		              		break;
		              }
				}
				rowNum++;
			}
		}

	public void Modifylogin() {
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement username = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BANKID);
			username.sendKeys("1");
			username.sendKeys("5");
			username.sendKeys("8");
			username.sendKeys("1");
			username.sendKeys("1");
			username.sendKeys("1");
			username.sendKeys("9");
			username.sendKeys(Keys.ENTER);
			WebElement password = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PASSWORD);
			password.click();
			password.click();sleep(medval);
			password.sendKeys("S");sleep(minval);
			password.sendKeys("c");sleep(minval);
			password.sendKeys("b");sleep(minval);
			password.sendKeys("@");sleep(minval);
			password.sendKeys("1");
			password.sendKeys("2");
			password.sendKeys("3");
			password.sendKeys("4");
			password.sendKeys("5");
		//	password.sendKeys(Keys.ENTER);
			sleep(minWaitVal);
			js.executeScript("arguments[0].click();", driver.findElement(ICM_UpdateCustomerProfilePage_Obj.LOGIN));
			sleep(4000);
			Log.info("User is able to logged In Sucessfully");
		} catch (Exception e) {
			System.out.println("Unable to Login ICM Application" + e.getMessage());
			Log.error("Unable to Login ICM Application" + e.getMessage());
		}
	}

	public void serachForIcmIdModify()
	{
		sleep(mediumWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ICM_EXPAND);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ACTION);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.UPDATE_PROFILE);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ICM_ID);
		inputText(ICM_UpdateCustomerProfilePage_Obj.ICM_ID, testData.get("icmID"));
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ENQUIRY_SUBMIT);sleep(mediumWaitVal);
		sleep(3000);
		driver.findElement(By.xpath("//a[text()='" + testData.get("icmID") + "']")).click();sleep(mediumWaitVal);
	}

	public void Modify_basicInfoTab() throws Exception
	{
   	//sleep(minWaitVal);
		if (!testData.get("Gender").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText().trim() != null) {
				   String genderName=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).click();
				   sleep(minWaitVal);
				   List<WebElement> listOfOptions=driver.findElements(By.xpath("//*[@ng-value='gend.code']/div[1]"));
				   for (WebElement option : listOfOptions) {
					   System.out.println("Gender" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("Gender").trim())) {
						     triggerOnClick(option);
						     System.out.println("Before Modification - Gender" +genderName + ", After Modification - Gender is: "+driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText()+ ". And sucessfully updated" );
						     driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						     Log.info("");
						     sleep(mediumWaitVal);
						     actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
						     Log.info("");
						     break;
					      }
					   }
                  }
		}
			if (!testData.get("DateofBirth").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value").trim() != null) {
				   String dateofBirth=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value");
				   inputText(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH, testData.get("DateofBirth"));
				   if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value").contains(testData.get("DateofBirth"))){
					   System.out.println("Before Modification  - Date Of Birth" +dateofBirth + ", After Modification - Date Of Birth is: "+driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value").trim()+ ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);
						Log.info("");
					     }
				   }
			   }

		 if (!testData.get("MaritalStatus").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getAttribute("value").trim() != null) {
				   String maritalStatus=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getAttribute("value").trim();
				   sleep(minWaitVal);
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).click();
				   List<WebElement> listOfmaritalStatus=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfmaritalStatus) {
					   System.out.println("MaritalStatus" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("MaritalStatus").trim())) {
						     triggerOnClick(option);
						     System.out.println("Before Modification -Marital Status is: " +maritalStatus + ", Expected Marital Status is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_MARITAL_STATUS).getText() + ". And sucessfully updated");
						     Log.info("");
						     driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
							    sleep(mediumWaitVal);
								actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
								Log.info("");
								break;
					   }

				   }
			   }
		   }

		   if (!testData.get("Nationality").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() != null) {
				   String nationality=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).click();
				   sleep(minWaitVal);
				   List<WebElement> listOfOptions=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfOptions) {
					   System.out.println("Nationality" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("Nationality").trim())) {
						     triggerOnClick(option);
					       System.out.println("Before Modification - Nationality is: " +nationality + ", After Modification - Nationality is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() + ". And sucessfully updated");
					       Log.info("");  
					       driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
							    sleep(mediumWaitVal);
								actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
								Log.info("");
								break;
					   }
				   }
			   }
		   }

		   if (!testData.get("EducationalQualification").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value").trim() != null) {
				   String qualification=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value").trim();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).click();
				   List<WebElement> listOfEducationalQualification=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfEducationalQualification) {
					   System.out.println("EducationalQualification" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("EducationalQualification").trim())) {
						     triggerOnClick(option);
					       System.out.println("Before Modification -Educational Qualification is: " +qualification + ", After Modification - Educational Qualification is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_QUALIFICATION).getAttribute("value").trim() + ". And sucessfully updated");
					       Log.info("");
					       driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						   sleep(mediumWaitVal);
						   actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
						   Log.info("");
						   break;
					   }
				   }
			   }
		   }
               if (!testData.get("PreferredStatementLanguage").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value").trim() != null) {
				   String PreferredStatementLanguage=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value").trim();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).click();
				   List<WebElement> listOfPreferredStatementLanguage=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfPreferredStatementLanguage) {
					   System.out.println("PreferredStatementLanguage" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("PreferredStatementLanguage").trim())) {
						     triggerOnClick(option);
					   System.out.println("Before Modification - Preferred Statement Language is: " +PreferredStatementLanguage + ", After Modification - Expected Preferred Statement Language is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PREFERRED_STATEMENT_LANG).getAttribute("value").trim() + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
						Log.info("");
						break;
					   }
				   }
			   }
		   }

		   if (!testData.get("CountryOfBirth").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value").trim() != null) {
				  String CountryOfBirth= driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value").trim();
				  driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).clear();
				  driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).click();
				  List<WebElement> listOfPreferredStatementLanguage=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfPreferredStatementLanguage) {
					   System.out.println("CountryOfBirth" +option.getText());
					   if (option.getText().trim().equalsIgnoreCase(testData.get("CountryOfBirth").trim())) {
						   triggerOnClick(option);
					   System.out.println("Before Modification - Country Of Birth is: " +CountryOfBirth + ", Expected Modification - Country Of Birth is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value").trim() + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
						Log.info("");
						break; 
					   }
				   }
			   }
		   }
		   if (!testData.get("PlaceofBirth").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").trim() != null) {
				   String PlaceofBirth =driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").trim();
				   inputText(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH, testData.get("PlaceofBirth"));
				   if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").equalsIgnoreCase(testData.get("PlaceofBirth"))){
					   System.out.println("Before Modification -Place of Birth is: " +PlaceofBirth + ", After Modification - Place of Birth is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PLACE_OF_BIRTH).getAttribute("value").trim() + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	       
						Log.info("");  
				   }
				   }
			   }
		   
		   if (!testData.get("PreferredLanguageofCommunication").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value").trim() != null) {
				   String PreferredLanguageofCommunication=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value").trim();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).click();
				   List<WebElement> listOfPreferredStatementLanguage=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfPreferredStatementLanguage) {
				   if (option.getText().trim().equalsIgnoreCase(testData.get("PreferredLanguageofCommunication").trim())) {
					   triggerOnClick(option);
					   System.out.println("Before Modification - Preferred Language of Communication is: " +PreferredLanguageofCommunication + ", After Modification - Preferred Language of Communication is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_LANG_PREFERRED_COMMUMNICATION).getAttribute("value").trim() + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
						Log.info("");
						break;
					  
					   }
				   }
			   }
		   }

		  if (!testData.get("NoofDependants").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getAttribute("value").trim() != null) {
				   String NoofDependants=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getAttribute("value").trim();
				   inputText(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT, testData.get("NoofDependants"));
				   if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getAttribute("value").equalsIgnoreCase(testData.get("NoofDependants"))){
					   System.out.println("Before Modification - No of Dependants is: " +NoofDependants + ", After Modification - No of Dependants is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NO_OF_DEPENDANT).getAttribute("value").trim() + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	        
						Log.info("");   
				   }
				   }
			   }

		   if (!testData.get("ProfileType").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText().trim() != null) {
				   String profileType=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText().trim();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).click();
				   sleep(minWaitVal);
				   List<WebElement> listOfOptions=driver.findElements(By.xpath("//*[@class='md-select-menu-container md-active md-clickable']/md-select-menu/md-content/md-option"));
				   for (WebElement option : listOfOptions) {
					   if (option.getText().trim().equalsIgnoreCase(testData.get("ProfileType").trim())) {
						   triggerOnClick(option);
						   System.out.println("Before Modification - PROFILE TYPE is: " +profileType + ", Expected PROFILE TYPE is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_PROFILE_TYPE).getText() + ". And sucessfully updated");
						   Log.info("");
						   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
					   }
				   }
			   }

		   }
		 if (!testData.get("Title").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value").trim() != null) {
				   String title=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value");
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).clear();
				   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).click();
				   sleep(minWaitVal);
				   List<WebElement> listOfOptions=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
				   for (WebElement option : listOfOptions) {
					   if (option.getText().trim().equalsIgnoreCase(testData.get("Title").trim())) {
						   triggerOnClick(option);
						   System.out.println("Before Modification - TITLE is: " +title + ", Expected TITLE is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_TITLE).getAttribute("value") + ". And sucessfully updated");
						   Log.info("");
						   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);sleep(minWaitVal);	
							Log.info("");
							break;
					  
					    }
				   }
			   }
		   }
		   if (!testData.get("FullName").trim().isEmpty()) {
			   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value").trim() != null) {
				   String fullname=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value").trim();
				   inputText(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME, testData.get("FullName"));
				   if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value").contains(testData.get("FullName"))){
					   System.out.println("Before Modification - FULL NAME is: " +fullname + ", Expected FULL NAME is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_FULL_NAME).getAttribute("value") + ". And sucessfully updated");
					   Log.info("");
					   driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					    sleep(mediumWaitVal);
						actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);sleep(minWaitVal);	
						Log.info("");  
				   }
				   }
			   }
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
	}  

	public void modify_address()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_NO_OF_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			String value=driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num+"]/td[1]")).getText();
			boolean alertPresents = false;
			Alert alert = null;
			if(testData.get("AddressType").equalsIgnoreCase(value))  
			{   
				driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num+"]")).click();
				if(!testData.get("Address1").trim().isEmpty()){
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE1).getAttribute("value").trim() != null) {
						String address1=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE1).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE1, testData.get("Address1"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE1).getAttribute("value").contains(testData.get("Address1"))){
							System.out.println("Before Modification - address 1 is: " +address1 + ", After Modification address type is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE1).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info(""); 
							break;
						} 
					}
				}

				if(!testData.get("Address2").trim().isEmpty()){
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE2).getAttribute("value").trim() != null) {
						String address2=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE2).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE2, testData.get("Address2"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE2).getAttribute("value").contains(testData.get("Address2"))){
							System.out.println("Before Modification - address 2 is: " +address2 + ", After Modification address type 2 is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE2).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				} 

				driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num+"]")).click();
				if(!testData.get("Address3").trim().isEmpty()){
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE3).getAttribute("value").trim() != null) {
						String address3=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE3).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE3, testData.get("Address3"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE3).getAttribute("value").contains(testData.get("Address3"))){
							System.out.println("Before Modification - address 3 is: " +address3 + ", After Modification address type is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_ADDRESS_LINE3).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;  
						} 
					} 
				}

				driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num+"]")).click();
				if (!testData.get("City").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_CITY).getAttribute("value").trim() != null) {
						String city=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_CITY).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_CITY, testData.get("City"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_CITY).getAttribute("value").contains(testData.get("City"))){
							System.out.println("Before Modification - City is: " +city + ", After Modification City is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_CITY).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info(""); 
							break;
						} 
					}
				}
				driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num+"]")).click();
				if (!testData.get("State").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_STATE).getAttribute("value").trim() != null) {
						String State=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_STATE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_STATE, testData.get("State"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_STATE).getAttribute("value").contains(testData.get("State"))){
							System.out.println("Before Modification - State is: " +State + ", After Modification State is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_STATE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info(""); 
							break;
						} 
					} 
				}


				if (!testData.get("PostalCode").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_POSTAL_CODE).getAttribute("value").trim() != null) {
						String PostalCode=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_POSTAL_CODE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_POSTAL_CODE, testData.get("PostalCode"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_POSTAL_CODE).getAttribute("value").contains(testData.get("PostalCode"))){
							System.out.println("Before Modification - Postal code is: " +PostalCode + ", After Modification Postal Code is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_POSTAL_CODE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;   
						} 
					} 
				}

				if (!testData.get("Country").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_COUNTRY_CODE).getAttribute("value").trim() != null) {
						String Country=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_COUNTRY_CODE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_COUNTRY_CODE, testData.get("Country"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_COUNTRY_CODE).getAttribute("value").contains(testData.get("Country"))){
							System.out.println("Before Modification - Country code is: " +Country + ", After Modification Country code is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_COUNTRY_CODE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					} 
				}

				if(!testData.get("AddressInvalidIndicatorA").trim().isEmpty()){
					List<WebElement> addressinvalidindicator=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_INVALID_INDICATOR);
					for(i=1;i<=addressinvalidindicator.size();i++)
					{
						String str= driver.findElement(By.xpath("(//*[@name='isWAUFlag']//md-radio-button)["+i+"]")).getAttribute("aria-checked");
						String value2=driver.findElement(By.xpath("(//*[@name='isWAUFlag']//md-radio-button//div[2]/span)["+i+"]")).getText();
						if (str.equals("false")&&(testData.get("AddressInvalidIndicatorA").equalsIgnoreCase(value2))){
							driver.findElement(By.xpath("(//*[@name='isWAUFlag']//md-radio-button//div[1]/div[1])["+i+"]")).click();
							System.out.print("Address Invalid IndicatorA is updated sucessfully");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						}

					}
				}

			}
			if(row_num<=tr_collection.size())
				row_num++;
		}
		actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
		Log.info("");
	}

	public void contact_modify() throws InterruptedException

	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_DETAILS_TABLE_ROW);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			String value=driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]/td[1]")).getText();

			if(testData.get("Classification").equalsIgnoreCase(value))	
			{
				driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]")).click();
				if (!testData.get("MobileNo").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_MOB).getAttribute("value").trim() != null) {
						String mobileno=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_MOB).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.CONTACT_MOB, testData.get("MobileNo"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_MOB).getAttribute("value").contains(testData.get("MobileNo"))){
							System.out.println("Before Modification - Mobile Number is: " +mobileno + ", After Modification Mobile Number is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_MOB).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}

				if (!testData.get("Email").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value").trim() != null) {
						String Email=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL, testData.get("Email"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value").contains(testData.get("Email"))){
							System.out.println("Before Modification - Email is: " +Email + ", After Modification Email is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							Thread.sleep(2000);
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}
				if (!testData.get("Telephone").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TELEPHONE).getAttribute("value").trim() != null) {
						String Telephone=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TELEPHONE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TELEPHONE, testData.get("Telephone"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TELEPHONE).getAttribute("value").contains(testData.get("Telephone"))){
							System.out.println("Before Modification - Email is: " +Telephone + ", After Modification Email is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TELEPHONE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}
				if(!testData.get("PrimaryContact").trim().isEmpty()){
					List<WebElement> primarycontact=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_PRIMARY_CONTACT);
					for(int i=1;i<=primarycontact.size();i++)
					{
						String str= driver.findElement(By.xpath("(//*[@name='primaryContact']/div/md-radio-button)["+i+"]")).getAttribute("aria-checked");
						String value1=driver.findElement(By.xpath("(//*[@name='primaryContact']/div/md-radio-button/div[2]/span)["+i+"]")).getText();
						if (str.equals("false")&&(testData.get("PrimaryContact").equalsIgnoreCase(value1))){
							driver.findElement(By.xpath("(//*[@name='primaryContact']/div/md-radio-button/div[1])["+i+"]")).click();
							System.out.println("GreenCardHolder value is  updated Sucessfully");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						}
					}
				} 

				if(!testData.get("ContactInvalidIndicator").trim().isEmpty()){
					List<WebElement> primarycontact=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_INVALID_INDICATOR);
					for(int i=1;i<=primarycontact.size();i++)
					{
						String str= driver.findElement(By.xpath("(//*[@name='contactInvalid']/div/md-radio-button)["+i+"]")).getAttribute("aria-checked");
						String value2=driver.findElement(By.xpath("(//*[@name='contactInvalid']//md-radio-button//div[2]/span)["+i+"]")).getText();
						if (str.equals("false")&&(testData.get("ContactInvalidIndicator").equalsIgnoreCase(value2))){
							driver.findElement(By.xpath("(//*[@name='contactInvalid']/div/md-radio-button/div[1])["+i+"]")).click();
							System.out.println("Contact Invalid Indicator value is  updated Sucessfully");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						}
					}  
				}
			}
			if(row_num<=tr_collection.size())
				row_num++;
		}
		actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
		Log.info("");
	}		   
	
	public void modify_document()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_TAB).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_DETAILS_ROW);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			if(driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[3]//tbody/tr["+row_num+"]/td[1]")).getText().equalsIgnoreCase(testData.get("DocumentCategory")));	
			{
				driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[3]//tbody/tr["+row_num+"]")).click();
				if (!testData.get("DocumentNumber").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).getAttribute("value").trim() != null) {
						String DocumentNumber=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER, testData.get("DocumentNumber"));
						if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).getAttribute("value").contains(testData.get("DocumentNumber"))){
							System.out.println("Before Modification - Document Number is: " +DocumentNumber + ", After Modification DocumentNumber is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}
				if (!testData.get("ExpiryDate").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_EXPITYDATE).getAttribute("value").trim() != null) {
						String DocumentNumber=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_EXPITYDATE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_EXPITYDATE, testData.get("ExpiryDate"));
						driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).click();
						if(!(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_EXPITYDATE).getAttribute("value").contains(testData.get("ExpiryDate")))){
							System.out.println("Before Modification - DOCUMENT EXPITY DATE is: " +DocumentNumber + ", After Modification DOCUMENT EXPITY DATE is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_EXPITYDATE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}
				if (!testData.get("SignatoryDate").trim().isEmpty()) {
					if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_SIGNATORYDATE).getAttribute("value").trim() != null) {
						String DocumentNumber=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_SIGNATORYDATE).getAttribute("value");
						inputText(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_SIGNATORYDATE, testData.get("SignatoryDate"));
						driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_NUMBER).click();
						if(!(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_SIGNATORYDATE).getAttribute("value").contains(testData.get("SignatoryDate")))){
							System.out.println("Before Modification - DOCUMENT SIGNATORY DATE is: " +DocumentNumber + ", After Modification DOCUMENT SIGNATORY DATE is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.DOCUMENT_SIGNATORYDATE).getAttribute("value") + ". And sucessfully updated");
							Log.info("");
							driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("");
							break;
						} 
					}
				}

			}
			if(row_num<=tr_collection.size())
				row_num++;
		} 
		actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
		Log.info("");
	}

	public void employmentAndWealth_modify() throws Exception
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_AND_WEALTH).click();
		Log.info("User ia able to clicked on Employment And Wealth Tab Sucessfully for modication");
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.EMPLOYMENT_TOTOL_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[1]")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("((//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope']//tr)[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Work Type *":
					if (!testData.get("WorkType").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							String worktype=driver.findElement(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[2]")).getAttribute("value").trim();  
							sleep(minWaitVal);
							driver.findElement(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[2]")).clear();
							driver.findElement(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[2]")).click();
							List<WebElement> listOfmaritalStatus=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
							for (WebElement option : listOfmaritalStatus) {
							System.out.println("WorkType" +option.getText());
							if (option.getText().trim().equalsIgnoreCase(testData.get("WorkType").trim())) {
							    triggerOnClick(option);
								System.out.println("Before Modification -Work Type is: " +worktype + ", Expected Work Type is: " + driver.findElement(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[2]")).getAttribute("value").trim() + ". And sucessfully updated");
							    Log.info("Before Modification -Work Type is: " +worktype + ", Expected Work Type is: " + driver.findElement(By.xpath("(//*[@class='table table-condensed highlight marginBtm10 ng-isolate-scope'])[1]//tbody/tr["+row_num+"]/td//input[2]")).getAttribute("value").trim() + ". And sucessfully updated");
							    driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
							    sleep(mediumWaitVal);
								actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
								Log.info("User is able to Clicked on Approve Button");
								break;
								}	  
							}  
						}
					}		   
					col_num++;
					break;

				case "Occupation *":
					if (!testData.get("Occupation").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {  
							String occupation=tdElement.getAttribute("value");
							sleep(minWaitVal);
							tdElement.clear();
							tdElement.click();
							List<WebElement> listOfmaritalStatus=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
							for (WebElement option : listOfmaritalStatus) {
								if (option.getText().trim().equalsIgnoreCase(testData.get("Occupation").trim())) {
									triggerOnClick(option);
									  System.out.println("Before Mofication - Occupation is: " +occupation + ", After Modification-Occupation  is: " + tdElement.getAttribute("value") + ". And sucessfully updated");
									Log.info("Before Mofication - Occupation is: " +occupation + ", After Modification-Occupation  is: " + tdElement.getAttribute("value") + ". And sucessfully updated");
									driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
									sleep(mediumWaitVal);
									actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);
									Log.info("User is able to Clicked on Approve Button");
									break;
  
								}
							}
						}	  
					}	  		  
					col_num++;
					break;
					
				case "ISIC *":
					if (!testData.get("ISIC").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							String ISIC=tdElement.getAttribute("value");
							sleep(minWaitVal);
							tdElement.clear();
							tdElement.click();
							List<WebElement> listOfmaritalStatus=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
							for (WebElement option : listOfmaritalStatus) {
								System.out.println("ISIC" +option.getText());
								if (option.getText().trim().equalsIgnoreCase(testData.get("ISIC").trim())) {
									triggerOnClick(option);
									  System.out.println("Before Modification -ISIC is: " +ISIC + ", After Modiction- ISIC is: " + tdElement.getAttribute("value") + ". And sucessfully updated");
									Log.info("Before Modification -ISIC is: " +ISIC + ", After Modiction- ISIC is: " + tdElement.getAttribute("value") + ". And sucessfully updated");
									driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
									sleep(mediumWaitVal);
									actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);
									Log.info("User is able to Clicked on Approve Button");
									break;
								}
							}
						}
					}
					col_num++;
					break;
					
				case "Staff Category":
					if (!testData.get("StaffCategory").trim().isEmpty()) {
						if (tdElement.getAttribute("value").trim() != null) {
							String staff=tdElement.getAttribute("value");
							sleep(minWaitVal);
							tdElement.clear();
							tdElement.click();
							List<WebElement> listOfmaritalStatus=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
							for (WebElement option : listOfmaritalStatus) {
								System.out.println("staff" +option.getText());
								if (option.getText().trim().equalsIgnoreCase(testData.get("StaffCategory").trim())) {
									triggerOnClick(option);
								    System.out.println("Before Modification -Staff Category is: " +staff + ", After Modification -Staff Category is: " + tdElement.getAttribute("value") + ". And sucessfully updated");
									Log.info("");
									driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
									sleep(mediumWaitVal);
									actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);
									Log.info("User is able to Clicked on Approve Button");
									break;
								}
							}
						}
					}
							
					col_num++;
					break;
					
				default:
					col_num++;
					break;
				}		
			}
			if(row_num<=tr_collection.size())
				row_num++;
		}
		actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
		Log.info("User ia able to Logged Out Sucessfully");
	}

	public void modify_fatca()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.FATCA_TAB).click();
		if(!testData.get("USResident").trim().isEmpty()){
			List<WebElement> usresidenttab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_RESIDENT);
			for(i=1;i<=usresidenttab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]/md-card//div[1]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				String value=driver.findElement(By.xpath("(//*[@name='usResident']/div[1]/div/md-radio-button[1]/div[2]/span)["+i+"]")).getText(); 
				if (str.equals("false")&&(testData.get("USResident").equalsIgnoreCase(value))){
					driver.findElement(By.xpath("(//*[@name='usResident']/div[1]/div/md-radio-button[1]/div/div[1])["+i+"]")).click();
					System.out.println("USResident value is updated Sucessfully");
					driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					driver.switchTo().alert().accept();
					Log.info("");
					break;
				}
			}
		}

		if(!testData.get("USCitizen").trim().isEmpty()){
			List<WebElement> uscitizentab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.US_CITIZEN);
			for(i=1;i<=uscitizentab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[3]/div[2]/md-input-container/md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				String value=driver.findElement(By.xpath("(//*[@name='usCitizen']/div[1]/div/md-radio-button[1]/div[2]/span)["+i+"]")).getText();
				if (str.equals("false")&&(testData.get("USCitizen").equalsIgnoreCase(value))){
					driver.findElement(By.xpath("(//*[@name='usCitizen']//md-radio-button[1]/div/div[1])["+i+"]")).click();
					System.out.println("USCitizen value is updated Sucessfully");
					Log.info("");
					driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					driver.switchTo().alert().accept();
					break;
				}  
			}
		}

		if(!testData.get("GreenCardHolder").trim().isEmpty()){
			List<WebElement> greencardholdertab=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.GREEN_CARD_HOLDER);
			for(i=1;i<=greencardholdertab.size();i++)
			{
				String str= driver.findElement(By.xpath("(//*[@id='FATCA']//div[1]/div[1]//div[4]/div[2]//md-radio-group//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				String value=driver.findElement(By.xpath("(//*[@name='usGreenCardHolder']/div[1]/div/md-radio-button[1]/div[2]/span)["+i+"]")).getText();
				if (str.equals("false")&&(testData.get("GreenCardHolder").equalsIgnoreCase(value))){
					driver.findElement(By.xpath("(//*[@name='usGreenCardHolder']//md-radio-button/div/div[1])["+i+"]")).click();
					System.out.println("GreenCardHolder value is  updated Sucessfully");
					Log.info("");
					driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					driver.switchTo().alert().accept();
					break;
				}  
			}
		}
	}

	public void cdd_modify()
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD).click();

		if(!testData.get("CDDReviewedFlag").trim().isEmpty())
		{
			List<WebElement> cddreviewflagradioButton=driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CDD_REVIEWED_FLAG);
			for(i=1;i<=cddreviewflagradioButton.size();i++)
			{
				String str = driver.findElement(By.xpath("((//*[@name='addrAmendAlertInd'])[2]//md-radio-button)"+"["+i+"]")).getAttribute("aria-checked");
				String value=driver.findElement(By.xpath("((//*[@name='addrAmendAlertInd'])[2]//md-radio-button/div[2]/span)["+i+"]")).getText();	
				if (str.equals("false")&&(testData.get("CDDReviewedFlag").equalsIgnoreCase(value))){
					driver.findElement(By.xpath("((//*[@name='addrAmendAlertInd'])[2]//md-radio-button/div/div[1])["+i+"]")).click();
					System.out.println("CDD Reviewed Flag is updated Sucessfully");
					driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					driver.switchTo().alert().accept();
					break;}
			}

		}
	}

	public void risk_modify() throws InterruptedException
	{
		sleep(mediumWaitVal);
		sleep(mediumWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_RISK).click();
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.RISK_CODE_TABLE_ROWS);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(ICM_UpdateCustomerProfilePage_Obj.RISK_CODE_TABLE_COLUME); 

			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String ExpectedValue = driver.findElement(By.xpath("(((//*[@class='table'])[3]//tr[1])[1]/th)["+col_num+"]")).getText().trim();
				System.out.println("Expected Value"+ExpectedValue);
				switch (ExpectedValue) {
				case "Expiry Date":
					if (!testData.get("ExpiryDate").trim().isEmpty()) {
						if (tdElement.getText().trim() != null) {
							WebElement ele= driver.findElement(By.xpath("(//*[@class='table'])[3]//tbody/tr["+row_num+"]/td["+col_num+"]//input"));
							ele.click();Thread.sleep(2000);
							ele.click();
							ele.clear();
							ele.sendKeys(testData.get("ExpiryDate"));
							if(!(tdElement.getText().equalsIgnoreCase(testData.get("ExpiryDate")))){
								System.out.println("Expiry Date is: " + testData.get("ExpiryDate") + "is updated sucessfully");
								Log.info("");}
							else{
								System.out.println("Expiry Date is:  " + testData.get("StartDate") + ". is not updated sucessfully");
								Log.info("");}
						}  
					}
					col_num++;
					driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
					driver.switchTo().alert().accept();
					break;
				default:
					driver.findElement(By.xpath("(//*[@class='table'])[3]//tbody/tr["+row_num+"]/td["+col_num+"]//input")).click();
					col_num++;
					break;
				}		
			}

			if(row_num<=tr_collection.size())
				row_num++;

		}
	} 

	public void mod_profileDormancyRisk(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.PROFILE_DORMANCY_RISK);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.DELETE_DORMANCY_RISK);sleep(minWaitVal);
	}
	
	public void mod_internal(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.INTERNAL);sleep(minWaitVal);
		actionClick(ICM_UpdateCustomerProfilePage_Obj.POPUPOK);sleep(minWaitVal);
		
		if(!testData.get("DECEASED_DATE").trim().isEmpty()){
			inputTextTab(ICM_UpdateCustomerProfilePage_Obj.DECEASED_DATE, testData.get("DECEASED_DATE"));
			Log.info("");}
		
		if(!testData.get("REFERRALID").trim().isEmpty()){
			enterInputText(ICM_UpdateCustomerProfilePage_Obj.REFERRALID, testData.get("REFERRALID"));
			Log.info("");}
		
		if(!testData.get("SOURCINGID").trim().isEmpty()){
			enterInputText(ICM_UpdateCustomerProfilePage_Obj.SOURCINGID, testData.get("SOURCINGID"));
			Log.info("");}
	
		if(!testData.get("CLOSINGID").trim().isEmpty()){
			enterInputText(ICM_UpdateCustomerProfilePage_Obj.CLOSINGID, testData.get("CLOSINGID"));
			Log.info("");}
		
		if(!testData.get("HOMEBRANCH").trim().isEmpty()){
			enterInputText(ICM_UpdateCustomerProfilePage_Obj.HOMEBRANCH, testData.get("HOMEBRANCH"));
			Log.info("");}
		
		if(!testData.get("Acquisition_Channel").trim().isEmpty()){
			enterInputText(ICM_UpdateCustomerProfilePage_Obj.Acquisition_Channel, testData.get("Acquisition_Channel"));
			Log.info("");}
	
		mod_MISVal();
		mod_referRelationship();
		mod_linkRelationship();
		}
	
	public void mod_MISVal(){
       if (!testData.get("MISCode").trim().isEmpty()) {
    	   actionEnterData(By.xpath("(//form[@name='internalTab']//table)[2]//tbody/tr/td[2]/md-input-container/input"), testData.get("MISCode"));
	  		System.out.println("MISCode : "+testData.get("MISCode")+ "is entered");
	  		Log.info("");}
	              
      if (!testData.get("MISValue").trim().isEmpty()) {
    	  actionEnterData(By.xpath("(//form[@name='internalTab']//table)[2]//tbody/tr/td[3]/md-input-container/input"), testData.get("MISValue"));
	        System.out.println("MISValue : "+testData.get("MISValue")+ "is entered");
	        Log.info("");}
      
      if (!testData.get("DeleteMIS").trim().isEmpty()) {
      actionClick(ICM_UpdateCustomerProfilePage_Obj.Delete_MIS);sleep(minWaitVal);
      Log.info("");}
	}
	
	
	public void mod_referRelationship(){
		if (!testData.get("REFERRED_RELATIONSHIP_NO").trim().isEmpty()) {
			actionClick(ICM_UpdateCustomerProfilePage_Obj.Refer_Relationship);sleep(minWaitVal);
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.Search_ICM_ID, testData.get("REFERRED_RELATIONSHIP_NO"));sleep(minWaitVal);
			actionClick(ICM_UpdateCustomerProfilePage_Obj.Search_Button);sleep(minWaitVal);
			actionClick(By.xpath("//a[text()='"+testData.get("REFERRED_RELATIONSHIP_NO")+"']"));sleep(mediumWaitVal);
	        System.out.println("REFERRED_RELATIONSHIP_NO Value is entered");
	        Log.info("");}
	}
	
	
	public void mod_linkRelationship(){
		if (!testData.get("Link Relationship No").trim().isEmpty()) {
			actionClick(ICM_UpdateCustomerProfilePage_Obj.Link_Relationship);sleep(minWaitVal);
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.Search_ICM_ID, testData.get("Link Relationship No"));sleep(minWaitVal);
			actionClick(ICM_UpdateCustomerProfilePage_Obj.Search_Button);sleep(minWaitVal);
			actionClick(By.xpath("//a[text()='"+testData.get("Link Relationship No")+"']"));sleep(mediumWaitVal);
	        System.out.println("Link Relationship No Value is entered");
	        Log.info("");}
	}
	
	public void mod_additionalDetails(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.ADDITIONAL_DETAILS);sleep(minWaitVal);
		
		if(!testData.get("Asia Miles Membership No").trim().isEmpty()){
			inputText(ICM_UpdateCustomerProfilePage_Obj.ASIA_MILES_MEMBERSHIP_NUMBER, testData.get("Asia Miles Membership No"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("Bankruptcy Court Order No").trim().isEmpty()){
			inputText(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_COURT_ORDER_NUMBER, testData.get("Bankruptcy Court Order No"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("Bankruptcy Court Order date").trim().isEmpty()){
			inputTextTab(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_COURT_ORDER_DATE, testData.get("Bankruptcy Court Order date"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("Bankruptcy Petition Filed date").trim().isEmpty()){
			inputTextTab(ICM_UpdateCustomerProfilePage_Obj.BANKRUPTCY_PETITION_FILED_DATE, testData.get("Bankruptcy Petition Filed date"));sleep(minWaitVal);
			Log.info("");}
		
		if(testData.get("International Mobile Preference flag").trim().equalsIgnoreCase("Yes")){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.INTERNATIONAL_MOBILE_PREF_FLAG);sleep(minWaitVal);
		Log.info("");}
		
		if(testData.get("SMS_NOTIFY_HIGH_RISK_TELLER_FLAG").trim().equalsIgnoreCase("Yes")){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.SMS_NOTIFY_HIGH_RISK_TELLER_FLAG);sleep(minWaitVal);
		Log.info("");}
		}
	
	public void mod_multilingual(){
		actionClick(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL);sleep(minWaitVal);
		
		if(!testData.get("LANGUAGE").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.LANGUAGE, testData.get("LANGUAGE"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("FULLNAME").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.FULLNAME, testData.get("FULLNAME"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MAILING_TITLE_1").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MAILING_TITLE_1, testData.get("MAILING_TITLE_1"));sleep(minWaitVal);
			Log.info("");}
	
		if(!testData.get("MAILING_TITLE_2").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MAILING_TITLE_2, testData.get("MAILING_TITLE_2"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_TYPE").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_TYPE, testData.get("MULTILINGUAL_TYPE"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_ADD1").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD1, testData.get("MULTILINGUAL_ADD1"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_ADD2").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD2, testData.get("MULTILINGUAL_ADD2"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_ADD3").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_ADD3, testData.get("MULTILINGUAL_ADD3"));sleep(minWaitVal);
			Log.info("");}
		
		if(!testData.get("MULTILINGUAL_CITY").trim().isEmpty()){
			actionEnterData(ICM_UpdateCustomerProfilePage_Obj.MULTILINGUAL_CITY, testData.get("MULTILINGUAL_CITY"));sleep(minWaitVal);
			Log.info("");}
	}
	
	
	public void mod_customerChoice() throws Exception{
		actionClick(ICM_UpdateCustomerProfilePage_Obj.CUSTOMER_CHOICE);sleep(minWaitVal);
		if(!testData.get("EMAIL_CUST_CHOICE").trim().isEmpty()){
			actionClick(ICM_UpdateCustomerProfilePage_Obj.EMAIL_CUST_CHOICE);
                  List<WebElement> listOfOption=driver.findElements(By.xpath("//*[@class='md-select-menu-container md-active md-clickable']//md-option"));
                 compare:
                  for (WebElement option : listOfOption) {
                         if (option.getText().trim().equalsIgnoreCase(testData.get("EMAIL_CUST_CHOICE").trim())) {
                                  triggerOnClick(option);
                                  Log.info("");
                                  break compare;}
                   }
            }
		
		
		if(!testData.get("MOBILE_CUST_CHOICE").trim().isEmpty()){
			actionClick(ICM_UpdateCustomerProfilePage_Obj.MOBILE_CUST_CHOICE);
                  List<WebElement> listOfOption=driver.findElements(By.xpath("//*[@class='md-select-menu-container md-active md-clickable']//md-option"));
                  for (WebElement option : listOfOption) {
                         if (option.getText().trim().equalsIgnoreCase(testData.get("MOBILE_CUST_CHOICE").trim())) {
                                  triggerOnClick(option);
                                  Log.info("");
                                  break;}
                  }      
            }
		
		if(!testData.get("POST_CUST_CHOICE").trim().isEmpty()){
			actionClick(ICM_UpdateCustomerProfilePage_Obj.POST_CUST_CHOICE);
                  List<WebElement> listOfOption=driver.findElements(By.xpath("//*[@class='md-select-menu-container md-active md-clickable']//md-option"));
                  for (WebElement option : listOfOption) {
                         if (option.getText().trim().equalsIgnoreCase(testData.get("POST_CUST_CHOICE").trim())) {
                                  triggerOnClick(option);
                                  Log.info("");
                                  break;}
                  } 
            }
		
		if(!testData.get("PHONE_CUST_CHOICE").trim().isEmpty()){
			actionClick(ICM_UpdateCustomerProfilePage_Obj.PHONE_CUST_CHOICE);
                  List<WebElement> listOfOption=driver.findElements(By.xpath("//*[@class='md-select-menu-container md-active md-clickable']//md-option"));
                  for (WebElement option : listOfOption) {
                         if (option.getText().trim().equalsIgnoreCase(testData.get("PHONE_CUST_CHOICE").trim())) {
                                  triggerOnClick(option);
                                  Log.info("");
                                  break;}
                  } 
            }
		
		
		if(!testData.get("REQUEST_OVER_PHONE").trim().isEmpty()){
			if(testData.get("REQUEST_OVER_PHONE").trim().equalsIgnoreCase("Yes")){
			actionClick(By.xpath("//md-radio-group[@ng-model='DND.requestOverPhone']//md-radio-button[@aria-label='Yes']/div[1]"));sleep(minWaitVal);
			Log.info("");}
			else if(testData.get("REQUEST_OVER_PHONE").trim().equalsIgnoreCase("No")){
				actionClick(By.xpath("//md-radio-group[@ng-model='DND.requestOverPhone']//md-radio-button[@aria-label='No']/div[1]"));sleep(minWaitVal);}
			Log.info("");}
	}
	
	public void verify_script()
	{
		waitForTextToLoad(By.xpath("//label[text()='ICM ID']"), "ICM ID");sleep(maxWaitVal);
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD).click();
		Log.info("User ia able to clicked on CDD Tab Sucessfully");
		if (!testData.get("CustomerCDDStatus").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value").equalsIgnoreCase(testData.get("CustomerCDDStatus"))){
					System.out.println("CDD Status is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value") + ", Expected CDD status is: " + testData.get("CustomerCDDStatus") + ". And it matches");
					Log.info("CDD Status is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value") + ", Expected CDD status is: " + testData.get("CustomerCDDStatus") + ". And it matches");}
			}
		}
 
		if (!testData.get("CDDLastReviewedDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CDDLastReviewedDate"))){
					System.out.println("CDD LAST REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value") + ", Expected CDD LAST REVIEW DATE is: " + testData.get("CDDLastReviewedDate") + ". And it matches");
					Log.info("CDD LAST REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value") + ", Expected CDD LAST REVIEW DATE is: " + testData.get("CDDLastReviewedDate") + ". And it matches");}
			}
		}
	
		if (!testData.get("CDDNextReviewDate").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value").equalsIgnoreCase(testData.get("CDDNextReviewDate"))){
					System.out.println("CDD NEXT REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value") + ", Expected CDD NEXT REVIEW DATE is: " + testData.get("CDDNextReviewDate") + ". And it matches");
					Log.info("CDD NEXT REVIEW DATE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value") + ", Expected CDD NEXT REVIEW DATE is: " + testData.get("CDDNextReviewDate") + ". And it matches");}
			}
		}
		
		if (!testData.get("CDDRiskCode").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value").trim() != null) {
				System.out.println(testData.get("CDDRiskCode"));
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value").equalsIgnoreCase(testData.get("CDDRiskCode"))){
					System.out.println("CDD RISK CODE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value") + ", Expected CDD RISK CODE is: " + testData.get("CDDRiskCode") + ". And it matches");
					Log.info("CDD RISK CODE is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value") + ", Expected CDD RISK CODE is: " + testData.get("CDDRiskCode") + ". And it matches");
				}
			}
		}

		
		driver.findElement(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_RISK).click();
		Log.info("User ia able to clicked on Risk Tab Sucessfully");
		if (!testData.get("RelationshipId").trim().isEmpty()) {
			if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value").trim() != null) {
				if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value").contains(testData.get("RelationshipId"))){
					System.out.println("ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipId") + ". And it matches");
					Log.info("ICM Relationship Number is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.RISK_REALTION_NO).getAttribute("value") + ", Expected RelationShip Number is: " + testData.get("RelationshipId") + ". And it matches");
				}
			}
		}
		
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
		   actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);	
		   Log.info("User is able to Logged Out Sucessfully");
	}

	
  public void email_modify()
  {         
	        sleep(mediumWaitVal);
			driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TAB).click();
			List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_DETAILS_TABLE_ROW);
			int row_num=1,col_num=1;
			for (WebElement trElement : tr_collection) 
			{
				String value=driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]/td[1]")).getText();

				if(testData.get("Classification").equalsIgnoreCase(value))	
				{
					driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]")).click();
					
					if (!testData.get("Email").trim().isEmpty()) {
						if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value").trim() != null) {
							String Email=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value");
							inputText(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL, testData.get("Email"));
							if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value").contains(testData.get("Email"))){
								System.out.println("Before Modification - Email is: " +Email + ", After Modification Email is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value") + ". And sucessfully updated");
								Log.info("Before Modification - Email is: " +Email + ", After Modification Email is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CONTACT_EMAIL).getAttribute("value") + ". And sucessfully updated");
								driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
							    sleep(mediumWaitVal);
								actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
								Log.info("User ia able to Clicked on Approve Button");
								break;
							} 
						}
					}
					
				}
				if(row_num<=tr_collection.size())
					row_num++;
			}
			actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
			actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);
			Log.info("User is able to Logged Out Sucessfully");
		}		   
  
  public void nationality_modify() throws Exception{
	sleep(mediumWaitVal);
	   if (!testData.get("Nationality").trim().isEmpty()) {
		   if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() != null) {
			   String nationality=driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim();
			   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).click();
			   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).clear();
			   driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).click();
			   sleep(minWaitVal);
			   List<WebElement> listOfOptions=driver.findElements(By.xpath("//*[@class='dropdown-menu ng-isolate-scope']/li"));
			   for (WebElement option : listOfOptions) {
				   System.out.println("Nationality" +option.getText());
				   if (option.getText().trim().equalsIgnoreCase(testData.get("Nationality").trim())) {
					     triggerOnClick(option);
				         System.out.println("Before Modification - Nationality is: " +nationality + ", After Modification - Nationality is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() + ". And sucessfully updated");
				         Log.info("Before Modification - Nationality is: " +nationality + ", After Modification - Nationality is: " + driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() + ". And sucessfully updated");
				         driver.findElement(By.xpath("//*[@id='customerProfileBody']/div[2]/button")).click();
						    sleep(mediumWaitVal);
							actionClick(ICM_UpdateCustomerProfilePage_Obj.OK_ALERT_BUTTON);;sleep(minWaitVal);	
							Log.info("User is able to Clicked on Approve Button");
							break;
				   }
			   }
		   }
	   }
	   actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
	   actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);	  
	   Log.info("User is able to Logged Out Sucessfully");
  }

public void Verify_nationality()
{
	sleep(mediumWaitVal);
	sleep(mediumWaitVal);
	if (!testData.get("Nationality").trim().isEmpty()) {
		if (driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").trim() != null) {
			if(driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value").contains(testData.get("Nationality"))){
				System.out.println("Nationality is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value") + ", Expected Nationality is: " + testData.get("Nationality") + ". And it matches");
				Log.info("Nationality is: " +driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value") + ", Expected Nationality is: " + testData.get("Nationality") + ". And it matches");
			}
		}
	}
	   actionClick(ICM_UpdateCustomerProfilePage_Obj.LOGOUT);sleep(minWaitVal);
	   actionClick(ICM_UpdateCustomerProfilePage_Obj.YES_BUTTON);sleep(minWaitVal);	 
	   Log.info("User is able to Logged Out Sucessfully");
}
	
	
}
