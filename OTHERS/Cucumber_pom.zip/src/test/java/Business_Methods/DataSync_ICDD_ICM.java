package Business_Methods;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebElement;

import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICM_UpdateCustomerProfilePage_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class DataSync_ICDD_ICM extends Common_Utils {
	DataProvider dataprovider = new DataProvider();
	ICM_UpdateCustomerProfilePage ICM_Modules = new ICM_UpdateCustomerProfilePage();
	ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
	ICDD_WorkItem ICDD_WorkItem = new ICDD_WorkItem();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public HashMap<String, String> testData = null;
	public String sheetname = null;
	public String scenarioName = null;
	StringBuffer unsync = new StringBuffer();
	StringBuffer empty = new StringBuffer();
	
	public void ICM_Data(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("######################## Data in ICM ############################");
		this.testData = testData;
		ICM_Modules.login();
		ICM_Modules.serachForIcmId(testData);
		
		//system cross reference check before proceeding with data validation
		click(By.xpath("//span[text()='Cross Reference']"));sleep(minWaitVal);
		click(By.xpath("//a[text()='System Cross Reference']"));
		try{
		if(driver.findElement(By.xpath("(//table[@class='table table-bordered table-responsive table-hover'])[2]//td")).getText()
				.equalsIgnoreCase(testData.get("ICDD_ID"))){
			dataprovider.insertExcelData(scenarioName, "System_Cross_Reference",sheetname, "valid");
			screenshot();
			getICMData(scenarioName, testData, sheetname);}
		}catch (Exception e) {
			System.out.println("exception :" +e);
			System.out.println("System cross reference check Failed, Data not valid");
			dataprovider.insertExcelData(scenarioName, "System_Cross_Reference",sheetname, "Not Valid");
		}
	}
		
	
	public void ICDD_Data(String scenarioName, HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("############################ Data in ICM ############################");
		try{
		getICDDdata(scenarioName, testData, sheetname);}
		catch (Exception e) {
			System.out.println("Exception : "+e);
			ICDD_WorkItem.logout();
		}
	}
	
	public void DataSyncVerify(String scenarioName, HashMap<String, String> testData, String sheetname) throws Exception{
		this.testData = testData;
		this.sheetname = sheetname;
		this.scenarioName = scenarioName;
		Log.info("############################ DataSync verification in ICM/ICDD ############################");
		compareString(testData.get("CUSTOMER_NAME_ICDD"), testData.get("ICM_FullName"), "Customer Name");
		compareString(testData.get("RISK_RATING_ICDD"), testData.get("ICM_CDD_RiskCode"), "CDD Risk code");
		compareData(testData.get("CDD_STATUS_ICDD"), testData.get("ICM_CDD_Status"), "CDD Status");
		compareCountryData(testData.get("COUNTRY_ICDD"), testData.get("ICM_COUNTRY"), "Country of birth");
		compareString(testData.get("DOB_ICDD"), testData.get("ICM_DOB"), "Date of birth");
		compareStringContains(testData.get("NATIONALITY_ICDD"), testData.get("ICM_Nationality"), "Nationality");
		compareString(testData.get("NEXT_REVIEW_DATE_ICDD"), testData.get("ICM_NRD"), "Next Review Date");
		compareString(testData.get("LAST_REVIEW_DATE_ICDD"), testData.get("ICM_LRD"), "Last Review Date");
		compareString(testData.get("EMAIL_ICDD"), testData.get("ICM_EMAIL"), "Email ID");
		compareString(testData.get("SUBSEGMENT_ICDD"), testData.get("ICM_SEGMENT"), "Segment Code");
		//compareString(testData.get("SEGMENT_ICDD"), testData.get("ICM_SUB_SEGMENT"), "Subsegment Code");
		compareStringContains(testData.get("ICM_ADDRESS1"), testData.get("RESIDENTIAL_ADDRESS_ICDD"), "Address 1");
		compareStringContains(testData.get("ICM_ADDRESS2"), testData.get("RESIDENTIAL_ADDRESS_ICDD"), "Address 2");
		compareStringContains(testData.get("ICM_ADDRESS3"), testData.get("RESIDENTIAL_ADDRESS_ICDD"), "Address 3");
		compareString(testData.get("CITY_ICDD"), testData.get("ICM_CITY"), "CITY");
		compareString(testData.get("STATE_ICDD"), testData.get("ICM_STATE"), "STATE");
		compareCountryData(testData.get("COUNTRY_ICDD"), testData.get("ICM_COUNTRY"), "COUNTRY");
		reasonCode(testData.get("POTANTIAL_PEP_ICDD"), testData.get("ICM_REASONCODE"), "PEP", "POTANTIAL_PEP");
		reasonCode(testData.get("POTANTIAL_ADVERSE_MEDIA_ICDD"), testData.get("ICM_REASONCODE"), "IBB", "Adverse_Media");
	}
	
	
	public void getICDDdata(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName,testData);
        ICDD_CustomerRecord.clickiccdid(scenarioName,testData);sleep(minWaitVal);
        webDriverwait(ICDD_CustomerRecord_Obj.CUSTOMER_NAME);
        System.out.println(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        dataprovider.insertExcelData(scenarioName, "CUSTOMER_NAME_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        Log.info("Actual CUSTOMER_NAME_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        System.out.println("Actual CUSTOMER_NAME_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        
        try{
        dataprovider.insertExcelData(scenarioName, "RISK_RATING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        Log.info("Actual RISK_RATING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        screenshot();
        System.out.println("Actual RISK_RATING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        }
        catch (Exception e) {
            System.out.println("CDD_STATUS_ICDD Not Available");
          }
        
        try{
        dataprovider.insertExcelData(scenarioName, "CDD_STATUS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        Log.info("Actual CDD_STATUS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        screenshot();
        System.out.println("Actual CDD_STATUS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        }
        catch (Exception e) {
            System.out.println("CDD_STATUS_ICDD Not Available");
          }
       
        try{
        dataprovider.insertExcelData(scenarioName, "CITY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        Log.info("Actual CITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        screenshot();
        System.out.println("Actual CITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        }
        catch (Exception e) {
            System.out.println("CITY_ICDD Not Available");
          }
       
        
        try{
        dataprovider.insertExcelData(scenarioName, "STATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        Log.info("Actual STATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        screenshot();
        System.out.println("Actual STATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        }
        catch (Exception e) {
            System.out.println("STATE_ICDD Not Available");
          }
        
        
        try{
        dataprovider.insertExcelData(scenarioName, "COUNTRY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        Log.info("Actual COUNTRY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        screenshot();
        System.out.println("Actual COUNTRY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        }
        catch (Exception e) {
            System.out.println("COUNTRY_ICDD Not Available");
          }
        
        try{
        dataprovider.insertExcelData(scenarioName, "DOB_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        Log.info("Actual DOB_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        screenshot();
        System.out.println("Actual DOB_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        }
        catch (Exception e) {
            System.out.println("DOB_ICDD Not Available");
          }
        
        try{
        dataprovider.insertExcelData(scenarioName, "RESIDENTIAL_ADDRESS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RESIDENTIAL_ADDRESS).getText());
        Log.info("Actual RESIDENTIAL_ADDRESS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RESIDENTIAL_ADDRESS).getText());
        screenshot();
        System.out.println("Actual RESIDENTIAL_ADDRESS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RESIDENTIAL_ADDRESS).getText());
	 }
    catch (Exception e) {
      System.out.println("RESIDENTIAL_ADDRESS_ICDD Not Available");
    }
        
        
        try{
        dataprovider.insertExcelData(scenarioName, "NATIONALITY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
        Log.info("Actual NATIONALITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
        screenshot();
        System.out.println("Actual NATIONALITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
	     }
        catch (Exception e) {
          System.out.println("NATIONALITY_ICDD Not Available");
        }

        
        try{
        dataprovider.insertExcelData(scenarioName, "NEXT_REVIEW_DATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
        Log.info("Actual NEXT_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
        screenshot();
        System.out.println("Actual NEXT_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
	      }
        catch (Exception e) {
       System.out.println("NEXT_REVIEW_DATE_ICDD Not Available");
	   }
        
        try{
        dataprovider.insertExcelData(scenarioName, "LAST_REVIEW_DATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        Log.info("Actual LAST_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        screenshot();
        System.out.println("Actual LAST_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        }
        catch (Exception e) {
        	System.out.println("LAST_REVIEW_DATE_ICDD Not Available");
    	}
        
      /*  dataprovider.insertExcelData(scenarioName, "SUBSEGMENT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SUB_SEGMENT).getText());
        Log.info("Actual SUB_SEGMENT is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SUB_SEGMENT).getText());
        System.out.println("Actual SUB_SEGMENT Code is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SUB_SEGMENT).getText());
      */  
        clickPerform(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);sleep(minWaitVal);
        screenshot();
        try{
        dataprovider.insertExcelData(scenarioName, " NAME_OF_EMPLYER_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
        Log.info("Actual NAME_OF_EMPLYER_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
        screenshot();
        System.out.println("Actual NAME_OF_EMPLYER_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
	  }
	catch (Exception e) {
    	System.out.println("SEGMENT_ICDD Not Available");
	}

        try{
        dataprovider.insertExcelData(scenarioName, "SEGMENT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SEGMENT).getText());
        Log.info("Actual LAST_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SEGMENT).getText());
        screenshot();
        System.out.println("Actual Segment Code is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SEGMENT).getText());
        }
        catch (Exception e) {
        	System.out.println("SEGMENT_ICDD Not Available");
		}
        
        click(ICDD_CustomerRecord_Obj.ONBOARDING_TAB);sleep(minWaitVal);
        try{
        dataprovider.insertExcelData(scenarioName, "NAME_SCREENING_HIT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());
        Log.info("Actual NAME_SCREENING_HIT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());
        screenshot();
        System.out.println("Actual NAME_SCREENING_HIT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());}
        catch (Exception e) {
        	System.out.println("NAME_SCREENING_HIT Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "NAME_SCREENING_ALERT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        Log.info("Actual NAME_SCREENING_ALERT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        screenshot();
        System.out.println("Actual NAME_SCREENING_ALERT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        } catch (Exception e) {
        	System.out.println("NAME_SCREENING_ALERT_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "MATCH_TRUE_MATCH_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        Log.info("Actual MATCH_TRUE_MATCH_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        screenshot();
        System.out.println("Actual MATCH_TRUE_MATCH_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        } catch (Exception e) {
        	System.out.println("MATCH_TRUE_MATCH_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "TYPE_NAME_SCREENING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        Log.info("Actual TYPE_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        System.out.println("Actual TYPE_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        }
        catch (Exception e) {
        	System.out.println("TYPE_NAME_SCREENING_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_PEP_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        Log.info("Actual POTANTIAL_PEP_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        System.out.println("Actual POTANTIAL_PEP_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        }
        catch (Exception e) {
        	System.out.println("POTANTIAL_PEP_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_SANCTIONS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        Log.info("Actual POTANTIAL_SANCTIONS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        screenshot();
        System.out.println("Actual POTANTIAL_SANCTIONS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        }
        catch (Exception e) {
        	System.out.println("POTANTIAL_SANCTIONS_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_ADVERSE_MEDIA_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        Log.info("Actual POTANTIAL_ADVERSE_MEDIA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        System.out.println("Actual POTANTIAL_ADVERSE_MEDIA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        }
        catch (Exception e) {
        	System.out.println("POTANTIAL_ADVERSE_MEDIA_ICDD Not Available");
		}
        screenshot();
        clickPerform(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);sleep(minWaitVal);
        screenshot();
        try{
        dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_STATIC_DATA_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        Log.info("Actual PROHIBITION_BASED_ON_STATIC_DATA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        System.out.println("Actual PROHIBITION_BASED_ON_STATIC_DATA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        }
        catch (Exception e) {
        	System.out.println("PROHIBITION_BASED_ON_STATIC_DATA_ICDD Not Available");
		}
        
        try{
        dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_NAME_SCREENING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        Log.info("Actual PROHIBITION_BASED_ON_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        screenshot();
        System.out.println("Actual PROHIBITION_BASED_ON_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        }
        catch (Exception e) {
        	System.out.println("PROHIBITION_BASED_ON_NAME_SCREENING_ICDD Not Available");
		}
        
       /* clickPerform(ICDD_CustomerRecord_Obj.CUSTOMER_PHONE_NUM);sleep(minWaitVal);
        try{
        dataprovider.insertExcelData(scenarioName, " PHONE1_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        Log.info("Actual PHONE1_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        System.out.println("Actual PHONE1_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        }catch(Exception e){}*/
        screenshot();
        clickPerform(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS);sleep(minWaitVal);
        screenshot();
        try{
        dataprovider.insertExcelData(scenarioName, " EMAIL_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        }catch(Exception e){}
        screenshot();
        //get key risk indicators data
        click(By.xpath("//td[contains(text(),'Key Risk Indicators')]"));
        screenshot();
        dataprovider.insertExcelData(scenarioName, "PEP_STATUS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_STATUS_ICDD).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_STATUS_ICDD).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_STATUS_ICDD).getText());
        
        dataprovider.insertExcelData(scenarioName, "PEP_CATEGORY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_CATEGORY_ICDD).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_CATEGORY_ICDD).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PEP_CATEGORY_ICDD).getText());
        
        dataprovider.insertExcelData(scenarioName, "ADVERSE_MEDIA_STATUS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_STATUS_ICDD).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_STATUS_ICDD).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_STATUS_ICDD).getText());
        screenshot();
        
        dataprovider.insertExcelData(scenarioName, "ADVERSE_MEDIA_SEVERITY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_SEVERITY_ICDD).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_SEVERITY_ICDD).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ADVERSE_MEDIA_SEVERITY_ICDD).getText());
        
        dataprovider.insertExcelData(scenarioName, "SANCTION_STATUS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SANCTION_STATUS_ICDD).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SANCTION_STATUS_ICDD).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.SANCTION_STATUS_ICDD).getText());
        screenshot();
       /* clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT_TAB);sleep(minWaitVal);
        clickPerform(ICDD_CustomerRecord_Obj.ACTIVE_ACCOUNT_DETAILS);sleep(minWaitVal);
        dataprovider.insertExcelData(scenarioName, " ACCOUNT_NUMBER5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_NUMBER5).getText());
        dataprovider.insertExcelData(scenarioName, " ACCCOUNT_SUBPRODUCT5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCCOUNT_SUBPRODUCT5).getText());
        dataprovider.insertExcelData(scenarioName, " ACCOUNT_SUBPRODUCT_DESCRIPTION5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_SUBPRODUCT_DESCRIPTION5).getText());*/
        //driver.quit();
        ICDD_WorkItem.logout();
	}
	
	public void getICMData(String scenarioName, HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("########### Basic Data");
		//ICM_Relationship_No
		sleep(mediumWaitVal);
		//webDriverWait(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO);
		String val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_Relationship_No", sheetname, val);
			System.out.println("Actual ICM Relationship Number is: " + val);
			Log.info("Actual ICM Relationship Number is: " + val);}
		
		//ICM_Status
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_STATUS).getText();
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_Status", sheetname, val);
			System.out.println("Actual ICM Status is: " + val);
			Log.info("Actual ICM Status is: " + val);}
		
		//ICM_Gender
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText();
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_Gender", sheetname, val);
			System.out.println("Actual ICM Gender is: " + val);
			Log.info("Actual ICM Gender is: " + val);}
		screenshot();
		
		//DOB
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_DOB", sheetname, val);
			System.out.println("Actual ICM DOB is: " + val);
			Log.info("Actual ICM DOB is: " + val);}
		
		//nationality
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_Nationality", sheetname, val);
			System.out.println("Actual ICM Nationality is: " + val);
			Log.info("Actual ICM Nationality is: " + val);}
		screenshot();
		
		//Country of birth
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_CountryOfBirth", sheetname, val);
			System.out.println("Actual ICM Country of Birth is: " + val);
			Log.info("Actual ICM Country of Birth is: " + val);}
		
		//Customer_fullname
		click(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_RISK);sleep(minWaitVal);
		val = driver.findElement(By.xpath("(//input[@id='custname'])[1]")).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_FullName", sheetname, val);
			System.out.println("Actual ICM Customer Fullname is: " + val);
			Log.info("Actual ICM Customer Fullname is: " + val);}		
		
		Log.info("########### CDD data");
		//CDD status
		click(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD);
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_CDD_Status", sheetname, val);
			System.out.println("Actual ICM CDD Status is: " + val);
			Log.info("Actual ICM CDD Status is: " + val);}
		screenshot();
		
		//CDD Risk code
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_CDD_RiskCode", sheetname, val);
			System.out.println("Actual ICM CDD Risk Code is: " + val);
			Log.info("Actual ICM CDD Risk Code is: " + val);}
		
		//LRD
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_LRD", sheetname, val);
			System.out.println("Actual ICM LRD is: " + val);
			Log.info("Actual ICM LRD is: " + val);}
		
		//NRD
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_NRD", sheetname, val);
			System.out.println("Actual ICM NRD is: " + val);
			Log.info("Actual ICM NRD is: " + val);}
		screenshot();
		
		//Risk reason code
		click(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD);
	    String reasoncod;
	    List<WebElement> reasoncode=driver.findElements(By.xpath("//*[@name='assReasonCode']"));
	    StringBuffer unsyncf1 = new StringBuffer();
	    for (WebElement trElement1 : reasoncode) {
	    	System.out.println(trElement1.getAttribute("value"));
	     	System.out.println(trElement1.getText());
	           if (trElement1.getAttribute("value").trim() != null) {
	                  reasoncod=trElement1.getAttribute("value");
	                  unsyncf1.append(reasoncod).append("|");
	           }
	    }
	    dataprovider.insertExcelData(scenarioName, "ICM_REASONCODE", sheetname, unsyncf1.toString());
	    screenshot();
		
		//email
		click(ICM_UpdateCustomerProfilePage_Obj.CONTACT_TAB);
		List<WebElement> tr_collection = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.CONTACT_DETAILS_TABLE_ROW);
		int row_num=1,col_num=1;
		for (WebElement trElement : tr_collection) 
		{
			List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			int n = td_collection.size();
			col_num=1;
			for (WebElement tdElement  :td_collection)
			{
				String value=driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]/td[2]")).getText();
				if(testData.get("ICM_Classification").equalsIgnoreCase(value))	
				{
			    driver.findElement(By.xpath("(//*[@class='table table-condensed highlight ng-isolate-scope'])[2]//tbody/tr["+row_num+"]")).click();
			    String ExpectedValue = driver.findElement(By.xpath("((//*[@id='tab-content-2']//div[3]/div/table//tr[1])[1]/th)["+col_num+"]")).getText().trim();
			    switch (ExpectedValue) {
				case "Details":
						if (tdElement.getText().trim() != null) {
								dataprovider.insertExcelData(scenarioName, "ICM_EMAIL", sheetname, tdElement.getText());
								System.out.println("Actual ICM Email is: " + tdElement.getText());
								Log.info("Actual ICM Email is: " + tdElement.getText());
							}
					col_num++;
					break;

				default:
					col_num++;
					break;
				}	
				}		
			}
			if(row_num<=tr_collection.size())
				row_num++;
		}
		screenshot();
		//segment
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SEGMENT).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_SEGMENT", sheetname, val);
			System.out.println("Actual ICM Segment Value is: " + val);
			Log.info("Actual ICM Segment Value is: " + val);}
		
		//subSegemrt
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.SUB_SEGMENT).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "ICM_SUB_SEGMENT", sheetname, val);
			System.out.println("Actual ICM Sub-Segment Value is: " + val);
			Log.info("Actual ICM Sub-Segment Value is: " + val);}
		screenshot();
		//city
		click(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_TAB);
		List<WebElement> tr_collection1 = driver.findElements(ICM_UpdateCustomerProfilePage_Obj.ADDRESS_NO_OF_ROWS);
		int row_num1=1,col_num1=1;
		for (WebElement trElement1 : tr_collection1) {
			List<WebElement> td_collection = trElement1.findElements(By.tagName("td")); 
			int n = td_collection.size();
			col_num1=1;
			for (WebElement tdElement  :td_collection){
				String value=driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num1+"]/td[1]")).getText();
				if(testData.get("ICM_AddressType").equalsIgnoreCase(value))	
				{
			    driver.findElement(By.xpath("//*[@id='addressForm']/div[3]/div/table//tbody/tr["+row_num1+"]")).click();
				String ExpectedValue = driver.findElement(By.xpath("((//*[@id='addressForm']/div[3]/div/table//tr[1])[1]/th)["+col_num1+"]")).getText().trim();
				switch (ExpectedValue) {
				case "Address 1":
					if (!tdElement.getText().isEmpty()) {
						dataprovider.insertExcelData(scenarioName, "ICM_ADDRESS1", sheetname, tdElement.getText());
						System.out.println("Actual ICM Address 1 is: " + tdElement.getText());
						Log.info("Actual ICM Address 1 is: " + tdElement.getText());

					}
					col_num1++;
					break;
				case "Address 2":
					if (!tdElement.getText().isEmpty()) {
						dataprovider.insertExcelData(scenarioName, "ICM_ADDRESS2", sheetname, tdElement.getText());
						System.out.println("Actual ICM Address 2 is: " + tdElement.getText());
						Log.info("Actual ICM Address 2 is: " + tdElement.getText());

					}
					col_num1++;
					break;
				case "Address 3":
					if (!tdElement.getText().isEmpty()) {
							dataprovider.insertExcelData(scenarioName, "ICM_ADDRESS3", sheetname, tdElement.getText());
							System.out.println("Actual ICM Address 3 is: " + tdElement.getText());
							Log.info("Actual ICM Address 3 is: " + tdElement.getText());
					}
					col_num1++;
					break;
				case "City":
					if (!tdElement.getText().isEmpty()) {
						dataprovider.insertExcelData(scenarioName, "ICM_CITY", sheetname, tdElement.getText());
						System.out.println("Actual ICM City is: " + tdElement.getText());
						Log.info("Actual ICM City is: " + tdElement.getText());
					}
					col_num1++;
					break;
				case "State":
					if (!tdElement.getText().isEmpty()) {
						dataprovider.insertExcelData(scenarioName, "ICM_STATE", sheetname, tdElement.getText());
						System.out.println("Actual ICM State is: " + tdElement.getText());
						Log.info("Actual ICM State is: " + tdElement.getText());
					}
					col_num1++;
					break;
				case "Country":
					if (!tdElement.getText().isEmpty()) {
						dataprovider.insertExcelData(scenarioName, "ICM_COUNTRY", sheetname, tdElement.getText());
						System.out.println("Actual ICM Country is: " + tdElement.getText());
						Log.info("Actual ICM Country is: " + tdElement.getText());
					}
					col_num1++;
					break;

				default:
					col_num1++;
					break;
				}	
			}
			// row_num++;
		}	if(row_num1<=tr_collection1.size())
			row_num1++;
	}
		screenshot();
		icmLogout();
}

	public void icmLogout() throws Exception{
		int count = 0;
		String temp = "";
		//switchBackToParentWindow(windowTitle);
		/*webDriverWait(By.xpath("//a[text()=' Logout']"));
		click(By.xpath("//a[text()=' Logout']"));sleep(minWaitVal);*/
		
			/*for (String winHandle : driver.getWindowHandles()) {
				driver.switchTo().window(winHandle);
			}*/
		for (String winHandle : driver.getWindowHandles()) {
			if(count == 0){
				temp = winHandle;
				driver.switchTo().window(winHandle);
			}else{
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_SHIFT);
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_CONTROL);
				robot.keyRelease(KeyEvent.VK_SHIFT);
				robot.keyRelease(KeyEvent.VK_TAB);
				robot.keyPress(KeyEvent.VK_CONTROL);
				robot.keyPress(KeyEvent.VK_W);
				robot.keyRelease(KeyEvent.VK_CONTROL);
				robot.keyRelease(KeyEvent.VK_W);
			}
			count++;
		}
		driver.switchTo().defaultContent(); 
		sleep(minWaitVal);
		
			/*try {
				alert = driver.switchTo().alert();
				alertPresents = true;
				break;
			} catch (NoAlertPresentException Ex) {
			}
		}
		if (alertPresents) {
			alert.accept();sleep(minWaitVal);
			Log.info("User is able to clicked on ICM Id Sucessfully");}
		click(By.xpath("//button[@class='md-button md-ink-ripple md-autofocus']/span"));sleep(minWaitVal);
		switchBackToParentWindow("Login");*/
	}
	
	public void compareData(String ICDD, String ICM, String fieldvalue) throws Exception{
		if(!ICDD.trim().replaceAll("\\s+","").isEmpty() && !ICM.trim().replaceAll("\\s+","").isEmpty()){
		switch (ICDD) {
		case "C-Review Completed":
			if(ICM.equalsIgnoreCase("C - Review Completed")){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);
			}
			break;
			
		case "W-Review WIP":
			//if(ICM.equalsIgnoreCase("W - WB REVIEW UPDATE - REF EKYC")){
			if(ICM.equalsIgnoreCase("W - Review WIP")){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);
			}
			break;
		
		case "O-Review Overdue":
			if(ICM.equalsIgnoreCase("O")){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);}
			break;
			
		case "E-Pending-Exit":
			if(ICM.equalsIgnoreCase("E - Pending-Exit")){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);}
			break;	
			
		default :
    			Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
    			updateUnsyncfield(fieldvalue);
			}
	}else{
		System.out.println("No "+ fieldvalue +" value is available either ICDD or ICM");
		updateEmptyField(fieldvalue);
		}
	}
	
	public void compareCountryData(String ICDD, String ICM, String fieldvalue) throws Exception{
		if(!ICDD.trim().replaceAll("\\s+","").isEmpty() && !ICM.trim().replaceAll("\\s+","").isEmpty()){
		switch (ICDD) {
		case "HONG KONG":
			Compare(ICM, "HK", fieldvalue);
			break;
			
		case "THAILAND":
			Compare(ICM, "TH", fieldvalue);
			break;
			
		case "KAZAKHSTAN":
			Compare(ICM, "KZ", fieldvalue);
			break;
			
		case "CN":
			Compare(ICM, "CN", fieldvalue);
			break;
			
		case "INDONESIA":
			Compare(ICM, "IN", fieldvalue);
			break;
			
		case "UNITED KINGDOM":
			Compare(ICM, "GB", fieldvalue);
			break;
			
		case "IRAQ":
			Compare(ICM, "IQ", fieldvalue);
			break;
			
		case "IRAN, ISLAMIC REPUBLIC OF":
			Compare(ICM, "IR", fieldvalue);
			break;
			
		case "ISRAEL":
			Compare(ICM, "IL", fieldvalue);
			break;
			
		case "UNITED STATES":
			Compare(ICM, "US", fieldvalue);
			break;
			
		case "UNITED ARAB EMIRATES":
			Compare(ICM, "IR", fieldvalue);
			break;
			
		case "CANADA":
			Compare(ICM, "CA", fieldvalue);
			break;
			
		case "JAMAICA":
			Compare(ICM, "JM", fieldvalue);
			break;
			
		case "AUSTRIA":
			Compare(ICM, "AT", fieldvalue);
			break;
			
		case "PHILIPPINES":
			Compare(ICM, "PH", fieldvalue);
			break;
			
		case "SYRIAN ARAB REPUBLIC":
			Compare(ICM, "SY", fieldvalue);
			break;
			
		case "KOREADEMOCRATIC PEOPLES REP":
			Compare(ICM, "KP", fieldvalue);
			break;
			}
		
		}
	}
		
		public void Compare(String ICM, String ICDD, String fieldvalue) throws Exception{
			if(ICM.contains(ICDD)){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);
		}
		}
	

    public void compareString(String ICDD, String ICM, String fieldValue) throws Exception{
    	if(!ICDD.trim().replaceAll("\\s+","").isEmpty() && !ICM.trim().replaceAll("\\s+","").isEmpty()){
    	if(ICDD.trim().replaceAll("\\s+","").equalsIgnoreCase(ICM.trim().replaceAll("\\s+",""))){
//    	if(ICDD.trim().replaceAll("\\s+","").equalsIgnoreCase(ICM)){
    		System.out.println(fieldValue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );
    		Log.info(fieldValue + " : is in sync between ICM and ICDD");
    	} else{
    		System.out.println(fieldValue + " value in ICDD : "+"*"+ ICDD +"*"+" is not in SYNC with ICM Value : "+"*"+ ICM +"*");
    		Log.info(fieldValue + " : is not in sync between ICM and ICDD");
    		updateUnsyncfield(fieldValue);}
    	}
    	else{
    		System.out.println("No "+ fieldValue +" value is available either ICDD or ICM");
    		updateEmptyField(fieldValue);
    	}
    }
	
    public void compareStringContains(String ICDD, String ICM, String fieldValue) throws Exception{
    	if(!ICDD.trim().replaceAll("\\s+","").isEmpty() && !ICM.trim().replaceAll("\\s+","").isEmpty()){
    	if(ICM.trim().replaceAll("\\s+","").contains(ICDD.trim().replaceAll("\\s+",""))||ICDD.trim().replaceAll("\\s+","").contains(ICM.trim().replaceAll("\\s+",""))){
//    	if(ICDD.trim().replaceAll("\\s+","").equalsIgnoreCase(ICM)){
    		System.out.println(fieldValue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );
    		Log.info(fieldValue + " : is in sync between ICM and ICDD");
    	} else{
    		System.out.println(fieldValue + " value in ICDD : "+"*"+ ICDD +"*"+" is not in SYNC with ICM Value : "+"*"+ ICM +"*");
    		Log.info(fieldValue + " : is not in sync between ICM and ICDD");
    		updateUnsyncfield(fieldValue);}
    	}
    	else{
    		System.out.println("No "+ fieldValue +" value is available either ICDD or ICM");
    		updateEmptyField(fieldValue);
    	}
    }
    
	public void reasonCode(String ICDD, String ICM, String reasonCode, String fieldvalue) throws Exception{
		if(!ICDD.trim().replaceAll("\\s+","").isEmpty() && !ICM.trim().replaceAll("\\s+","").isEmpty()){
			if (ICDD.equalsIgnoreCase("Y") && ICM.contains(reasonCode)){
				Log.info(fieldvalue + " : is in sync between ICM and ICDD");
				System.out.println(fieldvalue + " value in ICDD : "+ ICDD +" is in SYNC with ICM Value : "+ ICM );}
			else{
				System.out.println(fieldvalue + " value in ICDD : "+""+ ICDD +""+" is not in SYNC with ICM Value : "+""+ ICM +"");
	    		Log.info(fieldvalue + " : is not in sync between ICM and ICDD");
	    		updateUnsyncfield(fieldvalue);}
		}
			else{
		System.out.println("No "+ fieldvalue +" value is available either ICDD or ICM");}
		updateEmptyField(fieldvalue);
	}
	
			
	public void updateUnsyncfield(String fieldName) throws Exception{
		String Unsync_Data = testData.get("Unsync_Data");
	    if(!Unsync_Data.isEmpty()){
	    unsync.append(Unsync_Data).append(fieldName+"|");}
	    else{
	    	unsync.append(fieldName+"|");
	    }
	    dataprovider.insertExcelData(scenarioName, "Unsync_Data", sheetname, unsync.toString());
	    }

	public void updateEmptyField(String fieldName) throws Exception{
		String Data = testData.get("empty_data");
	    if(!Data.isEmpty()){
	    empty.append(Data).append(fieldName+"|");}
	    else{
	    	empty.append(fieldName+"|");
	    }
	    dataprovider.insertExcelData(scenarioName, "empty_data", sheetname, empty.toString());
	    }


}
	




	
