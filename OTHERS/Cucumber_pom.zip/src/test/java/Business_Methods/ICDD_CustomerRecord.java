package Business_Methods;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICDD_Forms_Obj;
import Object_Repository.ICDD_WorkItem_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;
import utillities.ScreenshotUtil_old;
import utillities.SetupPropertiesLoader;

public class ICDD_CustomerRecord extends Common_Utils{
	DataProvider dataprovider = new DataProvider();
//	ScreenshotUtil_old screenshot = new ScreenshotUtil_old();
	ICDD_WorkItem iCDD_WorkItem = new ICDD_WorkItem();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public HashMap<String, String> testData = null;
	public static WebDriverWait wait = null;
	public int i;
	public void allInputSearch(String scenarioName,HashMap<String, String> testData) throws Exception {
        try {
        	driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_TAB).click();
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_LASTNAME, testData.get("UserLastName"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_FIRSTNAME, testData.get("UserFirstName"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_TIN, testData.get("UserTIN"));
        	enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ACCOUNTNUMBER, testData.get("UserAccountNo"));;
            selectElementByName(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_CUSTOMERTYPE, testData.get("UserCustomerType"));
            enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ALERTDATE, testData.get("UserAlertDate"));
            driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).click();
        }
        catch (Exception e) {
            throw new Exception("Error while searching customer with all inputs"+" :"+e.getMessage());
        }

    }
	
	public void enterUserNameSearch(String scenarioName,HashMap<String, String> testData) throws Exception
	{
		try{
			driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_TAB).click();
			enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_LASTNAME, testData.get("UserLastName"));
			enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_FIRSTNAME, testData.get("UserFirstName"));
		}
		catch (Exception e) {
	            throw new Exception("Error while searching customer with name: "+testData.get("UserLastName")+" "+testData.get("UserFirstName")+" :"+e.getMessage());
	        }
	}
	
	public void searchiccdId(String scenarioName,HashMap<String, String> testData) throws Exception
	{
		try{
			BaseTestSetup.wait.until(ExpectedConditions.presenceOfElementLocated(ICDD_CustomerRecord_Obj.CUSTOMER_TAB));
            clickPerform(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);
			enterInput(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID").trim());sleep(minWaitVal);
			 screenshot();
			 BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).sendKeys("");
			 BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH).click();sleep(minWaitVal);
			 screenshot();
			// BaseTestSetup.wait.until(ExpectedConditions.elementToBeClickable(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH));
		}
		catch(Exception e)
		{
			screenshot();
			throw new Exception("Error while searching customer with ICCD Reference Id"+" :"+e.getMessage());
		}
	 }

    public void clickiccdid(String scenarioName,HashMap<String, String> testData) throws Exception
    {
    	try{
    		//System.out.println(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCHEDLINK).getText());
    		//WebDriverWait wait = new WebDriverWait(BaseTestSetup.driver, 50);
    		sleep(minWaitVal);
    		sleep(15000);
    		//waitForTextToLoad(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"), testData.get("ICDD_ID"));
    		sleep(minWaitVal);webDriverWait(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"));
    		click(By.xpath("//a[@class='customerLink'][text()='"+testData.get("ICDD_ID")+"']"));
    		screenshot();
    		sleep(mediumWaitVal);
    	}
    	catch(Exception e)
		{
    		screenshot();
			throw new Exception("Error while clicking on ICCD Reference Id"+" :"+e.getMessage());
		}
    }
	
	public void Verify_the_details(String scenarioName,HashMap<String, String> testData)
	{
		try
		{
			List<WebElement> tr_collection = BaseTestSetup.driver.findElements(ICDD_CustomerRecord_Obj.CUSTOMERDATA_TOTAL_ROWS);
			int row_num=1,col_num=1;
			for (WebElement trElement : tr_collection) {
			     List<WebElement> td_collection = trElement.findElements(By.tagName("td")); 
			     int n = td_collection.size();
			    	col_num=1;
			     for (WebElement tdElement  :td_collection) {
			    	String ActualValue = BaseTestSetup.driver.findElement(By.xpath("(//table[@class='clsGridTableBase']/tbody/tr[2]/td)["+col_num+"]")).getText().trim();
			    	System.out.println("Actual Value"+ActualValue);
			    	switch (ActualValue) {
					case "ICDD ID":
						if (!testData.get("referenceID").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("referenceID"))){
									   System.out.println("Actual ICCD Reference Number is: " +tdElement.getText() + ", Expected ICCD Reference Number is: " + testData.get("referenceID") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Active":
						if (!testData.get("Active").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("Active"))){
									   System.out.println("Actual Active Value is: " +tdElement.getText() + ", Expected Actual Value is: " + testData.get("Active") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "TIN":
						if (!testData.get("UserTIN").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("TIN"))){
									   System.out.println("Actaul TIN Value is: " +tdElement.getText() + ", Expected TIN Value is: " + testData.get("TIN") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Customer Name":
						if (!testData.get("CustomerName").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("CustomerName"))){
									   System.out.println("Actual Customer Name is: " +tdElement.getText() + ", Expected Customer Name Value is: " + testData.get("CustomerName") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Customer Type":
						if (!testData.get("UserCustomerType").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("UserCustomerType"))){
									   System.out.println("Actual Customer Type Value is: " +tdElement.getText() + ", Expected Customer Type Value is: " + testData.get("UserCustomerType") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					case "Risk Score":
						if (!testData.get("RiskScore").trim().isEmpty()) {
							  if (tdElement.getText().trim() != null) {
								   if(tdElement.getText().equalsIgnoreCase(testData.get("RiskScore"))){
									   System.out.println("Actual Risk Score is: " +tdElement.getText() + ", Expected Risk Score is: " + testData.get("RiskScore") + ". And it matches");
									    }
								   }
							  
				    	}
						col_num++;
						break;
					default:
						col_num++;
			            break;
			    	}	
			     }		
			}			
		}	
		catch(Exception e)
		{
			
		}
	}
	


	public void searchCustomer_ICDD_ID(String scenarioName,HashMap<String, String> testData) throws InterruptedException {
		this.testData = testData;
		click(ICDD_CustomerRecord_Obj.CUSTOMER_TAB);sleep(minWaitVal);
		screenshot();
		inputText(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_ICDD_ID, testData.get("ICDD_ID"));
		click(ICDD_CustomerRecord_Obj.CUSTOMERSEARCH_SEARCH);sleep(mediumWaitVal);sleep(maxWaitVal);
		webDriverWait(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));
		click(By.xpath("//a[text()='"+ testData.get("ICDD_ID") +"']"));sleep(minWaitVal);
		screenshot();
		Log.info(testData.get("ICDD_ID")+ " ICDD ID is searched & opened successfully ");
		System.out.println(testData.get("ICDD_ID")+ " ICDD ID is searched & opened successfully ");
	}


	public void createSavePDF(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_Forms_Obj.PEP_WORKITEM);
		click(ICDD_CustomerRecord_Obj.PDF_MENU);sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.PDF_ICON);sleep(mediumWaitVal);
		try {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_SHIFT);
			robot.keyPress(KeyEvent.VK_S);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_SHIFT);
			robot.keyRelease(KeyEvent.VK_S);
			sleep(minWaitVal);
			for(int i=0;i<=4;i++){
				robot.keyPress(KeyEvent.VK_TAB);
				robot.keyRelease(KeyEvent.VK_TAB);
				if(i==4){
					enter();
					robotCopyPaste(SetupPropertiesLoader.getProperty("PDF1", "config"));sleep(500);
					enter();sleep(500);
					enter();
				}
			}
			try{
				robot.keyPress(KeyEvent.VK_LEFT);
				robot.keyRelease(KeyEvent.VK_LEFT);
				enter();}
			catch (Exception e) {
			}
		} catch (AWTException e) {
		}
	}
	
	
	public void addAttachment(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.CHECK_ALERT);
	//	iCDD_WorkItem.assign_to_me();
		click(ICDD_CustomerRecord_Obj.ADD_ATTACHMENT);sleep(maxWaitVal);
		switchToWindow();
		click(ICDD_CustomerRecord_Obj.ADD_ATTACHMENT_FILE);sleep(mediumWaitVal);
		//switchBackToParentWindow(windowTitle);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		robotCopyPaste("Alerts.jsp.pdf");
		for(int i=0;i<=3;i++){
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			if(i==3){
				enter();
				robotCopyPaste(SetupPropertiesLoader.getProperty("PDF1", "config"));sleep(500);
				enter();sleep(500);
				enter();
			}
		}
	}
	
	public void viewAttachment(String scenarioName,HashMap<String, String> testData) throws Exception{
		searchiccdId(scenarioName, testData);
    	clickiccdid(scenarioName, testData);
    	click(ICDD_WorkItem_Obj.CUSTOMER_ALERT);sleep(minWaitVal);
		sleep(minWaitVal);
		click(ICDD_CustomerRecord_Obj.CHECK_ALERT);
		click(ICDD_CustomerRecord_Obj.VIEW_ATTACHMENT);sleep(maxWaitVal);
		switchToWindow();
		compareByText(ICDD_CustomerRecord_Obj.ATTACHEMENT_NAME, "Alerts.jsp.pdf");
		click(ICDD_CustomerRecord_Obj.CLOSE_ATTACHMENT_VIEW);
		switchToParentWindow();
	}
	
	
	public void bridge(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
	webDriverwait(By.xpath("//input[@id='autosearch']"));
	click(By.xpath("//input[@id='autosearch']"));
	inputText(By.xpath("//input[@id='autosearch']"), testData.get("StaffName"));sleep(minWaitVal);
	webDriverwait(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']"));
	scrollUpVertical(driver.findElement(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']")));
	click(By.xpath("//span[@class='result-title lnk'][text()='"+ testData.get("StaffName")+"']"));sleep(minWaitVal);
	
	webDriverWait(By.xpath("//span[text()='Title']/.."));
	String designation = driver.findElement(By.xpath("//span[text()='Title']/..")).getText();
	String number = driver.findElement(By.xpath("//span[text()='Phone Number']/..")).getText();
	String email = driver.findElement(By.xpath("//span[text()='Email']/..")).getText();
	StringBuffer sb1 = new StringBuffer(designation);
	StringBuffer sb2 = new StringBuffer(number);
	StringBuffer sb3 = new StringBuffer(email);
	String refID1 = sb1.delete(0, 5).toString().trim();
	String refID2 = sb2.delete(0, 12).toString().trim();
	String refID3 = sb3.delete(0, 5).toString().trim();
	System.out.println(refID1 + "||"+ refID2+ "||"+ refID3);
	dataprovider.insertExcelData(scenarioName, "Designation", sheetname, refID1);
	dataprovider.insertExcelData(scenarioName, "Phone_No", sheetname, refID2);
	dataprovider.insertExcelData(scenarioName, "Email_Id", sheetname, refID3);
	//
	String addLoc = driver.findElement(By.xpath("//*[@id='jive-body']//address")).getText();
	System.out.println(addLoc);
	dataprovider.insertExcelData(scenarioName, "AddressLoc", sheetname, addLoc);
	try{
	System.out.println(driver.findElement(By.xpath("//span[text()='Mobile Phone Number']")).getText());
	String mobNum = driver.findElement(By.xpath("//span[text()='Mobile Phone Number']/..")).getText();
	if(mobNum!=null){
	StringBuffer sb = new StringBuffer(mobNum);
	sb.delete(0, 19);
	String refID = sb.toString().trim();
	System.out.println(mobNum);
	System.out.println(refID);
	dataprovider.insertExcelData(scenarioName, "AlternateNumber", sheetname, refID);}
	}catch (Exception e) {
	}
	}
	
}
