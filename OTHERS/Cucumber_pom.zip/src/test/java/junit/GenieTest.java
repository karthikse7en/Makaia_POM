		
package junit;

import cucumber.api.CucumberOptions;

import cucumber.api.SnippetType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import com.standardchartered.genie.junit.Genie;

@RunWith(Genie.class)
@CucumberOptions(features = { "src/test/resources/features/R1/ICDDCR-808/PR_CR-808_110_PRR_Exit Off-board.feature"},
//@CucumberOptions(features = { "src/test/resources/features/140_Scenarios/D_Rating_Trigger_Review.feature" },
tags = {"@All"},
glue = { "classpath:Step_Defination", "src/test/resources/snippet/" }, monochrome = true, snippets = SnippetType.UNDERSCORE, strict = true, dryRun=false)

public class GenieTest {
    private static Logger Log= LogManager.getLogger(GenieTest.class.getName());
    @BeforeClass
    public static void setup() {
        Log.info("###############################################################################");
        Log.info("##################===Test Suite Execution Started===###########################");
        Log.info("###############################################################################");
    }

    @AfterClass
    public static void teardown() {
        Log.info("#################################################################################");
        Log.info("#####################===Test Suite Execution Completed===########################");
        Log.info("#################################################################################");
    }
}