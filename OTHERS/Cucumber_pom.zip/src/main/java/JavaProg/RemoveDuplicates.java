package JavaProg;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Stack;

public class RemoveDuplicates {

	HashSet<String> set = new HashSet<String>();
	static RemoveDuplicates dup = new RemoveDuplicates(); 
	
	public void deleteDuplicates(){
	String[] array = {"a", "b","a", "b","a", "b", "c", "dog"};
	for (int i=0; i<=array.length-1; i++){
		set.add(array[i]);
	}
	Iterator<String> it = set.iterator();
	while(it.hasNext()){
		System.out.println(it.next());
	}
	}

	
	public void duplicateCount(String s){
    int distinct = 0 ;
    for (int i = 0; i < s.length(); i++) {
        for (int j = 0; j < s.length(); j++) {
            if(s.charAt(i)==s.charAt(j))
            {
                distinct++;
            }
        }   
        System.out.println(s.charAt(i)+"--"+distinct);
        String d=String.valueOf(s.charAt(i)).trim();
        s=s.replaceAll(d,"");
        distinct = 0;
    }
}
	
	public static void main(String[] args){
		//dup.deleteDuplicates();
		//dup.duplicateCount("hellllloooowwww world");
		
//		ZoneId z = ZoneId.of(zoneId)
//		LocalDate today = LocalDate.now( z );
		
		String pattern = "dd-MM-yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		System.out.println(date);
		
		
	}
}
