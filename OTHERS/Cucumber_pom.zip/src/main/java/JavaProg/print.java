package JavaProg;

public class print {

/*	public void print(){
		for (i )
	}*/
}
