package JavaProg;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class sample {

	public static void main(String[] args) throws IOException {

		createFile();
	}
	public static void createFile() throws IOException{
		
		String data="Bruce Lee";
		FileOutputStream Out=new FileOutputStream("c://SCB//Test.docx");
		System.out.println(data.getBytes());
		Out.write(data.getBytes());
		Out.close();
		
		
	}


}
