package Business_Methods;

import java.util.HashMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;

import Object_Repository.ICDD_CustomerRecord_Obj;
import Object_Repository.ICM_UpdateCustomerProfilePage_Obj;
import utillities.BaseTestSetup;
import utillities.Common_Utils;
import utillities.DataProvider;

public class DataSync_ICDD_ICM extends Common_Utils {
	DataProvider dataprovider = new DataProvider();
	ICM_UpdateCustomerProfilePage ICM_Modules = new ICM_UpdateCustomerProfilePage();
	ICDD_CustomerRecord ICDD_CustomerRecord = new ICDD_CustomerRecord();
	private static Logger Log = LogManager.getLogger(ICM_UpdateCustomerProfilePage.class.getName());
	public HashMap<String, String> testData = null;
	
	public void ICM_Data(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("######################## Data in ICM ############################");
		this.testData = testData;
		ICM_Modules.login();
		ICM_Modules.serachForIcmId(testData);
		getICMData(scenarioName, testData, sheetname);
	}
	
	public void ICDD_Data(String scenarioName, HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("############################ Data in ICM ############################");
		getICDDdata(scenarioName, testData, sheetname);
	}
	
	public void DataSyncVerify(String scenarioName, HashMap<String, String> testData, String sheetname){
		Log.info("############################ DataSync verification in ICM/ICDD ############################");
		compareString(testData.get("CUSTOMER_NAME_ICDD"), testData.get("DS_FullName"), "Customer Name");
		compareString(testData.get("RISK_RATING_ICDD"), testData.get("DS_CDD_RiskCode"), "CDD Risk code");
		compareString(testData.get("CDD_STATUS_ICDD"), testData.get("DS_CDD_Status"), "CDD Status");
		compareString(testData.get("COUNTRY_ICDD"), testData.get("DS_Nationality"), "Country of birth");
		compareString(testData.get("DOB_ICDD"), testData.get("DS_DOB"), "Date of birth");
		compareString(testData.get("NATIONALITY_ICDD"), testData.get("DS_Nationality"), "Nationality");
		compareString(testData.get("NEXT_REVIEW_DATE_ICDD"), testData.get("DS_NRD"), "Next Review Date");
		compareString(testData.get("LAST_REVIEW_DATE_ICDD"), testData.get("DS_LRD"), "Last Review Date");
		compareString(testData.get("DS_FullName"), testData.get("CUSTOMER_NAME_ICDD"), "Customer Name");
		//compareString(testData.get("GENDER_ICDD"), testData.get("DS_Gender"), "Gender");
	}
	
	public void getICDDdata(String scenarioName,HashMap<String, String> testData, String sheetname) throws Exception{
		ICDD_CustomerRecord.searchiccdId(scenarioName,testData);
        ICDD_CustomerRecord.clickiccdid(scenarioName,testData);
        System.out.println(BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        dataprovider.insertExcelData(scenarioName, "CUSTOMER_NAME_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        Log.info("Actual CUSTOMER_NAME_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        System.out.println("Actual CUSTOMER_NAME_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_NAME).getText());
        
        
        
        dataprovider.insertExcelData(scenarioName, "RISK_RATING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        Log.info("Actual RISK_RATING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        System.out.println("Actual RISK_RATING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.RISK_RATING).getText());
        
        dataprovider.insertExcelData(scenarioName, "CDD_STATUS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        Log.info("Actual CDD_STATUS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        System.out.println("Actual CDD_STATUS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CDD_STATUS).getText());
        
        dataprovider.insertExcelData(scenarioName, "CITY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        Log.info("Actual CITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        System.out.println("Actual CITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CITY).getText());
        
        dataprovider.insertExcelData(scenarioName, "STATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        Log.info("Actual STATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        System.out.println("Actual STATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.STATE).getText());
        
        dataprovider.insertExcelData(scenarioName, "COUNTRY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        Log.info("Actual COUNTRY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        System.out.println("Actual COUNTRY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.COUNTRY).getText());
        
        dataprovider.insertExcelData(scenarioName, "DOB_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        Log.info("Actual DOB_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        System.out.println("Actual DOB_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.DOB).getText());
        
        dataprovider.insertExcelData(scenarioName, "NATIONALITY_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
        Log.info("Actual NATIONALITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
        System.out.println("Actual NATIONALITY_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NATIONALITY).getText());
        
        dataprovider.insertExcelData(scenarioName, "NEXT_REVIEW_DATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
        Log.info("Actual NEXT_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
        System.out.println("Actual NEXT_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NEXT_REVIEW_DATE).getText());
        
        dataprovider.insertExcelData(scenarioName, "LAST_REVIEW_DATE_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        Log.info("Actual LAST_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        System.out.println("Actual LAST_REVIEW_DATE_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.CUSTOMER_LAST_REVIEW_DATE).getText());
        
        clickPerform(ICDD_CustomerRecord_Obj.ADDITIONAL_DATA_TAB);sleep(minWaitVal);
        dataprovider.insertExcelData(scenarioName, " NAME_OF_EMPLYER_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
        Log.info("Actual NAME_OF_EMPLYER_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
        System.out.println("Actual NAME_OF_EMPLYER_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_OF_EMPLYER).getText());
        
        click(ICDD_CustomerRecord_Obj.ONBOARDING_TAB);sleep(minWaitVal);
        dataprovider.insertExcelData(scenarioName, "NAME_SCREENING_HIT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());
        Log.info("Actual NAME_SCREENING_HIT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());
        System.out.println("Actual NAME_SCREENING_HIT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_HIT).getText());
        
        dataprovider.insertExcelData(scenarioName, "NAME_SCREENING_ALERT_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        Log.info("Actual NAME_SCREENING_ALERT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        System.out.println("Actual NAME_SCREENING_ALERT_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.NAME_SCREENING_ALERT).getText());
        
        dataprovider.insertExcelData(scenarioName, "MATCH_TRUE_MATCH_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        Log.info("Actual MATCH_TRUE_MATCH_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        System.out.println("Actual MATCH_TRUE_MATCH_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.MATCH_TRUE_MATCH).getText());
        
        dataprovider.insertExcelData(scenarioName, "TYPE_NAME_SCREENING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        Log.info("Actual TYPE_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        System.out.println("Actual TYPE_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.TYPE_NAME_SCREENING).getText());
        
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_PEP_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        Log.info("Actual POTANTIAL_PEP_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        System.out.println("Actual POTANTIAL_PEP_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_PEP).getText());
        
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_SANCTIONS_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        Log.info("Actual POTANTIAL_SANCTIONS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        System.out.println("Actual POTANTIAL_SANCTIONS_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_SANCTIONS).getText());
        
        dataprovider.insertExcelData(scenarioName, "POTANTIAL_ADVERSE_MEDIA_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        Log.info("Actual POTANTIAL_ADVERSE_MEDIA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        System.out.println("Actual POTANTIAL_ADVERSE_MEDIA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.POTANTIAL_ADVERSE_MEDIA).getText());
        
        clickPerform(ICDD_CustomerRecord_Obj.PROHIBITION_TAB);sleep(minWaitVal);
        dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_STATIC_DATA_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        Log.info("Actual PROHIBITION_BASED_ON_STATIC_DATA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        System.out.println("Actual PROHIBITION_BASED_ON_STATIC_DATA_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_STATIC_DATA).getText());
        
        dataprovider.insertExcelData(scenarioName, " PROHIBITION_BASED_ON_NAME_SCREENING_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        Log.info("Actual PROHIBITION_BASED_ON_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        System.out.println("Actual PROHIBITION_BASED_ON_NAME_SCREENING_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PROHIBITION_BASED_ON_NAME_SCREENING).getText());
        
        clickPerform(ICDD_CustomerRecord_Obj.CUSTOMER_PHONE_NUM);sleep(minWaitVal);
        try{
        dataprovider.insertExcelData(scenarioName, " PHONE1_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        Log.info("Actual PHONE1_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        System.out.println("Actual PHONE1_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.PHONE1).getText());
        }catch(Exception e){}
        clickPerform(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS);sleep(minWaitVal);
        try{
        dataprovider.insertExcelData(scenarioName, " EMAIL_ICDD",sheetname, BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        Log.info("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        System.out.println("Actual EMAIL_ICDD is: " + BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.EMAIL_ADDRESS_EMAIL1).getText());
        }catch(Exception e){}
       /* clickPerform(ICDD_CustomerRecord_Obj.ACCOUNT_TAB);sleep(minWaitVal);
        clickPerform(ICDD_CustomerRecord_Obj.ACTIVE_ACCOUNT_DETAILS);sleep(minWaitVal);
        dataprovider.insertExcelData(scenarioName, " ACCOUNT_NUMBER5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_NUMBER5).getText());
        dataprovider.insertExcelData(scenarioName, " ACCCOUNT_SUBPRODUCT5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCCOUNT_SUBPRODUCT5).getText());
        dataprovider.insertExcelData(scenarioName, " ACCOUNT_SUBPRODUCT_DESCRIPTION5", BaseTestSetup.driver.findElement(ICDD_CustomerRecord_Obj.ACCOUNT_SUBPRODUCT_DESCRIPTION5).getText());*/
	}
	
	
	public void getICMData(String scenarioName, HashMap<String, String> testData, String sheetname) throws Exception{
		Log.info("########### Basic Data");
		//DS_Relationship_No
		String val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_RELATIONSHIP_NO).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_Relationship_No", sheetname, val);
			System.out.println("Actual ICM Relationship Number is: " + val);
			Log.info("Actual ICM Relationship Number is: " + val);}
		
		//DS_Status
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_STATUS).getText();
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_Status", sheetname, val);
			System.out.println("Actual ICM Status is: " + val);
			Log.info("Actual ICM Status is: " + val);}
		
		//DS_Gender
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_GENDER).getText();
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_Gender", sheetname, val);
			System.out.println("Actual ICM Gender is: " + val);
			Log.info("Actual ICM Gender is: " + val);}
		
		//DOB
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_DATEOFBIRTH).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_DOB", sheetname, val);
			System.out.println("Actual ICM DOB is: " + val);
			Log.info("Actual ICM DOB is: " + val);}
		
		//nationality
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_NATIONALITY).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_Nationality", sheetname, val);
			System.out.println("Actual ICM Nationality is: " + val);
			Log.info("Actual ICM Nationality is: " + val);}
		
		//Country of birth
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.BASIC_COUNTRY_OF_BIRTH).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_CountryOfBirth", sheetname, val);
			System.out.println("Actual ICM Country of Birth is: " + val);
			Log.info("Actual ICM Country of Birth is: " + val);}
		
		//Customer_fullname
		click(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_RISK);sleep(minWaitVal);
		val = driver.findElement(By.xpath("(//input[@id='custname'])[1]")).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_FullName", sheetname, val);
			System.out.println("Actual ICM Customer Fullname is: " + val);
			Log.info("Actual ICM Customer Fullname is: " + val);}		
		
		Log.info("########### CDD data");
		//CDD status
		click(ICM_UpdateCustomerProfilePage_Obj.PROFILE_ENQUIRY_CDD);
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_STATUS).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_CDD_Status", sheetname, val);
			System.out.println("Actual ICM CDD Status is: " + val);
			Log.info("Actual ICM CDD Status is: " + val);}
		
		//CDD Risk code
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_RISK_CODE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_CDD_RiskCode", sheetname, val);
			System.out.println("Actual ICM CDD Risk Code is: " + val);
			Log.info("Actual ICM CDD Risk Code is: " + val);}
		
		//LRD
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_LAST_REVIEW_DATE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_LRD", sheetname, val);
			System.out.println("Actual ICM LRD is: " + val);
			Log.info("Actual ICM LRD is: " + val);}
		
		//NRD
		val = driver.findElement(ICM_UpdateCustomerProfilePage_Obj.CDD_NEXT_REVIEW_DATE).getAttribute("value");
		if (val.trim() != null) {
			dataprovider.insertExcelData(scenarioName, "DS_NRD", sheetname, val);
			System.out.println("Actual ICM NRD is: " + val);
			Log.info("Actual ICM NRD is: " + val);}
		
		
		
	}
		
		
		
		
}
